// ==UserScript==
// @name         PT站点自动签到
// @namespace    dhjesus
// @version      1.3.1
// @description  pt站点自动签到(本插件基于PTsign二次开发https://greasyfork.org/zh-CN/scripts/372581-ptsign，感谢原作者)
// @author       DHJesus
// @include     *://ourbits.club/*
// @include     *://hdhome.org/*
// @include     *://hdchina.org/*
// @include     *://pterclub.com/*
// @include     *://leaguehd.com/*
// @include     *://lemonhd.org/*
// @include     *://pthome.net/*
// @include     *://pt.btschool.club/*
// @include     *://pt.soulvoice.club/*
// @include     *://1ptba.com/*
// @include     *://www.hddolby.com/*
// @include     *://hdzone.me/*
// @include     *://hddisk.life/*
// @include     *://discfan.net/*
// @include     *://www.hdarea.co/*
// @include     *://hdcity.city/*
// @include     *://dhcmusic.xyz/*
// @include     *://totheglory.im/*
// @include     *://www.nicept.net/*
// @include     *://yingk.com/*
// @include     *://hdstreet.club/*
// @include     *://52pt.site/*
// @include     *://moecat.best/*
// @include     *://pt.hd4fans.org/*
// @include     *://www.haidan.video/*
// @grant        none
// @compatible	 Chrome
// @compatible	 Firefox
// @compatible	 Edge
// @compatible	 Safari
// @compatible	 Opera
// @compatible	 UC
// ==/UserScript==

(function () {
  var host = window.location.host
  var href = window.location.href
  setTimeout(function() {
    var ourbitsSign = document.getElementsByClassName('faqlink')[0]
    var hdhomeSign = document.getElementsByClassName('faqlink')[0]
    var hdc = document.getElementsByClassName('userinfort')[0]
    if(hdc) {
      var hdchinaSign = hdc.getElementsByTagName('a')[1]
    }
    var pterSign = document.getElementsByClassName('faqlink')[0]
    var leaguehdSign = document.getElementsByClassName('faqlink')[0]
    var lemonhdSign = document.getElementsByClassName('faqlink')[0]
    var pthomeSign = document.getElementsByClassName('faqlink')[0]
    var btschool = document.getElementsByClassName('outer')[0]
    if(btschool) {
      var btschoolSign = btschool.getElementsByTagName('a')[0]
    }
    var soulvoiceSign = document.getElementsByClassName('faqlink')[0]
    var _1ptbaSign = document.getElementsByClassName('faqlink')[0]
    var hddolbySign = document.getElementsByClassName('faqlink')[0]
    var hdzoneSign = document.getElementsByClassName('faqlink')[0]
    var hddiskSign = document.getElementsByClassName('faqlink')[0]
    var discfanSign = document.getElementsByClassName('faqlink')[0]
    var hdarea = document.getElementById('sign_in')
    if(hdarea) {
      var hdareaSign = hdarea.getElementsByTagName('a')[0]
    }
    var hdcity = document.getElementById('bottomnav')
    if(hdcity) {
      var hdcitySign = hdcity.getElementsByTagName('a')[1]
    }
    var dhcmusicSign = document.getElementsByClassName('faqlink')[0]
    var ttg = document.getElementById('sp_signed')
    if(ttg) {
      var ttgSign = ttg.getElementsByTagName('a')[0]
    }
    var niceptSign = document.getElementsByClassName('faqlink')[0]
    var haidanSign = document.getElementById('modalBtn')

    // BAKATEST SITE
    var yingkSign = document.getElementById('game')
    var hdstreet = document.getElementsByClassName('medium')[0]
    if(hdstreet) {
      var hdstreetSign = hdstreet.getElementsByTagName('a')[5]
    }
    var _52ptSign = document.getElementById('game')
    var moecatSign = document.getElementById('game')
    var hd4fan = document.getElementById('checkin')
    if(hd4fan) {
        var hd4fanSign = hd4fan.getElementsByTagName('a')[0]
    }


    if (host.indexOf('ourbits') != -1 && ourbitsSign.innerText.indexOf('签到得魔力') != -1) {
      ourbitsSign.click()
    }
    if (host.indexOf('hdhome') != -1 && hdhomeSign.innerText.indexOf('签到得魔力') != -1) {
      hdhomeSign.click()
    }
    if (host.indexOf('hdchina') != -1 && hdchinaSign.innerText.indexOf('签 到') != -1) {
      hdchinaSign.click()
    }
    if (host.indexOf('pterclub') != -1 && pterSign.innerText.indexOf('签到得猫粮') != -1) {
      pterSign.click()
    }
    if (host.indexOf('leaguehd') != -1 && leaguehdSign.innerText.indexOf('签到获魔力') != -1) {
      leaguehdSign.click()
    }
    if (host.indexOf('lemonhd') != -1 && lemonhdSign.innerText.indexOf('签到获魔力') != -1) {
      lemonhdSign.click()
    }
    if (host.indexOf('pthome') != -1 && pthomeSign.innerText.indexOf('签到得魔力') != -1) {
      pthomeSign.click()
    }
    if (host.indexOf('btschool') != -1 && btschoolSign.innerText.indexOf('每日签到') != -1) {
      btschoolSign.click()
    }
    if (host.indexOf('soulvoice') != -1 && soulvoiceSign.innerText.indexOf('签到得魔力') != -1) {
      soulvoiceSign.click()
    }
    if (host.indexOf('1ptba') != -1 && _1ptbaSign.innerText.indexOf('签到得魔力') != -1) {
      _1ptbaSign.click()
    }
    if (host.indexOf('hddolby') != -1 && hddolbySign.innerText.indexOf('签到得魔力') != -1) {
      hddolbySign.click()
    }
    if (host.indexOf('hdzone') != -1 && hdzoneSign.innerText.indexOf('签到得魔力') != -1) {
      hdzoneSign.click()
    }
    if (host.indexOf('hddisk') != -1 && hddiskSign.innerText.indexOf('签到得魔力') != -1) {
      hddiskSign.click()
    }
    if (host.indexOf('discfan') != -1 && (discfanSign.innerText.indexOf('簽到得魔力') != -1 || discfanSign.innerText.indexOf('签到得魔力') != -1)) {
      discfanSign.click()
    }
    if (host.indexOf('hdarea') != -1 && hdareaSign.innerText.indexOf('签到') != -1) {
      hdareaSign.click()
    }
    if (host.indexOf('hdcity') != -1 && hdcitySign.innerText.indexOf('签到') != -1 && hdcitySign.innerText.indexOf('已签到') < 0) {
      hdcitySign.click()
    }
    if (host.indexOf('dhcmusic') != -1 && dhcmusicSign.innerText.indexOf('签到得魔力') != -1) {
      dhcmusicSign.click()
    }
    if (host.indexOf('totheglory') != -1 && ttgSign.innerText.indexOf('签到') != -1) {
      ttgSign.click()
    }
    if (host.indexOf('nicept') != -1 && (niceptSign.innerText.indexOf('簽到得魔力') != -1 || niceptSign.innerText.indexOf('签到得魔力') != -1)) {
      niceptSign.click()
    }
    if (host.indexOf('haidan') != -1 && haidanSign.value.indexOf('每日打卡') != -1) {
      haidanSign.click()
    }
    // BAKSTEST SITE
    if (host.indexOf('yingk') != -1 && href.indexOf('bakatest') < 0 && yingkSign.innerText.indexOf('每日签到') != -1) {
      yingkSign.click()
    }
    if (host.indexOf('hdstreet') != -1 && href.indexOf('bakatest') < 0 && hdstreetSign.innerText.indexOf('每日签到') != -1) {
      hdstreetSign.click()
    }
    if (host.indexOf('52pt') != -1 && href.indexOf('bakatest') < 0 && _52ptSign.innerText.indexOf('签到赚魔力') != -1) {
      _52ptSign.click()
    }
    if (host.indexOf('moecat') != -1 && href.indexOf('bakatest') < 0 && moecatSign.innerText.indexOf('每日签到') != -1) {
      moecatSign.click()
    }
    if (host.indexOf('hd4fans') != -1 && hd4fanSign.innerText.indexOf('签 到') != -1) {
      hd4fanSign.click()
    }
  }, 500)
})();