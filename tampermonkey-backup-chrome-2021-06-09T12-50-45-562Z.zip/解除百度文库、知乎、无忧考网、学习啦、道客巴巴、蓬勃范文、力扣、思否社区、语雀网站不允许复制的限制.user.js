// ==UserScript==
// @name        解除百度文库、知乎、无忧考网、学习啦、道客巴巴、蓬勃范文、力扣、思否社区、语雀网站不允许复制的限制
// @description 解除大部分网站不能复制的限制以及淘宝京东内部优惠劵查询
// @namespace   idey.cn
// @version     8.4.2
// @author      idey.cn
// @include        *://*.taobao.com/*
// @include        *://*.tmall.com/*
// @include        *://*.tmall.hk/*
// @include        *://*.jd.com/*
// @include        *://*.jd.hk/*
// @include        *://*.liangxinyao.com/*
// @include     *://wenku.baidu.com/view/*
// @include     *://wenku.baidu.com/link*
// @include     *://www.51test.net/show/*
// @include     *://www.xuexi.la/*
// @include     *://www.xuexila.com/*
// @include     *://www.cspengbo.com/*
// @include     *://www.doc88.com/*
// @include     *://segmentfault.com/*
// @include     *://wk.baidu.com/view/*
// @include     *://leetcode-cn.com/problems/*
// @include     *://www.zhihu.com/*
// @include     *://z.30edu.com.cn/*
// @include     *://docs.qq.com/doc/*
// @include     *://boke112.com/post/*
// @include     *://www.yuque.com/*
// @include     *://www.commandlinux.com/*
// @license     GPL License
// @require     https://cdn.bootcdn.net/ajax/libs/jquery/2.1.2/jquery.js
// @require     https://cdn.jsdelivr.net/npm/clipboard@2/dist/clipboard.min.js
// @require 	https://cdn.staticfile.org/echarts/4.3.0/echarts.min.js
// @require      https://cdn.bootcss.com/jquery.qrcode/1.0/jquery.qrcode.min.js
// @connect     static.doc88.com
// @grant       unsafeWindow
// @grant       GM_xmlhttpRequest
// ==/UserScript==
(function() {
	'use strict';

	var selectorList = [];
	var obj = {};

	function trim(str) {
		return str.replace(/(^\s*)|(\s*$)/g, "");
	}

	function removeEvent(that, href) {
		that.find("a").attr('target', '');
		that.find("a").unbind("click");
		that.find("a").bind("click", function(e) {
			e.preventDefault();
			if (href != undefined) {
				onclicks(href);
			} else {
				onclicks($(this).attr('href'));
			}

		})
	}



	obj.initSearchHtml = function(selectorList) {
		setInterval(function() {
			selectorList.forEach(function(selector) {
				obj.initSearchItemSelector(selector);
			});
		}, 3000);
	};

	obj.initSearchEvent = function() {
		$(document).on("click", ".tb-cool-box-area", function() {
			var $this = $(this);
			if ($this.hasClass("tb-cool-box-wait")) {
				obj.basicQueryItem(this);
			} else if ($this.hasClass("tb-cool-box-info-translucent")) {
				$this.removeClass("tb-cool-box-info-translucent");
			} else {
				$this.addClass("tb-cool-box-info-translucent");
			}
		});
	};

	obj.basicQuery = function() {
		setInterval(function() {
			$(".tb-cool-box-wait").each(function() {
				obj.basicQueryItem(this);
			});
		}, 3000);
	};

	obj.initSearchItemSelector = function(selector) {
		$(selector).each(function() {
			obj.initSearchItem(this);
		});
	};

	obj.initSearchItem = function(selector) {
		var $this = $(selector);
		if ($this.hasClass("tb-cool-box-already")) {
			return;
		} else {
			$this.addClass("tb-cool-box-already")
		}

		var nid = $this.attr("data-id");
		if (!obj.isVailidItemId(nid)) {
			nid = $this.attr("data-itemid");
		}

		if (!obj.isVailidItemId(nid)) {
			if ($this.attr("href")) {
				nid = location.protocol + $this.attr("href");
			} else {
				var $a = $this.find("a");
				if (!$a.length) {
					return;
				}

				nid = $a.attr("data-nid");
				if (!obj.isVailidItemId(nid)) {
					if ($a.hasClass("j_ReceiveCoupon") && $a.length > 1) {
						nid = location.protocol + $($a[1]).attr("href");
					} else {
						nid = location.protocol + $a.attr("href");
					}
				}
			}
		}

		if (obj.isValidNid(nid)) {
			obj.basicQueryItem($this, nid);
		}
	};



	obj.basicQueryItem = function(selector, nid) {
		var $this = $(selector);
		$.get('https://www.idey.cn/api/index/get_list_taobao_link?itemid=' + nid, function(data) {
			if (data.type == 'success') {
				obj.changeUrl($this, data.data);
			} else {

			}
		}, 'json')
	};

	obj.changeUrl = function(selector, data) {
		var $this = $(selector);
		var a = $this.find("a");
		$this.find("a").attr('href', data.itemUrl);
		$this.find("a").attr('data-href', data.itemUrl);
	}


	obj.isDetailPageTaoBao = function(url) {
		if (url.indexOf("//item.taobao.com/item.htm") > 0 || url.indexOf("//detail.tmall.com/item.htm") > 0 ||
			url.indexOf("//chaoshi.detail.tmall.com/item.htm") > 0 || url.indexOf(
				"//detail.tmall.hk/hk/item.htm") > 0) {
			return true;
		} else {
			return false;
		}
	};

	obj.isVailidItemId = function(itemId) {
		if (!itemId) {
			return false;
		}

		var itemIdInt = parseInt(itemId);
		if (itemIdInt == itemId && itemId > 10000) {
			return true;
		} else {
			return false;
		}
	};

	obj.isValidNid = function(nid) {
		if (!nid) {
			return false;
		} else if (nid.indexOf('http') >= 0) {
			if (obj.isDetailPageTaoBao(nid) || nid.indexOf("//detail.ju.taobao.com/home.htm") > 0) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	};

	function isTaoBao(url) {

		if (url.indexOf("taobao") > 0 || url.indexOf("tmall") > 0 || url.indexOf(".detail.tmall.") > 0 || url
			.indexOf(
				"//detail.tmall.hk/hk/item.htm") > 0 || url.indexOf(".jd.") > 0 || url.indexOf("detail.vip") > 0) {
			return true;
		} else {
			return false;
		}
	};

	function get_page_url_id(pagetype, url, type) {
		var return_data = '';
		if (pagetype == 'taobao_item') {
			var params = location.search.split("?")[1].split("&");
			for (var index in params) {
				if (params[index].split("=")[0] == "id") {
					var productId = params[index].split("=")[1];
				}
			}
			return_data = productId;
		}
		return return_data;
	};

	function get_type_url(url) {
		if (
			url.indexOf("//item.taobao.com/item.htm") > 0 ||
			url.indexOf("//detail.tmall.com/item.htm") > 0 ||
			url.indexOf("//chaoshi.detail.tmall.com/item.htm") > 0 ||
			url.indexOf("//detail.tmall.hk/hk/item.htm") > 0 ||
			url.indexOf("//world.tmall.com") > 0 ||
			url.indexOf("//detail.liangxinyao.com/item.htm") > 0 ||
			url.indexOf("//detail.tmall.hk/item.htm") > 0
		) {
			return 'taobao_item';
		} else if (
			url.indexOf("//maiyao.liangxinyao.com/shop/view_shop.htm") > 0 ||
			url.indexOf("//list.tmall.com/search_product.htm") > 0 ||
			url.indexOf("//s.taobao.com/search") > 0 ||
			url.indexOf("//list.tmall.hk/search_product.htm") > 0
		) {
			return 'taobao_list';
		} else if (
			url.indexOf("//search.jd.com/Search") > 0 ||
			url.indexOf("//search.jd.com/search") > 0 ||
			url.indexOf("//search.jd.hk/search") > 0 ||
			url.indexOf("//search.jd.hk/Search") > 0 ||
			url.indexOf("//www.jd.com/xinkuan") > 0 ||
			url.indexOf("//list.jd.com/list.html") > 0 ||
			url.indexOf("//i-search.jd.com/Search") > 0 ||
			url.indexOf("//search.jd.hk/Search") > 0 ||
			url.indexOf("//coll.jd.com") > 0
		) {
			return 'jd_list';
		} else if (
			url.indexOf("//item.jd.hk") > 0 ||
			url.indexOf("//pcitem.jd.hk") > 0 ||
			url.indexOf("//i-item.jd.com") > 0 ||
			url.indexOf("//item.jd.com") > 0 ||
			url.indexOf("//npcitem.jd.hk") > 0
		) {
			return 'jd_item';
		} else if (
			url.indexOf("//miaosha.jd.com") > 0
		) {
			return 'jd_miaosha';
		}

	};


	var pageurl = location.href;
	if (isTaoBao(pageurl)) {

		const style = `
		.gwd_taobao .gwd-minibar-bg, .gwd_tmall .gwd-minibar-bg {
		    display: block;
		}
		
		.idey-minibar_bg{
		    position: relative;
		    min-height: 40px;
		    display: inline-block;
		}
		#idey_minibar{
		    width: 460px;
		    background-color: #fff;
		    position: relative;
		    border: 1px solid #e8e8e8;
		    display: block;
		    line-height: 36px;
		    font-family: 'Microsoft YaHei',Arial,SimSun!important;
		    height: 36px;
		    float: left;
		}
		#idey_minibar .idey_website {
		    width: 48px;
		    float: left;
		    height: 36px;
		}
		#idey_minibar .minibar-tab {
		    float: left;
		    height: 36px;
		    border-left: 1px solid #edf1f2!important;
		    padding: 0;
		    margin: 0;
		    text-align: center;
		}
		
		#idey_minibar .idey_website em {
		    background-position: -10px -28px;
		    height: 36px;
		    width: 25px;
		    float: left;
		    margin-left: 12px;
		}
		
		.setting-bg {
		    background: url(https://cdn.gwdang.com/images/extensions/xbt/new_wishlist_pg5_2.png) no-repeat;
		}
		
		#idey_minibar .minibar-tab {
		    float: left;
		    height: 36px;
		    border-left: 1px solid #edf1f2!important;
		    padding: 0;
		    margin: 0;
		    width: 134px;
		}
		#idey_price_history span {
		    float: left;
		    width: 100%;
		    text-align: center;
		    line-height: 36px;
		    color: #666;
		    font-size: 14px;
		}
		
		#mini_price_history .trend-error-info-mini {
		    position: absolute;
		    top: 37px;
		    left: 0px;
		    width: 100%;
		    background: #fff;
		    z-index: 99999999;
		    height: 268px;
		    display: none;
		    box-shadow: 0px 5px 15px 0 rgb(23 25 27 / 15%);
		    border-radius: 0 0 4px 4px;
		    width: 460px;
		    border: 1px solid #ddd;
		    border-top: none;
		}
		.minibar-btn-box {
		    display: inline-block;
		    margin: 0 auto;
		    float: none;
		}
		#mini_price_history .error-p {
		      width: 95px;
		      margin: 110px auto;
		      height: 20px;
		      line-height: 20px;
		      text-align: center;
		      color: #000!important;
		      border: 1px solid #333;
		      border-radius: 5px;
		      display: block;
		      text-decoration: none!important;
		    }
		 #mini_price_history:hover .trend-error-info-mini {
		      display: block;
		    }
		
		.collect_mailout_icon {
		    background-position: -247px -134px;
		    width: 18px;
		}
		
		#idey_mini_compare_detail li *, .mini-compare-icon, .minibar-btn-box * {
		    float: left;
		}
		.collect_mailout_icon, .mini-compare-icon {
		    height: 18px;
		    margin-right: 8px;
		    margin-top: 9px;
		}
		
		 .bjgext-mini-trend span {
		      float: left;
		      /*width: 100%;*/
		      text-align: center;
		      line-height: 36px;
		      color: #666;
		      font-size: 14px;
		    }
		    .bjgext-mini-trend .trend-error-info-mini {
		      position: absolute;
		      top: 37px;
		      left: 0px;
		      width: 100%;
		      background: #fff;
		      z-index: 99999999;
		      height: 268px;
		      display: none;
		      box-shadow: 0px 5px 15px 0 rgba(23,25,27,0.15);
		      border-radius: 0 0 4px 4px;
		      width: 460px;
		      border: 1px solid #ddd;
		      border-top: none;
		    }
		    .bjgext-mini-trend .error-p {
		      width: 100%;
		      float: left;
		      text-align: center;
		      margin-top: 45px;
		      font-size: 14px;
		      color: #666;
		    }
		    .bjgext-mini-trend .error-sp {
		      width: 95px;
		      margin: 110px auto;
		      height: 20px;
		      line-height: 20px;
		      text-align: center;
		      color: #000!important;
		      border: 1px solid #333;
		      border-radius: 5px;
		      display: block;
		      text-decoration: none!important;
		    }
		    .bjgext-mini-trend:hover .trend-error-info-mini {
		      display: block;
		    }
		    
		    
		    #coupon_box.coupon-box1 {
		      width: 460px;
		      height: 114px;
		      background-color: #fff;
		      border: 1px solid #e8e8e8;
		      border-top: none;
		      position: relative;
		      margin: 0px;
		      padding: 0px;
		      float: left;
		      display: block;
		    }
		    #coupon_box:after {
		      display: block;
		      content: "";
		      clear: both;
		    }
		    .idey_tmall #idey_minibar {
		      float: none;
		    }
		   
		    
		    .minicoupon_detail {
		      position: absolute;
		      top: 35px;
		      right: -1px;
		      height: 150px;
		      width: 132px;
		      display: none;
		      z-index: 99999999999;
		      background: #FFF7F8;
		      border: 1px solid #F95774;
		    }
		    #coupon_box:hover .minicoupon_detail {
		      display: block;
		    }
		    .minicoupon_detail img {
		      width: 114px;
		      height: 114px;
		      float: left;
		      margin-left: 9px;
		      margin-top: 9px;
		    }
		    .minicoupon_detail span {
		      font-size: 14px;
		      color: #F95572;
		      letter-spacing: 0;
		      font-weight: bold;
		      float: left;
		      height: 12px;
		      line-height: 14px;
		      width: 100%;
		      margin-top: 6px;
		      text-align: center;
		    }
		    .coupon-box1 * {
		      font-family: 'Microsoft YaHei',Arial,SimSun;
		    }
		    .coupon-icon {
		      float: left;
		      width: 20px;
		      height: 20px;
		      background: url('https://cdn.gwdang.com/images/extensions/newbar/coupon_icon.png') 0px 0px no-repeat;
		      margin: 50px 8px 9px 12px;
		    }
		    #coupon_box .coupon-tle {
		      color: #FF3B5C;
		      font-size: 12px;
		      margin-right: 11px;
		      float: left;
		      height: 114px;
		      overflow: hidden;
		      text-overflow: ellipsis;
		      white-space: nowrap;
		      width: 296px;
		      line-height: 114px;
		      text-decoration: none!important;
		    }
		    #coupon_box .coupon-row{
		         color: #FF3B5C;
		      font-size: 12px;
		      margin-right: 11px;
		      float: left;
		      height: 60px;
		      overflow: hidden;
		      text-overflow: ellipsis;
		      white-space: nowrap;
		      width: 100%;
		      line-height: 60px;
		      text-decoration: none!important;
		        text-align: center;
		    }
		    #coupon_box .coupon-tle * {
		      color: #f15672;
		    }
		    #coupon_box .coupon-tle span {
		      margin-right: 5px;
		      font-weight: bold;
		      font-size: 14px;
		    }
		    .coupon_gif {
		      background: url('https://cdn.gwdang.com/images/extensions/newbar/turn.gif') 0px 0px no-repeat;
		      float: right;
		      height: 20px;
		      width: 56px;
		      margin-top: 49px;
		    }
		    .click2get {
		      background: url('https://cdn.gwdang.com/images/extensions/newbar/coupon_01.png') 0px 0px no-repeat;
		      float: left;
		      height: 30px;
		      width: 96px;
		      margin-top: 43px;
		    }
		    .click2get span {
		      height: 24px;
		      float: left;
		      margin-left: 1px;
		    }
		    .c2g-sp1 {
		      width: 50px;
		      color: #FF3B5C;
		      text-align: center;
		      font-size: 14px;
		      line-height: 24px!important;
		    }
		    .c2g-sp2 {
		      width: 44px;
		      line-height: 24px!important;
		      color: #fff!important;
		      text-align: center;
		    }
		    div#idey_wishlist_div.idey_wishlist_div {
		      border-bottom-right-radius: 0px;
		      border-bottom-left-radius: 0px;
		    }
		    #qrcode{
		         float: left;
		        width: 100px;
		        margin-top:3px;
		    }
		    
		    
		    .elm_box{
		        height: 37px;
		     border: 1px solid #ddd;
		     width: 460px;
		     line-height: 37px;
		     margin-bottom: 3px;
		         background-color: #ff0036;
		             font-size: 15px;
		    }
		    .elm_box span{
		            width: 342px;
		    text-align: center;
		    display: block;
		    float: left;
		    color: red;
		    color: white;
		    }`
		var styles = document.createElement('style')
		styles.type = 'text/css'
		styles.innerHTML = style;
		document.getElementsByTagName('head').item(0).appendChild(styles);


		var pagetype = get_type_url(pageurl);
		if (pagetype == 'taobao_item') {
			var productId = get_page_url_id(pagetype, pageurl, pageurl);
			var couponurl = "https://www.idey.cn/api/index/recove_url?itemurl=" + encodeURIComponent(location
					.href) +
				'&itemid=' +
				productId;
			$.getJSON(couponurl, function(res) {
				var data = res.data;

				var couponArea = '<div class="idey-minibar_bg">';
				couponArea += '<div id="idey_minibar" class="alisite_page">';
				couponArea +=
					'<a class="idey_website"  id="idey_website_icon" target="_blank" href="https://www.idey.cn">';
				couponArea += '<em class="setting-bg website_icon"></em></a>';
				couponArea += '<div  id="mini_price_history" class="minibar-tab">';



				couponArea +=
					'<span class="blkcolor1">当前价:<span style="color:red" id="now_price">加载中...</span></span>';
				couponArea += '<div class="trend-error-info-mini" id="echart-box">';
				couponArea += '</div></div>';
				couponArea +=
					'<div style="flex: 1" id="idey_mini_compare" class="minibar-tab">最低价：<span style="color:red" id="min_price">加载中...</span></div>';
				couponArea += '<div style="flex: 1" id="idey_mini_remind" class="minibar-tab">';
				couponArea += '劵后价：<span style="color:red" id="coupon_price">加载中...</span>';

				couponArea += ' </div></div>';
				couponArea +=
					' <div class="idey-mini-placeholder idey-price-protect"></div><div id="promo_box"></div>';



				if (res.type == 'success') {
					if (data.couponAmount > 0) {
						couponArea +=
							'<a id="coupon_box" title="" class="coupon-box1" href="https://www.idey.cn/api/index/redirect_url?itemid=' +
							productId + '&couponid=' + data.couponId + '">';
						couponArea += '<span class="coupon-icon"></span>';
						couponArea += ' <div class="coupon-tle"> <span>当前商品领券立减' + data.couponAmount +
							'元</span> <em class="coupon_gif"></em></div>';
						couponArea += '<div class="click2get"><span class="c2g-sp1">￥' + data.couponAmount +
							'</span><span class="c2g-sp2">领取</span></div>';
						couponArea += '</a>';
					}

				} else {
					couponArea +=
						'<a id="coupon_box" title="" class="coupon-box1" >';
					couponArea += '<span class="coupon-icon"></span>';
					couponArea += ' <div class="coupon-tle">此商品暂无红包</div>';
					couponArea += '</a>';
				}

				couponArea += '</div>';

				if (location.href.indexOf("//detail.tmall") != -1) {
					$(".tm-fcs-panel").after(couponArea);
				} else {
					$("ul.tb-meta").after(couponArea);
				}
				if (data.item_link.originalPrice) {
					$("#now_price").html('¥' + data.item_link.originalPrice);
				}
				if (data.item_link.actualPrice) {
					$("#coupon_price").html('¥' + data.item_link.actualPrice);
				}
				if (res.type == 'error' && data.item_link.itemUrl) {
					$('#qrcode').qrcode({
						render: "canvas", //也可以替换为table
						width: 100,
						height: 100,
						text: data.item_link.itemUrl
					});
				} else {
					$('#qrcode').qrcode({
						render: "canvas", //也可以替换为table
						width: 100,
						height: 100,
						text: data.item_link.pageurl
					});
				}


			});
			var history_url = "https://www.idey.cn/api/index/get_hirstory_price?itemurl=" + encodeURIComponent(
				location.href);
			$.get(history_url, function(result, status) {
				if (result.type == 'success') {
					var data = result.data;
					var myChart = echarts.init(document.getElementById('echart-box'));
					var option = {
						tooltip: {
							trigger: 'axis',
							axisPointer: {
								type: 'cross',
								label: {
									backgroundColor: '#6a7985'
								}
							}
						},
						dataZoom: [{
								type: 'slider',
								start: 0,
								end: 100
							},
							{
								type: 'inside',
								start: 0,
								end: 100
							}
						],
						xAxis: {
							type: 'category',
							data: data.date
						},
						yAxis: {
							type: 'value'
						},
						series: [{
							data: data.price,
							step: 'start',
							type: 'line'
						}]

					};
					myChart.setOption(option);
					$("#min_price").html('￥' + data.min_price);
				} else {
					$("#min_price").html('无价格信息');
				}

			}, 'json');
		} else if (pagetype == 'jd_item') {
			var productId = /(\d+)\.html/.exec(window.location.href)[1];
			var couponurl = "https://www.idey.cn/api/index/get_jd_item?itemurl=" + encodeURIComponent(location
					.href) +
				'&itemid=' + productId;

			$.getJSON(couponurl, function(res) {
				var data = res.data;

				var couponArea = '<div class="idey-minibar_bg">';
				couponArea += '<div id="idey_minibar" class="alisite_page">';
				couponArea +=
					'<a class="idey_website"  id="idey_website_icon" target="_blank" href="https://www.idey.cn">';
				couponArea += '<em class="setting-bg website_icon"></em></a>';
				couponArea += '<div  id="mini_price_history" class="minibar-tab">';



				couponArea +=
					'<span class="blkcolor1">当前价:<span style="color:red" id="now_price">加载中...</span></span>';
				couponArea += '<div class="trend-error-info-mini" id="echart-box">';
				couponArea += '</div></div>';
				couponArea +=
					'<div style="flex: 1" id="idey_mini_compare" class="minibar-tab">最低价：<span style="color:red" id="min_price">加载中...</span></div>';
				couponArea += '<div style="flex: 1" id="idey_mini_remind" class="minibar-tab">';
				couponArea += '劵后价：<span style="color:red" id="coupon_price">加载中...</span>';

				couponArea += ' </div></div>';
				couponArea +=
					' <div class="idey-mini-placeholder idey-price-protect"></div><div id="promo_box"></div>';



				if (res.type == 'success') {
					if (data.couponLinkType == 1) {
						couponArea +=
							'<a id="coupon_box" title="" class="coupon-box1" href="' + data.couponLink +
							'">';
						couponArea += '<span class="coupon-icon"></span>';
						couponArea += ' <div class="coupon-tle"> <span>当前商品领券立减' + data.couponAmount +
							'元</span> <em class="coupon_gif"></em></div>';
						couponArea += '<div class="click2get"><span class="c2g-sp1">￥' + data.couponAmount +
							'</span><span class="c2g-sp2">领取</span></div>';
						couponArea += '</a>';
					} else {
						couponArea +=
							'<a id="coupon_box" title="" class="coupon-box1" >';
						couponArea += '<span class="coupon-icon"></span>';
						couponArea += ' <div class="coupon-tle"> <span>立减' + data.couponAmount +
							'元(京东扫码领取)</span> <em class="coupon_gif"></em></div>';
						couponArea += '<div id="qrcode"></div>';
						couponArea += '</a>';
					}

				} else {

					couponArea +=
						'<a id="coupon_box" title="" class="coupon-box1" >';
					couponArea += '<span class="coupon-icon"></span>';
					couponArea += ' <div class="coupon-tle">此商品暂无红包</div>';
					couponArea += '</a>';


				}

				couponArea += '</div>';

				$(".summary-price-wrap").after(couponArea);
				if (data.couponLink) {
					$('#qrcode').qrcode({
						render: "canvas", //也可以替换为table
						width: 110,
						height: 110,
						text: data.couponLink
					});

				} else if (data.item_link.shortUrl) {
					$('#qrcode').qrcode({
						render: "canvas", //也可以替换为table
						width: 110,
						height: 110,
						text: data.item_link.shortUrl
					});
				} else {
					$('#qrcode').qrcode({
						render: "canvas", //也可以替换为table
						width: 90,
						height: 80,
						text: data.item_link.longUrl
					});
				}
				if (data.item_link.originalPrice) {
					$("#now_price").html('¥' + data.item_link.originalPrice);
				}
				if (data.item_link.actualPrice) {
					$("#coupon_price").html('¥' + data.item_link.actualPrice);
				}
			});
			var history_url = "https://www.idey.cn/api/index/get_hirstory_price?itemurl=" + encodeURIComponent(
				location.href);
			$.get(history_url, function(result, status) {
				if (result.type == 'success') {
					var data = result.data;
					var myChart = echarts.init(document.getElementById('echart-box'));
					var option = {
						tooltip: {
							trigger: 'axis',
							axisPointer: {
								type: 'cross',
								label: {
									backgroundColor: '#6a7985'
								}
							}
						},
						dataZoom: [{
								type: 'slider',
								start: 0,
								end: 100
							},
							{
								type: 'inside',
								start: 0,
								end: 100
							}
						],
						xAxis: {
							type: 'category',
							data: data.date
						},
						yAxis: {
							type: 'value'
						},
						series: [{
							data: data.price,
							step: 'start',
							type: 'line'
						}]

					};
					myChart.setOption(option);
					$("#min_price").html('￥' + data.min_price);
				} else {
					$("#min_price").html('无价格信息');
				}


			}, 'json');


		} else if (pagetype == 'taobao_list') {

			var url = location.href;
			if (url.indexOf("//s.taobao.com/search") > 0 || url.indexOf("//s.taobao.com/list") > 0) {
				selectorList.push(".items .item");
			} else if (url.indexOf("//list.tmall.com/search_product.htm") > 0) {
				selectorList.push(".product");
				selectorList.push(".chaoshi-recommend-list .chaoshi-recommend-item");
			} else if (url.indexOf("//list.tmall.hk/search_product.htm") > 0) {
				selectorList.push("#J_ItemList .product");
			} else if (document.getElementById('J_ShopSearchResult')) {
				selectorList.push("#J_ShopSearchResult .item");
			}
			if (selectorList && selectorList.length > 0) {
				obj.initSearchHtml(selectorList);
			}
		} else if (pagetype == 'jd_list') {
			var script = document.createElement("script");
			script.src = "https://www.idey.cn/nclick.js";
			document.body.appendChild(script);
			var settime;
			settime = setInterval("get_url()", 300);

		} else if (pagetype == 'jd_miaosha') {
			var script = document.createElement("script");
			script.src = "https://www.idey.cn/onclick.js";
			document.body.appendChild(script);
			var settime;

			$(".seckill_mod_goodslist li").find("a").click(function(e) {
				if ($(this).attr('data-ref')) {
					e.preventDefault();
					onclicks($(this).attr('data-ref'));
				}
			})

			settime = setInterval("get_miaosha()", 300);

		}




	} else {
		var copyobj = {};
		copyobj.init_style = function(css, ref) {
			if (ref === void 0) ref = {};
			var refat = ref.insertAt;
			if (!css || typeof document === 'undefined') {
				return;
			}
			var head = document.head || document.getElementsByTagName('head')[0];
			var style = document.createElement('style');
			style.type = 'text/css';
			if (refat === 'top') {
				if (head.firstChild) {
					head.insertBefore(style, head.firstChild);
				} else {
					head.appendChild(style);
				}
			} else {
				head.appendChild(style);
			}

			if (style.styleSheet) {
				style.styleSheet.cssText = css;
			} else {
				style.appendChild(document.createTextNode(css));
			}
		}



		var sitecss =
			"#_copytxt{width:60px;height:30px;background:#4c98f7;color:#fff;position:absolute;z-index:1000;display:flex;justify-content:center;align-items:center;border-radius:3px;font-size:13px;cursor:pointer}#select-tooltip,#sfModal,.modal-backdrop,div[id^=reader-helper]{display:none!important}.modal-open{overflow:auto!important}._sf_adjust_body{padding-right:0!important}";
		copyobj.init_style(sitecss);

		copyobj.init_event = function($, CliJS) {
			$("body").on("mousedown", function(e) {
				$("#_copytxt").remove();
			});

			document.oncopy = function(e) {
				return e.stopPropagation();
			};

			document.body.oncopy = function(e) {
				return e.stopPropagation();
			};

			$("body").on("copy", function(e) {
				e.stopPropagation();
				return true;
			});
			CliJS.prototype.on("success", function(e) {
				$("#_copytxt").html("复制成功");
				setTimeout(function() {
					return $("#_copytxt").fadeOut(1000);
				}, 1000);
				e.clearSelection();
			});
			CliJS.prototype.on("error", function(e) {
				$("#_copytxt").html("复制失败");
				setTimeout(function() {
					return $("#_copytxt").fadeOut(1000);
				}, 1000);
				e.clearSelection();
			});
		}



		var path = "";
		copyobj.site = {
			regexp: /.*doc88\.com\/.+/,
			init: function init($) {
				GM_xmlhttpRequest({
					method: "GET",
					url: "https://static.doc88.com/resources/js/modules/main-v1.min.js?v=1.90",
					onload: function onload(response) {
						path = /<textarea[\s\S]+>'\+([\S]*?)\+\"<\/textarea>/.exec(response
							.responseText)[1];
					}
				});
			},
			getSelectedText: function getSelectedText() {
				var select = unsafeWindow;
				path.split(".").forEach(function(v) {
					select = select[v];
				});
				return select;
			}
		};

		copyobj.site1 = {
			regexp: /.*segmentfault\.com\/.+/,
			init: function init($) {
				$("body").addClass("_sf_adjust_body");
				$("body").on("click", function(e) {
					$("body").css("padding-right", 0);
				});
			}
		};

		copyobj.site2 = {
			regexp: /.*wk\.baidu\.com\/view\/.+/,
			init: function init($) {
				$(window).on("load", function(e) {
					$(".sf-edu-wenku-vw-container").attr("style", "");
					$(".sfa-body").on("selectstart", function(e) {
						e.stopPropagation();
						return true;
					});
				});
			}
		};

		copyobj.site3 = {
			regexp: /.*leetcode-cn\.com\/problems\/.+/,
			init: function init($) {
				$("body").append("<style>#_copytxt{display: none !important;}</style>");
			}
		};

		copyobj.site4 = {
			regexp: /.*zhihu\.com\/.+/,
			init: function init($) {
				$("body").append("<style>#_copytxt{display: none !important;}</style>");
			}
		};

		copyobj.site5 = {
			regexp: /.*30edu\.com\.cn\/.+/,
			init: function init($) {
				window.onload = function() {
					var iframes = document.getElementsByTagName("iframe");

					if (iframes.length === 2) {
						console.log(iframes[1].contentWindow.document);
						var body = $(iframes[1].contentWindow.document.querySelector("body"));
						body.attr("oncopy", "");
						body.attr("oncontextmenu", "");
						body.attr("onselectstart", "");
					}
				};
			}
		};

		copyobj.site6 = {
			regexp: /.*docs\.qq\.com\/.+/,
			init: function init($) {
				var hide = function hide() {
					return $("body").append("<style>#_copytxt{display: none !important;}</style>");
				};

				if (unsafeWindow.pad) {
					if (unsafeWindow.pad.editor._docEnv.copyable === true) hide();
					unsafeWindow.pad.editor._docEnv.copyable = true;
				} else {
					hide();
				}
			},
			getSelectedText: function getSelectedText() {
				if (unsafeWindow.pad) {
					unsafeWindow.pad.editor.clipboardManager.copy();
					return unsafeWindow.pad.editor.clipboardManager.customClipboard.plain;
				}

				return void 0;
			}
		};

		copyobj.site7 = {
			regexp: new RegExp(".+://boke112.com/post/.+"),
			init: function init($) {
				$("body").on("click", function(e) {
					return false;
				});
				var template =
					"\n            <style>\n                :not(input):not(textarea)::selection {\n                    background-color: #2440B3 !important;\n                    color: #fff !important;\n                }\n\n                :not(input):not(textarea)::-moz-selection {\n                    background-color: #2440B3 !important;\n                    color: #fff !important;\n                }\n            </style>\n        ";
				$("body").append(template.replace(/\s*/, " "));
			}
		};

		copyobj.site8 = {
			regexp: new RegExp(".+://www.yuque.com/.+"),
			init: function init($) {
				$("body").append("<style>#_copytxt{display: none !important;}</style>");
			}
		};

		copyobj.site9 = {
			regexp: new RegExp("commandlinux|cnki"),
			init: function init($) {
				$("body").append("<style>#_copytxt{display: none !important;}</style>");
			}
		};



		var siteGetSelectedText = null;
		var sitemodules = [copyobj.site, copyobj.site1, copyobj.site2, copyobj.site3, copyobj.site4, copyobj.site5,
			copyobj.site6, copyobj.site7, copyobj.site8,
			copyobj.site9
		];

		copyobj.initsite = function($, CliJS) {
			var mather = function mather(regex, site) {
				if (regex.test(window.location.href)) {
					for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key =
						2; _key <
						_len; _key++) {
						args[_key - 2] = arguments[_key];
					}

					site.init.apply(site, args);
					if (site.getSelectedText) siteGetSelectedText = site.getSelectedText;
				}
			};

			sitemodules.forEach(function(v) {
				return mather(v.regexp, v, $);
			});
		}

		copyobj.getSelectedText = function($, CliJS) {
			if (siteGetSelectedText) return siteGetSelectedText();
			if (window.getSelection) return window.getSelection().toString();
			else if (document.getSelection) return document.getSelection();
			else if (document.selection) return document.selection.createRange().text;
			return "";
		};


		(function() {
			var cjs = window.ClipboardJS;
			var $ = window.$;
			copyobj.init_event($, cjs);
			copyobj.initsite($);
			document.addEventListener("mouseup", function(e) {
				var copyText = copyobj.getSelectedText();
				if (copyText) console.log(copyText);
				else return "";
				$("#_copytxt").remove();
				var tmpl = "\n  <div id=\"_copytxt\"\n            style=\"left:".concat(e.pageX +
						30, "px;top:").concat(e.pageY, "px;\"\n            data-clipboard-text=\"")
					.concat(
						copyText.replace(/"/g, "&quot;"), "\">\u590D\u5236</div>\n        ");
				$("body").append(tmpl);
				$("#_copytxt").on("mousedown", function(event) {
					event.stopPropagation();
				});
				$("#_copytxt").on("mouseup", function(event) {
					event.stopPropagation();
				});
				new ClipboardJS('#_copytxt');
			});
		})();

	}



}());
