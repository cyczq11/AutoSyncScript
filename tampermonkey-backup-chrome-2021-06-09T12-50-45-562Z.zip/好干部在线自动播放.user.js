// ==UserScript==
// @name         好干部在线自动播放
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  省去手动点击
// @author       lidppp
// @match        https://www.sxgbxx.gov.cn/front/playkpoint/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var f = false
    function pl(){
        if(_player.j2s_resumeVideo){
            setTimeout(()=>{
                _player.j2s_resumeVideo()
                f = true
            },300)
        }
    }
    var Intval = setInterval(()=>{
        pl()
        if(f){
            clearInterval(Intval)
        }
    },200)
})();