// ==UserScript==
// @name        Steam历史最低价(支持外服，货币自动转换)
// @namespace   tea.pm
// @match       https://store.steampowered.com/app/*
// @require     https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js
// @grant       none
// @version     1.2.10
// @author      cljnnn
// @grant       GM.xmlHttpRequest
// @grant       GM.getValue
// @grant       GM.setValue
// @description 获取stream的历史最低价，支持当前币种，及参考币种。B站相关视频搜索。
// ==/UserScript==

function gmGet(name) {
    var theValue = GM.getValue(name);
    return theValue;
}

function gmSet(name, valuee) {
    GM.setValue(name, valuee);
}

let gameDescription = $("div.game_description_snippet").text();
let gameName = null;//gameDescription.match(/《(.*?)》/)
if (gameName != null) {
    gameName = gameName[1];
} else {
    gameName = $("div.apphub_AppName").text();
}
gameName = gameName.replace(/[®-]/g, '')
console.log(gameName);


function auto_price_callback() {
    let auto_price_enabled = document.getElementById("auto_price").checked
    gmSet('auto_price_enabled', auto_price_enabled);
    if (!auto_price_enabled) return;
    update_price();
}

function update_price() {
    let priceAction;
    let price;
    $("div.game_purchase_action div.game_purchase_action_bg").each(function (e) {
        priceAction = $(this);
        let thisPrice = priceAction.find("div.game_purchase_price,div.discount_final_price").text().trim();
        console.log("price:", thisPrice, thisPrice.match("\\d{2}$"));
        if (thisPrice.match("\\d{2}$") != null) {
            price = thisPrice.replace('.', '');
            return false;
        }
    });
    console.log(price);
    if (price === undefined) return;
    console.log("searching...");

    GM.xmlHttpRequest({
        method: "GET",
        url: steamdbUrl,
        synchronous: true,
        onload: function (response) {
            data = response.responseText;
            if (data.indexOf("tab-prices") == -1) {
                alert("无法从steamdb.info获取所需信息，可能需要通过验证码，验证后请返回并刷新本页面，即将前往！");
                window.open(steamdbUrl, "_blank");
                return;
            };
            // get the target: <tr>...</tr>
            let priceIdx = data.indexOf(price);
            if (priceIdx == -1) {
                return;
            }
            let trBeginIdx = data.lastIndexOf("<tr", priceIdx);
            let trEndIdx = data.indexOf("</tr>", priceIdx) + 5;
            let priceHtml = data.substring(trBeginIdx, trEndIdx);
            //alert(priceHtml);

            // get columns
            let jp = $('<div/>').html(priceHtml);
            let nowPrice = jp.find("td:nth-child(3)").text().trim();
            let discountBase = jp.find("td:nth-child(4)").text().trim();
            let lowestPrice = jp.find("td:nth-last-child(2)").text().trim();
            let lowestDate = jp.find("td:last").attr("title").trim();
            lowestDate = new Date(lowestDate).toLocaleDateString();
            console.log("discountBase:", discountBase);
            console.log("lowestPrice:", lowestPrice);
            console.log("nowPrice:", nowPrice);

            // handle "Base Price"
            if (nowPrice == "Base Price") {
                nowPrice = price;
                discountBase = "";
            } // base shop doesn't have this game.
            else if (!(discountBase.startsWith("+") || discountBase.startsWith("-"))) {
                discountBase = "";
            }
            else {
                discountBase = parseInt(discountBase.match("[\-\\d\.]+"));
                if (isNaN(discountBase)) discountBase = "";
                else {
                    if (discountBase >= 0) discountBase = "+" + discountBase;
                    discountBase += "%";
                }
            }
            // set style, red if it's lowestPrice.
            let style = "";
            let lowestStyle = "";
            // not have lowest ever
            let isTrueLowestPrice = jp.find("td:last").text().indexOf("at") != -1;
            if (!isTrueLowestPrice && nowPrice == lowestPrice) {
                lowestPrice = "";
                lowestDate = "没有";
            }
            if (nowPrice == lowestPrice) {
                lowestDate = "现在";
                style = "color:red";
                lowestStyle = "color:red";
            } else {
                lowestStyle = "color:yellow";
            }
            // don't show nowPrice if it's same as price.
            if (price == nowPrice) {
                nowPrice = "";
            }
            // discountBaseHtml, gray the buy button if discountBase>0
            let discountBaseHtml = "";
            if (discountBase != "") {
                if (discountBase.startsWith("+")) {
                    priceAction.find(".btn_addtocart").attr("style", "background-color:gray");
                    priceAction.find("a.btn_green_steamui").removeClass("btn_green_steamui");
                }
                discountBaseHtml = String.raw`<div class="discount_pct">${discountBase}</div>`;
            }

            priceAction.prepend(String.raw`
<div class="discount_prices"><div class="discount_original_price" style="${lowestStyle}">${lowestPrice}</div><div class="discount_final_price" style="${style}">${nowPrice}</div></div>
${discountBaseHtml}
<a class="btn_blue_steamui btn_medium" href="${steamdbUrl}" target="_blank"> <span>${lowestDate}</span> </a>
`);
        }
    });
};


let steamdbUrl = "https://steamdb.info/app/" + window.location.href.match('[0-9]+');
$("div.queue_actions_ctn").append(String.raw`
<a href="#app_reviews_hash" class="btnv6_blue_hoverfade btn_medium"><span>评测</span></a>
<a href="${steamdbUrl}" target="_blank" class="btnv6_blue_hoverfade btn_medium"><span>价格</span></a>
<a href="https://search.bilibili.com/video?keyword=${gameName}" target="_blank" class="btnv6_blue_hoverfade btn_medium"><span>B站</span></a>
<input type="checkbox" id="auto_price" name="auto_price">自动获取</input>
`);
$("div.queue_actions_ctn div:last").appendTo($("div.queue_actions_ctn"));

(async () => {
    let auto_price_enabled = (await gmGet('auto_price_enabled')) == true;
    document.getElementById("auto_price").checked = auto_price_enabled;
    if (auto_price_enabled) {
        update_price();
    }
})();

document.getElementById("auto_price").addEventListener('click', auto_price_callback, false);