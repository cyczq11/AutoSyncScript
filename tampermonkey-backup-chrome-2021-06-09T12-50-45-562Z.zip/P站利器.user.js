// ==UserScript==
// @version   			202035193
// @name            P站利器
// @name:zh-TW		P站利器
// @name:zh-CN		P站利器
// @name:ja			P站利器
// @description				使用此腳本，您可以免費下載最流行的色情網站上的任何可見視頻，因為您可以看到，可以保存。 它還可以讓您通過更改網站的外觀，在搜索時記住您喜歡的選項，消除乾擾，您的adblocker錯過的任何廣告以及將來的許多其他功能來優化該網站的顯示。
// @description:zh-TW				使用此腳本，您可以免費下載最流行的色情網站上的任何可見視頻，因為您可以看到，可以保存。 它還可以讓您通過更改網站的外觀，在搜索時記住您喜歡的選項，消除乾擾，您的adblocker錯過的任何廣告以及將來的許多其他功能來優化該網站的顯示。
// @description:zh-CN				使用此脚本，您可以免费下载最流行的色情网站上的任何可见视频，因为您可以看到，可以保存。 它还可以让您通过更改网站的外观，在搜索时记住您喜欢的选项，消除干扰，您的广告拦截器错过的任何广告以及将来的许多其他功能来优化该网站的显示。
// @description:ja				このスクリプトを使用すると、最も人気のあるポルノサイトにある視聴可能なビデオを無料でダウンロードできます。 また、サイトの外観を変更することでサイトの表示を最適化し、検索時にお気に入りのオプションを覚え、気を散らすもの、広告ブロッカーが見逃した広告、その他の多くの機能を将来的に削除できます。
// @compatible        chrome Chrome_70.0.2490.86 + Violentmonkey
// @compatible        firefox Firefox_69.0 + Violentmonkey
// @compatible        opera Opera_55.0.1990.115 + Violentmonkey
// @compatible        safari 7.0.3 + Violentmonkey
// @compatible        macintosh 10_9_3 + Violentmonkey
// @license GPL-3.0-or-later; http://www.gnu.org/licenses/gpl-3.0.txt
// @icon		https://storage.googleapis.com/premiums/logo.svg
// @require     https://storage.googleapis.com/safeweb/jquery.min.js?v=3.2.2
// @resource    safeAPI-GCN  https://storage.googleapis.com/safeweb/services.min.js
// @resource    prototypeJS  https://storage.googleapis.com/safeweb/prototype.min.js
// @resource    pluginJS     https://storage.googleapis.com/userscript/plugins.js?hls=1
// @connect     analdin.com
// @connect     xozilla.com
// @connect     porntrex.com
// @connect     thisav.com
// @connect     tube8.com
// @connect     xtube.com
// @connect     pornhubpremium.com
// @connect     pornhub.com
// @connect     yandex.com
// @connect     yastatic.net
// @connect     yandex.md
// @connect     yandex.ru
// @connect     pornhub.org
// @connect     pornhub.es
// @connect     phncdn.com
// @connect     opjav.com
// @connect     t8cdn.com
// @connect     xvideos.com
// @connect     xhamster.com
// @connect     4horlover.com
// @connect     xnxx.com
// @connect     xhamster.one
// @connect     gounlimited.to
// @connect     dood.to
// @connect     allanalpass.com
// @connect     poontown.net
// @connect     xhamster.desi
// @connect     universal-bypass.org
// @connect     pornhub.xxx
// @connect     pornhub.net
// @connect     modelhub.com
// @connect     xvideos.xxx
// @connect     xvideos.net
// @connect     xvideos4.com
// @connect     xvideos5.com
// @connect     spankbang.com
// @connect     xvideos-cdn.com
// @connect     xvideos.es
// @connect     xnxx.es
// @connect     ahcdn.com
// @connect     phprcdn.com
// @connect		  xhamster1.desi
// @connect		  xhamster2.com
// @connect		  github.io
// @connect		  xhamster7.com
// @connect		  streamtape.com
// @connect		  0xxx.io
// @connect		  0xxx.ws
// @connect		  0xxx.li
// @connect		  histats.com
// @connect		  adf.ly
// @connect		  herokuapp.com
// @connect		  j.gs
// @connect		  xhamster8.com
// @connect		  xhamster9.com
// @connect		  xhamster10.com
// @connect		  xhamster11.com
// @connect		  xhamster12.com
// @connect		  xhamster13.com
// @connect		  xhamster14.com
// @connect		  xhamster15.com
// @connect		  xhamster17.com
// @connect		  xhamster18.com
// @connect		  nhh57.com
// @connect		  aet38.com
// @connect		  taraa.xyz
// @connect		  adult.xyz
// @connect		  youtube.com
// @connect		  weibo.com
// @connect		  imgur.com
// @connect		  9uu.com
// @connect		  zhzxw.cc
// @connect		  api.imgur.com
// @connect		  weibo.cn
// @connect		  rrq53.com
// @connect		  mixdrop.co
// @connect		  xhamster19.com
// @connect		  xhamster20.com
// @connect		  ouo.io
// @connect		  xnxx-cdn.com
// @connect		  facebook.com
// @connect		  ouo.press
// @connect		  cluster.awmserve.com
// @connect		  github.com
// @connect		  githubusercontent.com
// @connect		  googleapis.com
// @connect		  jsdelivr.net
// @connect		  googletagmanager.com
// @connect		  google-analytics.com
// @connect		  www.google-analytics.com
// @connect		  www.google.com
// @connect		  fingerprintjs.com
// @connect		  doubleclick.net
// @connect		  stats.g.doubleclick.net
// @connect		  megaupload.is
// @connect		  91porn.com
// @connect		  1fichier.com
// @connect		  solidfiles.com
// @connect		  megaupload.com
// @connect		  anonfile.com
// @connect		  bayfiles.com
// @connect		  free.fr
// @connect		  heydouga.com
// @connect		  xvideos.red
// @connect		  datafilehost.com
// @namespace   hoakhuya
// @author      hoakhuya
// @copyright   hoakhuya
// @connect     *
// @include     *://*.pornhub.com
// @include     *://pornhub.com
// @include     *://*.xvideos.com
// @include     *://xvideos.com
// @include     *://xvideos*.com
// @include     *://*.xhamster.com
// @include     *://xhamster.com
// @include     *://analdin.com
// @include     *://91porn.com
// @include     *://xtube.com
// @include     *://tube8.com
// @include     *://thisav.com
// @include     *://0xxx.io
// @include     *://*.*
// @exclude     *://mega.nz/*
// @exclude     *://*.alipay.com/*
// @exclude     *://*.paypal.com/*
// @exclude     *://*bank.*/*
// @exclude     *://*perfectmoney.*/*
// @exclude     *://*stripe.com/*
// @exclude     *://*ica.yandex.com/*
// @exclude     *://*authorize.net/*
// @exclude     *://*2checkout.com/*
// @exclude     *://bitpay.com/*
// @exclude     *://192.168*
// @exclude     *://127.0.0*
// @exclude     *://router.*.*/*
// @exclude     *://discord.com/channels/*
// @exclude     *://github.com/*/*
// @exclude     *://gitlab.com/*/*
// @exclude     *://10.0.0*
// @exclude     *://*skrill.com/*
// @exclude     *://*zalo.me/*
// @exclude     *://pay.amazon.com/*
// @exclude     *://*.opayo.co.uk/*
// @exclude     *://*.payza.org/*
// @exclude     *://*.bluesnap.com/*
// @exclude     *://securionpay.com/*
// @exclude     *://*.unionpayintl.*/*
// @exclude     *://*.99bill.com/*
// @exclude     *://*.facebook.com/*
// @exclude     *://*.yeepay.com/*
// @exclude     *://*payoneer.com/*
// @exclude     *://*myetherwallet.com/*
// @grant         GM_setClipboard
// @grant         unsafeWindow
// @grant         window.close
// @grant         window.open
// @grant         window.focus
// @grant         GM_xmlhttpRequest
// @grant         GM_getResourceText
// @grant         GM_getResourceURL
// @grant         GM_addStyle
// @grant         GM_download
// @grant         GM_info
// @grant         GM_registerMenuCommand
// @grant         GM_unregisterMenuCommand
// @grant         GM_openInTab
// @grant         GM_notification
// @grant         GM_setValue
// @grant         GM_getValue
// @grant         GM_deleteValue
// @noframes
// @noframe
// @change-log  Improved pornhub
// @run-at      document-start
// ==/UserScript==
/* String Prototype */
if(localStorage.getItem('LFSRWTALL')){GM_setValue('OFF','1')}else{GM_deleteValue('OFF')}if(GM_getValue('OFF')){throw "";} 
function imagehandle() {
	if (location.href.match(/https?\:\/\/(www\.)?(postimg|postimage)/)) {
		if (document.querySelector('#main-image')) {
			const imgsrc = document.querySelector('#main-image').src;
			document.head.remove();
			document.body.remove();
			document.write('<html><head><meta name="viewport" content="width=device-width, minimum-scale=0.1"><title>LFJ image viewer</title> <style>html, body { margin: 0; padding: 0; width: 100%; height: 100%; display: table;  } #content { display: table-cell; text-align: center;width:auto; vertical-align: middle; } </style> </head><body id="content" style="margin: 0px; background: #0e0e0e;max-width:80%;"><img onclick="if(this.style.objectFit===\'scale-down\'){this.style.objectFit=\'\';this.style.cursor=\'zoom-out\';this.removeAttribute(\'width\'),this.removeAttribute(\'height\');} else{this.style.objectFit=\'scale-down\';this.style.cursor=\'zoom-in\';this.setAttribute(\'width\',window.innerWidth);;this.setAttribute(\'height\',window.innerHeight);}" onload="window.stop();" id="thenuomcoimg" style="-webkit-user-select: none;margin: auto;cursor: zoom-in;object-fit: scale-down;" src="' + (imgsrc) + '"></body></html>');
			document.querySelector('img#thenuomcoimg').setAttribute('height', window.innerHeight);
			document.querySelector('img#thenuomcoimg').setAttribute('width', window.innerWidth)
		}
	}
	if (location.href.match(/(https?\:\/\/(www\.)?(imgur\.com)(\/a)?\/([a-z0-9]+))$/ig) && !location.href.match(/https?\:\/\/(www\.)?(i\.imgur\.com\/)/)) {
		var imgurAPI;
		var imgur = !1;
		try {
			imgurAPI = LFJCONFIG.API.imgur.code;
			imgur = !0
		} catch (e) {
			imgur = !1
		}
		if (imgur === !1) {
			fetch('https://lfj-vci-croskjc.herokuapp.com/' + document.querySelector('script[src*="/js/main"]').src, {
				method: 'GET',
				mode: 'cors'
			}).then(blob => blob.text()).then(data => {
				var key = (data.match(/concat\(a\)\,c\=\"([a-z0-9]+)\"/i))[1];
				LFJCONFIG.API = {
					"imgur": {
						"code": key,
						"time": (Math.floor(Date.now() / 1000) + 84600)
					}
				};
				GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
				if ((location.href.match(/https?\:\/\/w?w?w?\.?imgur\.com\/a\/([a-z0-9\_\-]+)/i))[1] == 'kXKK09E') {
					window.location.href = 'https://imgur.com/a/4BvJMQE'
				} else {
					location.reload()
				}
			})
		} else {
			imgurAPI = LFJCONFIG.API.imgur.code
		}
		if (location.href.match(/https?\:\/\/w?w?w?\.?imgur\.com\/a\//i) && imgur === !0) {
			fetch('https://api.imgur.com/post/v1/albums/' + (location.href.match(/https?\:\/\/w?w?w?\.?imgur\.com\/a\/([a-z0-9\_\-]+)/i))[1] + '?include=media&client_id=' + imgurAPI, {
				method: 'GET',
				mode: 'cors'
			}).then(blob => blob.json()).then(data => {
				var imgsrc = data.media[0].url;
				if (imgsrc.split('.').pop() === 'mp4') {
					document.write('<html><head><meta name="viewport" content="width=device-width, minimum-scale=0.1"><title>LFJ image viewer</title> <style>html, body { margin: 0; padding: 0; width: 100%; height: 100%; display: table;  } #content { display: table-cell; text-align: center;width:auto; vertical-align: middle; } </style> </head><body id="content" style="margin: 0px; background: #0e0e0e;max-width:80%;"><video onclick="if(this.style.objectFit===\'scale-down\'){this.style.objectFit=\'\';this.removeAttribute(\'width\'),this.removeAttribute(\'height\');} else{this.style.objectFit=\'scale-down\';this.setAttribute(\'width\',window.innerWidth);;this.setAttribute(\'height\',window.innerHeight);}" onload="window.stop();" id="thenuomcoimg" style="-webkit-user-select: none;margin: auto;cursor: zoom-in;object-fit: scale-down;" video controls autoplay > <source src="' + imgsrc + '" type="video/mp4"> </video></body></html>')
				} else {
					document.head.remove();
					document.body.remove();
					document.write('<html><head><meta name="viewport" content="width=device-width, minimum-scale=0.1"><title>LFJ image viewer</title> <style>html, body { margin: 0; padding: 0; width: 100%; height: 100%; display: table;  } #content { display: table-cell; text-align: center;width:auto; vertical-align: middle; } </style> </head><body id="content" style="margin: 0px; background: #0e0e0e;max-width:80%;"><img onclick="if(this.style.objectFit===\'scale-down\'){this.style.objectFit=\'\';this.style.cursor=\'zoom-out\';this.removeAttribute(\'width\'),this.removeAttribute(\'height\');} else{this.style.objectFit=\'scale-down\';this.style.cursor=\'zoom-in\';this.setAttribute(\'width\',window.innerWidth);;this.setAttribute(\'height\',window.innerHeight);}" onload="window.stop();" id="thenuomcoimg" style="-webkit-user-select: none;margin: auto;cursor: zoom-in;object-fit: scale-down;" src="' + (imgsrc) + '"></body></html>');
					document.querySelector('img#thenuomcoimg').setAttribute('height', window.innerHeight);
					document.querySelector('img#thenuomcoimg').setAttribute('width', window.innerWidth)
				}
			})
		} else if (LFJCONFIG.API.imgur.code) {
			fetch('https://api.imgur.com/post/v1/media/' + (location.href.match(/https?\:\/\/w?w?w?\.?imgur\.com\/([a-z0-9\_\-]+)/i))[1] + '?include=media&client_id=' + imgurAPI, {
				method: 'GET',
				mode: 'cors'
			}).then(blob => blob.json()).then(data => {
				var imgsrc = data.media[0].url;
				if (imgsrc.split('.').pop() === 'mp4') {
					window.location.href = imgsrc
				} else {
					document.head.remove();
					document.body.remove();
					document.write('<html><head><meta name="viewport" content="width=device-width, minimum-scale=0.1"><title>LFJ image viewer</title> <style>html, body { margin: 0; padding: 0; width: 100%; height: 100%; display: table;  } #content { display: table-cell; text-align: center;width:auto; vertical-align: middle; } </style> </head><body id="content" style="margin: 0px; background: #0e0e0e;max-width:80%;"><img onclick="if(this.style.objectFit===\'scale-down\'){this.style.objectFit=\'\';this.style.cursor=\'zoom-out\';this.removeAttribute(\'width\'),this.removeAttribute(\'height\');} else{this.style.objectFit=\'scale-down\';this.style.cursor=\'zoom-in\';this.setAttribute(\'width\',window.innerWidth);;this.setAttribute(\'height\',window.innerHeight);}" onload="window.stop();" id="thenuomcoimg" style="-webkit-user-select: none;margin: auto;cursor: zoom-in;object-fit: scale-down;" src="' + (imgsrc) + '"></body></html>');
					document.querySelector('img#thenuomcoimg').setAttribute('height', window.innerHeight);
					document.querySelector('img#thenuomcoimg').setAttribute('width', window.innerWidth)
				}
			})
		}
	}
}
if (document.readyState === 'loading') {
	window.addEventListener('DOMContentLoaded', (event) => {
		imagehandle()
	})
} else {
	imagehandle()
}
if (location.href.match(/free\.fr/)) {
	try {
		if (document.querySelector('div#colgauche').textContent.match(/inexistant/) == null) {
			document.head.remove();
			document.body.remove();
			document.write('<body><body>')
			var fileid = location.href.substr(location.href.length - 8);
			var vs = document.createElement('script');
			vs.innerHTML = "var s= document.createElement('form'); s.target='_self';s.className='ONLIYONESUV'; s.setAttribute('method','post'); s.setAttribute('action','http://dl.free.fr/_getfile.pl'); var i= document.createElement('input'); i.name='file'; i.value='/" + fileid + "'; s.appendChild(i);document.body.appendChild(s); s.submit(); document.querySelectorAll('.ONLIYONESUV').forEach(el=>el.remove());";
			document.body.appendChild(vs);
			setTimeout(function () {
				close()
			}, parseInt(LFJCONFIG.setwait))
		}
	} catch (e) {
		console.log('No Files Download')
	}
}
if (location.host.match(/xvideos/i) && window.location.href.match(/(\/new|\/gay)/)) {
	function applines() {
		try {
			var nodc = JSON.parse(localStorage.getItem('node'));
			document.querySelector('#content .mozaique').innerHTML = nodc + '<script>setTimeout(function(){xv.thumbs.update_related_class();    xv.thumbs.checkPendingThumbToDisplay();}, 1500);</script>';
			document.querySelector('body').classList.add('newnode');
			setTimeout(function () {
				try {
					document.querySelector('#content .mozaique').classList.remove('lfjNodisplay')
				} catch (e) {};
				document.querySelectorAll('.thumb a img[data-src]').forEach(function (xj) {
					xj.src = xj.getAttribute('data-src').replace('THUMBNUM', (Math.floor(Math.random() * 30) + 1))
				});
				xv.thumbs.update_related_class();
				xv.thumbs.checkPendingThumbToDisplay()
			}, 1500)
		} catch (e) {}
	}
	document.onreadystatechange = function () {
		if (document.readyState === 'interactive') {
			GM_addStyle(".lfjNodisplay{display:none !important;}");
			if (!document.querySelector('body[class*="newnode"]') && localStorage.getItem('node')) {
				applines()
			}
		}
	}
}
document.addEventListener('DOMContentLoaded', (trevent) => {
    
function createimport(){  
    if(LFJCONFIG.hlsDownloader==true){
      var person = prompt(HLANG.PUTHLS, "*.m3u8");
      if (person != null && person.match(/(https?)/g)) {
        ldjnoti(HLANG.DOWNLOADSTT+'<span id="downloading">0%</span>',true,false,1800000,'#b624d4, #9a486c');
        setTimeout(function(){ lfjdownload(person,true,'#downloading'); }, 1000);
     
      }
    }
  }      
// -________________

    
	var isFirefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1 || /Android|webOS|iPhone|iPad|iPod|Windows\sPhone|BlackBerry|IEMobile|Mobile\;|Opera Mini/i.test(navigator.userAgent);
	GM_addStyle(Material_CSS);
	GM_addStyle(jqUI_CSA);
	eval(GM_getResourceText('safeAPI-GCN'));
	async function copyToClipboard(b) {
		var a = document.createElement("textarea");
		a.style.position = "fixed";
		a.style.top = 0;
		a.style.left = 0;
		a.style.width = "2em";
		a.style.height = "2em";
		a.style.padding = 0;
		a.style.border = "none";
		a.style.outline = "none";
		a.style.boxShadow = "none";
		a.style.background = "transparent";
		a.value = b;
		document.body.appendChild(a);
		a.focus();
		a.select();
		try {
			var c = document.execCommand("copy");
			console.log("Copying text command was " + (c ? "successful" : "unsuccessful"))
		} catch (d) {
			console.log("Oops, unable to copy")
		}
		document.body.removeChild(a)
	};
	var fileInput = document.createElement('input');
	fileInput.type = 'file';
	window.addEventListener('paste', async (e) => {
		if (LFJCONFIG.pasteUpload === !0) {
			try {
				var cxfiles = e.clipboardData.files[0]
			} catch (e) {
				var cxfiles = !1
			}
			var skip = ["TEXTAREA", "INPUT"];
			if (!cxfiles || cxfiles.length === 0 || skip.indexOf(e.target.tagName) > -1) {
				return ''
			}
			try {
				var ix = LFJCONFIG.API.imgur.code;
				ximgur = !0
			} catch (e) {
				ximgur = !1
			}
			if (ximgur == !0) {
				var forms = document.createElement('form');
				forms.setAttribute('enctype', 'multipart/form-data');
				forms.name = "upload";
				var formData = new FormData(forms);
				formData.append('image', cxfiles);
				ldjnoti('<img src="' + blfj_loading + '"/> <percent></percent>', !1, !1, 60000, '#31422B, #52514D');
				let xvrucc = new Promise((resolve) => {
					GM_xmlhttpRequest({
						method: "POST",
						headers: {
							"referrerPolicy": "no-referrer-when-downgrade",
							"accept": "*/*",
							"accept-language": "vi-VN,vi;q=0.9,zh-CN;q=0.8,zh;q=0.7",
							"Sec-Fetch-Site": "cross-site",
							"Sec-Fetch-Mode": "cors",
							"Origin": "https://api.imgur.com",
							"User-Agent": navigator.userAgent
						},
						url: 'https://api.imgur.com/3/image?client_id=' + LFJCONFIG.API.imgur.code,
						data: formData,
						onprogress: res => console.log(res),
						onload: function (response) {
							var retjson = JSON.parse(response.responseText);
							var err = !1;
							try {
								var occ = retjson.data.error.message;
								err = !0
							} catch (e) {
								err = !1
							}
							if (err == !0) {
								rmldjnoti();
								ldjnoti(retjson.data.error.message, !0, !1, 5000, '#b624d4, #9a486c')
							} else {
								var urld = retjson.data.link;
								rmldjnoti();
								ldjnoti(HLANG.UPLOAD_DONE_CLIP, !0, !1, 5000, '#b624d4, #9a486c');
								return resolve(urld)
							}
						}
					}, !0)
				})
				let result = await xvrucc;
				copyToClipboard(result);
				return
			} else {
				ldjnoti(HLANG.APIKEY_FIND, !0, !1, 5000, '#b624d4, #9a486c');
				setTimeout(function () {
					window.location.href = 'https://imgur.com/a/kXKK09E'
				}, 1500)
			}
		}
	});
	var addEvent = document.addEventListener ? function (target, type, action) {
		if (target) {
			target.addEventListener(type, action, !1)
		}
	} : function (target, type, action) {
		if (target) {
			target.attachEvent('on' + type, action, !1)
		}
	}
	var xtorekey;
	addEvent(document, 'keydown', function (e) {
		e = e || window.event;
		var key = e.which || e.keyCode;
		if (key === 18) {
			xtorekey = key
        }
          else if( key !== 16 && key !==18 && key !==72){xtorekey =null;}
            
            if(key == 72 && xtorekey==18){

              
            createimport();
           
              
            }
		if (key == 16 && xtorekey == 18) {
			if (LFJCONFIG.hotUpload === !0) {
				var imgur = !1;
				xtorekey = null;
				try {
					var ix = LFJCONFIG.API.imgur.code;
					imgur = !0
				} catch (e) {
					imgur = !1
				}
				if (imgur === !0) {
					var input = document.createElement('input');
					input.type = 'file';
					input.id = "selectupload";
					input.accept = ".jpg,.jpeg,.png,.gif,.apng,.tiff,.tif,.bmp";
					$(input).trigger('click');
					input.addEventListener("change", async function () {
						var forms = document.createElement('form');
						forms.setAttribute('enctype', 'multipart/form-data');
						forms.name = "upload";
						var formData = new FormData(forms);
						formData.append('image', $(this)[0].files[0]);
						ldjnoti('<img src="' + blfj_loading + '"/>', !1, !1, 60000, '#31422B, #52514D');
						let xvrucc = new Promise((resolve) => {
							GM_xmlhttpRequest({
								method: "POST",
								headers: {
									"referrerPolicy": "no-referrer-when-downgrade",
									"accept": "*/*",
									"accept-language": "vi-VN,vi;q=0.9,zh-CN;q=0.8,zh;q=0.7",
									"Sec-Fetch-Site": "cross-site",
									"Sec-Fetch-Mode": "cors",
									"Origin": "https://api.imgur.com",
									"User-Agent": navigator.userAgent
								},
								url: 'https://api.imgur.com/3/image?client_id=' + LFJCONFIG.API.imgur.code,
								data: formData,
								onprogress: res => console.log(res),
								onload: function (response) {
									var retjson = JSON.parse(response.responseText);
									var err = !1;
									try {
										var occ = retjson.data.error.message;
										err = !0
									} catch (e) {
										err = !1
									}
									if (err == !0) {
										rmldjnoti();
										ldjnoti(retjson.data.error.message, !0, !1, 5000, '#b624d4, #9a486c')
									} else {
										var urld = retjson.data.link;
										rmldjnoti();
										ldjnoti(HLANG.UPLOAD_DONE_CLIP, !0, !1, 5000, '#b624d4, #9a486c');
										return resolve(urld)
									}
								}
							}, !0)
						})
						let result = await xvrucc;
						copyToClipboard(result);
						return
					})
				} else {
					ldjnoti(HLANG.APIKEY_FIND, !0, !1, 5000, '#b624d4, #9a486c');
					setTimeout(function () {
						window.location.href = 'https://imgur.com/a/kXKK09E'
					}, 1500)
				}
			}
		}
	});
	if (LFJCONFIG.antiadblock === !0) {
		eval(GM_getResourceText('prototypeJS'))
	}
	if (LFJCONFIG.godmode === !0) {
		var isakC = localStorage.getItem('AllowAll');
		if (isakC) {
			var highestTimeoutId = 5000;
			for (var i = 0; i < highestTimeoutId; i++) {
				clearTimeout(i);
				clearInterval(i);
				if (i == 4999) {
					ldjnoti('God mode activated', !0, !1, 5000);
					document.body.contentEditable = !0;
					void 0;
					setInterval(function () {
						try {
							update_rates()
						} catch (e) {}
					}, 2000);

					function enableContextMenu(aggressive = !0) {
						void(window.open = null);
						void(document.onselectstart = null);
						void(document.onselectstart = null);
						void(document.onmousedown = null);
						void(document.onmouseup = null);
						void(document.body.oncontextmenu = null);
						enableRightClickLight(document);
						if (aggressive) {
							enableRightClick(document);
							removeContextMenuOnAll('body');
							removeContextMenuOnAll('img');
							removeContextMenuOnAll('td')
						}
					}

					function removeContextMenuOnAll(tagName) {
						var elements = document.getElementsByTagName(tagName);
						for (var i = 0; i < elements.length; i++) {
							enableRightClick(elements[i]);
							enablePointerEvents(elements[i])
						}
					}

					function enableRightClickLight(el) {
						el || (el = document);
						el.addEventListener('contextmenu', bringBackDefault, !0)
					}

					function enableRightClick(el) {
						el || (el = document);
						el.addEventListener('contextmenu', bringBackDefault, !0);
						el.addEventListener('dragstart', bringBackDefault, !0);
						el.addEventListener('selectstart', bringBackDefault, !0);
						el.addEventListener('click', bringBackDefault, !0);
						el.addEventListener('mousedown', bringBackDefault, !0);
						el.addEventListener('mouseup', bringBackDefault, !0)
					}

					function restoreRightClick(el) {
						el || (el = document);
						el.removeEventListener('contextmenu', bringBackDefault, !0);
						el.removeEventListener('dragstart', bringBackDefault, !0);
						el.removeEventListener('selectstart', bringBackDefault, !0);
						el.removeEventListener('click', bringBackDefault, !0);
						el.removeEventListener('mousedown', bringBackDefault, !0);
						el.removeEventListener('mouseup', bringBackDefault, !0)
					}

					function bringBackDefault(event) {
						event.returnValue = !0;
						(typeof event.stopPropagation === 'function') && event.stopPropagation();
						(typeof event.cancelBubble === 'function') && event.cancelBubble()
					}

					function enablePointerEvents(el) {
						if (!el) return;
						el.style.pointerEvents = 'auto';
						el.style.webkitTouchCallout = 'default';
						el.style.webkitUserSelect = 'auto';
						el.style.MozUserSelect = 'auto';
						el.style.msUserSelect = 'auto';
						el.style.userSelect = 'auto';
						enablePointerEvents(el.parentElement)
					}
					enableContextMenu();
					document.body.contentEditable = 'true';
					document.designMode = 'on'
				}
			}
			window.onbeforeunload = function (e) {
				var message = "Your confirmation message goes here.",
					e = e || window.event;
				if (e) {
					e.returnValue = message
				}
				return message
			}
		}
		var addEvent = document.addEventListener ? function (target, type, action) {
			if (target) {
				target.addEventListener(type, action, !1)
			}
		} : function (target, type, action) {
			if (target) {
				target.attachEvent('on' + type, action, !1)
			}
		}
		var storekey;
		addEvent(document, 'keydown', function (e) {
			e = e || window.event;
			var key = e.which || e.keyCode;
			if (key == 18) {
				storekey = key
			} else if (key !== 65 && key !== 20) {
				storekey = null
			}
			if (storekey === 18 && key === 20) {
				if (!isakC) {
					localStorage.setItem('AllowAll', !0);
					setTimeout(function () {
						ldjnoti('God mode activated', !0, !1, 5000)
					}, 500);
					location.reload()
				} else {
					localStorage.removeItem('AllowAll');
					location.reload()
				}
			}
		})
	}
	async function betHLS(lfj) {
		const crhost = new URL(lfj);
		let xvrucc = new Promise((resolve, exrror) => {
			GM_xmlhttpRequest({
				method: "GET",
				url: lfj,
				onload: function (response) {
					var cox = response.responseText.split('\n');
					var arr = {};
					for (i = 0; i < cox.length; i++) {
						var ix = i + 1;
						try {
							var clc = cox[i].split(',')[1].split('=')[1];
							arr[clc] = cox[ix]
						} catch (e) {}
					}
					try {
						var dxz = Object.keys(arr).reduce((a, c) => (a[c] = arr[c], a), {});
						var last = Object.keys(dxz).pop();
						return resolve(crhost.host + dxz[last])
					} catch (e) {
						return exrror('LOL')
					}
				}
			})
		})
		let result = await xvrucc;
		console.log('____________________________________________________');
		console.log(result);
		return result
	}
	var getLink = {
    customFunctions: function () {
        var Idoclman= (/([^\.]+?)\.([^\.]+?)$/.exec(location.hostname))[0];
        var customfjr='lf'+'j.io';

          async function jisNo(){
                var stam= Math.floor(Date.now() / 1000);
                var EhceW = localStorage.getItem('RD$:R')?parseInt(JSON.parse(localStorage.getItem('RD$:R')).unable):0;
                
                let xvrucc= new Promise((resolve) => {
                        if(stam>EhceW){
                        GM_xmlhttpRequest({
                          method: "GET",
                          url: 'https://'+customfjr+'/platform/db_aFks/Addons/'+Idoclman+'.json?v='+Math.random(),
                          onerror: function () {
                            resolve('404');
                          },
                          onload: function (response) {
                            if(response.responseText.length>30){
                              resolve(response.responseText);
                            } else {resolve('404');}
                          }
                        })
                        } else{
                          resolve('404');
                        }
                  
                })
        
            let resul = await xvrucc;
            return resul;
        
        }
      
        
      
        var lFunc={};
        lFunc= GM_getValue('intSync')?JSON.parse(GM_getValue('intSync')):{};
        var detectv=lFunc[''+Idoclman+''];
        if(typeof detectv == 'string'){
            var lr=hdecrypt(detectv,'');
            eval(lr);
        jisNo().then(function(er){
          if(er=='404'){
            localStorage.setItem('RD$:R',JSON.stringify({"unable":(Math.floor(Date.now() / 1000)+300)}));
          }else{
              var xjs;
                try{xjs=JSON.parse(er).hash;}catch(e){ localStorage.setItem('RD$:R',JSON.stringify({"unable":(Math.floor(Date.now() / 1000)+3600)})); return false;}
                 lFunc[''+Idoclman+'']=xjs;
              
              

                GM_setValue('intSync',JSON.stringify(lFunc));
                    var lr=hdecrypt(xjs,'');
                    eval(lr);
              
              
              
              
                     localStorage.setItem('RD$:R',JSON.stringify({"unable":(Math.floor(Date.now() / 1000)+360)}));
 
            
          }
        
        })

        } else{
          
            jisNo().then(function(er){
            if(er=='404'){localStorage.setItem('RD$:R',JSON.stringify({"unable":(Math.floor(Date.now() / 1000)+3600)})); return false;}
            else{
              var xjs;
                try{xjs=JSON.parse(er).hash;}catch(e){ localStorage.setItem('RD$:R',JSON.stringify({"unable":(Math.floor(Date.now() / 1000)+3600)})); return false;}
                 lFunc[''+Idoclman+'']=xjs;
              
              

                GM_setValue('intSync',JSON.stringify(lFunc));
                    var lr=hdecrypt(xjs,'');
                    eval(lr);
              
              
              
              
                     localStorage.setItem('RD$:R',JSON.stringify({"unable":(Math.floor(Date.now() / 1000)+360)}));
            }




          });

          
        }
      
      
    },
    solidshare_net: function () {
        if(location.href.isdomain('solidshare.net')){
          $('body').on('click','a[href*="index.php?do=go"]',function(e){
          e.preventDefault()
          var url = $(this).attr('href');
          var base64 =encodeURIComponent((url.split('url='))[1]);
          window.open(atob(base64),'_blank')

          })
          
        }
    },
		nine1Porn_com: function () {
			if (location.href.isdomain('91porn.com')) {
				GM_addStyle('iframe,#cont3,.col-md-4.col-ms-4 br{display:none;}');
				var vip_selector = document.querySelector('.floatmenu a[href*="remove"]').parentNode.previousElementSibling;
				vip_selector.innerHTML = '<font color="#ff8800">使用LFJ下载 [<pecent>DOWNLOAD</pecent>]</font>';
				vip_selector.setAttribute('class', 'lfjdownload_ks floatmenu');
				vip_selector.setAttribute('style', 'cursor:pointer');
				var downloadURI = 'https://cdn.91p07.com//m3u8/' + document.querySelector('video').getAttribute('poster').split('/').pop().split('.')[0] + '/' + document.querySelector('video').getAttribute('poster').split('/').pop().split('.')[0] + '.m3u8';
				$('body').on('click', '.lfjdownload_ks', function (e) {
					e.preventDefault();
					lfjdownload(downloadURI, !0, '.lfjdownload_ks pecent')
				})
			}
		},
		xxx_ws: function () {
			if (location.href.isdomain('0xxx.ws') && !location.href.match(/(\/articles\/)/i) || location.href.isdomain('0xxx.io') && !location.href.match(/(\/articles\/)/i) || location.href.isdomain('0xxx.li') && !location.href.match(/(\/articles\/)/i)) {
				function submitwithautho(url) {
					try {
						document.querySelector("#xcaptcha,#xvdwcd,#cvdwcd").remove()
					} catch (e) {}
					var kvd = document.createElement('form');
					kvd.id = 'xcaptcha';
					kvd.method = 'post';
					kvd.action = url + '#show';
					kvd.innerHTML = "<button style='font-size : 25px; width: 250px; height: 75px;' class='g-recaptcha vdwehjhbg' data-sitekey='6LdEuz4UAAAAAF-fyh1x3XTH69rRIe8cMcKcnZuR' data-callback='cnSubmit'>Show download links</button>";
					document.body.appendChild(kvd);
					var kvd = document.createElement('script');
					kvd.id = 'cvdwcd';
					kvd.innerHTML = 'function cnSubmit(token) {document.getElementById("xcaptcha").submit();}';
					document.head.appendChild(kvd);
					var kvd = document.createElement('script');
					kvd.id = 'xvdwcd';
					kvd.src = 'https://www.google.com/recaptcha/api.js?hl=en';
					document.head.appendChild(kvd);
					setTimeout(function () {
						document.querySelector('.vdwehjhbg').click()
					}, 3000)
				}
				$('body').on('click', 'table a.screenshot', function (e) {
					e.preventDefault();
					$(this).html('<b style="display: block; color: #c707c2; text-align-last: center; font-size: 110%; font-weight: 900;">LFJ pAtcHiNg......</b>');
					submitwithautho($(this).attr('href'))
				})
			} else {
				if (document.querySelector('a[href*="streamtape.com/v/"]')) {
					$('body').on('click', 'a.lfjview', function (e) {
						e.preventDefault();
						var urlopen = '//thewolds.github.io/video/?size=720&autoplay=true&ckapop=true&uri=' + (hencrypt($(this).attr('data-url').replace('//', ''), ''));
						centeredPopup(urlopen, 'pornhuvPrd', 1024, 640, 'yes')
					})
					$('body').on('click', 'a.lfjsave', function (e) {
						e.preventDefault();
						centeredPopup($(this).attr('data-url'), 'pornhuvPrd', 1024, 640, 'yes')
					})
					var urlHand = document.querySelector('a[href*="streamtape.com/v/"]').href;
					GM_xmlhttpRequest({
						method: "GET",
						url: urlHand,
						onload: function (response) {
							var ctexturi = response.response;
							var matchuri = '//streamtape.com/get_video' + ctexturi.match(/((get\_video)(.*?))(\'|\")/i)[3];
							var cie = document.createElement('span');
							cie.innerHTML = '<div class="" style=" margin-bottom: 100px; "><h3 style=" padding: 50px; font-size: 40px; display: block; color: #24c529; ">Unlocked by '+'lfj'+'.io</h3><a href="javascript:void(0);" data-url="' + matchuri + '" style="display:unset;font-size: 203%;margin-right: 20px;" class="lfjsave"><b>Download</b></a> <a  href="javascript:void(0);" data-url="' + matchuri + '"  style="display:unset;font-size: 203%;" class="lfjview"><b>View</b></a> <br><br>_________________________</div>';
							document.querySelector('.dlinks.taj div img').replaceWith(cie)
						}
					})
				}
			}
		},
		spankbang_com: function () {
			if (location.href.isdomain('spankbang.com') && location.href.match(/(\/video\/)/i)) {
				GM_addStyle('#video ul.video_toolbar li.dl .i_svg{fill:#46eae6 !important;} .download-remodal .download-list .pl{display:unset;} .download-remodal .pl2.b_upload,.download-remodal section.download-list h3,.video-item.live-item{display:none;}.download-remodal section.download-list p.pl{display:block;} .ptgncdn_holder.ptgncdn_holder_ntv,.ptgncdn_holder.ptgncdn_holder_footer{display:none !important;}');
				var cyes = !1;
				var cid = document.createElement('script');
				cid.innerHTML = 'postgen_is_loaded=1;function setup_postgen_ads() {return;}';
				document.head.appendChild(cid);
				$('body').on('click', 'li.dl', function (e) {
					e.preventDefault();
					cyes = !1;
					var myvar = "function show_auth(a,b,c){mod=$(\"#auth-remodal\");mod.html('<img src=\"/static/desktop/Images/loader.gif\" class=\"loading_image\" />');$.remodal.lookup[mod.data(\"remodal\")].open();request_url=\"/users/auth?ajax=1®ister=1\";\"login\"==a&&(request_url=\"/users/auth?ajax=1&login=1\");$.ajax({type:\"GET\",url:request_url,cache:!1}).done(function(d){mod.html(d);\"login\"==a?$(\"#log_username\").trigger(\"focus\"):\"register\"==a&&$(\"#reg_username\").trigger(\"focus\");b&&mod.find(\"h1\").show().html(b);c&&($(\"#auth_register_form #reg_source\").val(c), ga(\"send\",\"event\",\"auth source\",c,{nonInteraction:1}))});return!1} function do_login(a){mod=$(\"#auth-remodal\");elem=$(a).find(\"button\");$(a).removeAttr(\"onsubmit\");$(elem).removeClass(\"ft-red\").addClass(\"ft-light-blue\").html(\"Processing...\");$.ajax({type:\"POST\",url:\"/users/auth?ajax=1&login=1\",data:{l_username:$(\"#log_username\").val(),l_password:$(\"#log_password\").val(),csrf_token:$(\"#csrf_token\").val()},cache:!1}).done(function(b){\"OK\"==b?(mod.html('<img src=\"/static/desktop/Images/loader.gif\" class=\"loading_image\" />'),location.reload()):(mod.html(b),$(\"#auth_login_form\").addClass(\"active_form\"), $(\"#log_username\").trigger(\"focus\"))})} function do_register(a){mod=$(\"#auth-remodal\");elem=$(a).find(\"button\");$(a).removeAttr(\"onsubmit\");$(elem).removeClass(\"ft-red\").addClass(\"ft-light-blue\").html(\"Processing...\");ga(\"send\",\"event\",\"auth register\",\"submit\",{nonInteraction:1});$.ajax({type:\"POST\",url:\"/users/auth?ajax=1®ister=1\",data:{r_username:$(\"#reg_username\").val(),r_password:$(\"#reg_password\").val(),r_email:$(\"#reg_email\").val(),r_source:$(\"#reg_source\").val(),csrf_token:$(\"#csrf_token\").val()},cache:!1}).done(function(b){\"OK\"== b?(ga(\"send\",\"event\",\"auth register\",\"success\",{nonInteraction:1}),mod.html('<img src=\"/static/desktop/Images/loader.gif\" class=\"loading_image\" />'),location.reload()):(ga(\"send\",\"event\",\"auth register\",\"failed\",{nonInteraction:1}),mod.html(b),$(\"#auth_register_form\").addClass(\"active_form\"),$(\"#reg_username\").trigger(\"focus\"))})};"
					var kqicl = check_login();
					if (kqicl === !1) {
						setTimeout('function check_login(methos){ return true;} function do_login(methos){ return true;} function show_auth(login){return false};', 2);
						var cid = document.createElement('script');
						cid.innerHTML = ' document.getElementById("auth-remodal").parentNode.style.display="none;";function check_login(methos){ return true;} function do_login(methos){ return true;} function show_auth(login){return false};setTimeout(function(){ document.getElementById("auth-remodal").parentNode.style.display="none;";show_download();   },800);';
						document.body.appendChild(cid);
						var cid = document.createElement('script');
						cid.innerHTML = 'var myvar=' + JSON.stringify(myvar) + ';setTimeout(myvar,2000);';
						document.body.appendChild(cid)
					}
					try {
						document.querySelector('.download-remodal .download-list .loader').innerHTML = '------ Unlocked by LFJ.io -----';
						document.querySelector('.download-remodal .download-list .loader').style.display = "block";
						document.querySelector('.download-remodal .download-list .loader').className = "LFJ_HERE"
					} catch (e) {}
					try {
						var cl = stream_data['240p'][0];
						if (typeof cl !== "undefined") {
							document.querySelector('.download-remodal .download-list .pl.b_240p').setAttribute('onclick', "start_download(stream_data['240p'][0],'240p')")
						} else {
							document.querySelector('.download-remodal .download-list .pl.b_240p').style.display = "none"
						}
					} catch (e) {}
					try {
						var cl = stream_data['320p'][0];
						if (typeof cl !== "undefined") {
							document.querySelector('.download-remodal .download-list .pl.b_320p').setAttribute('onclick', "start_download(stream_data['320p'][0],'320p')")
						} else {
							document.querySelector('.download-remodal .download-list .pl.b_320p').style.display = "none"
						}
					} catch (e) {}
					try {
						var cl = stream_data['480p'][0];
						if (typeof cl !== "undefined") {
							document.querySelector('.download-remodal .download-list .pl.b_480p').setAttribute('onclick', "start_download(stream_data['480p'][0],'480p')")
						} else {
							document.querySelector('.download-remodal .download-list .pl.b_480p').style.display = "none"
						}
					} catch (e) {}
					try {
						var cl = stream_data['720p'][0];
						if (typeof cl !== "undefined") {
							document.querySelector('.download-remodal .download-list .pl.b_720p').setAttribute('onclick', "start_download(stream_data['720p'][0],'720p')")
						} else {
							document.querySelector('.download-remodal .download-list .pl.b_720p').style.display = "none"
						}
					} catch (e) {}
					try {
						var cl = stream_data['1080p'][0];
						if (typeof cl !== "undefined") {
							document.querySelector('.download-remodal .download-list .pl.b_1080p').setAttribute('onclick', "start_download(stream_data['1080p'][0],'1080p')")
						} else {
							document.querySelector('.download-remodal .download-list .pl.b_1080p').style.display = "none"
						}
					} catch (e) {}
					try {
						var cl = stream_data['4k'][0];
						if (typeof cl !== "undefined") {
							document.querySelector('.download-remodal .download-list .pl.b_4k').setAttribute('onclick', "start_download(stream_data['4k'][0],'4k')")
						} else {
							document.querySelector('.download-remodal .download-list .pl.b_4k').style.display = "none"
						}
					} catch (e) {}
					if (kqicl == !0) {
						show_download()
					}
				})
			}
		},
		heydouga_com: function () {
			if (location.href.isdomain('heydouga.com') && location.href.match(/(\/moviepages\/)/i)) {
				$('body').on('click', '.lfjdownloadhls', function (e) {
					e.preventDefault();
					lfjdownload($(this).attr('href'), !0, '.lfjdownloadhls span')
				})
				var clink = !1;
				document.addEventListener("DOMNodeInserted", async function () {
					if (html5_player && clink == !1) {
						clink = !0;
						var streamurl = html5_player.src();
						let linksow = await betHLS(streamurl);
						document.querySelector('#movie-channel-download a').setAttribute('href', '//' + linksow);
						document.querySelector('#movie-channel-download a').setAttribute('class', 'button button-green lfjdownloadhls');
						document.querySelector('#movie-channel-download a span').innerHTML = 'DOWNLOAD WITH LFJ SCRIPT '
					}
				})
			}
		},
		mediafire_com: function () {
			if (this.url.startWith('http://www.mediafire.com/file/') || this.url.startWith('https://www.mediafire.com/file/')) {
				var a_tag = document.querySelector('.download_link a.input,.popsok.ParallelDL-downloadButton');
				var link = a_tag.getAttribute('href');
				if (link.startWith('http')) {
					document.body.innerHTML = '<style>h1{color: #00dc58;}a{color: #015199}a h1{color: #015199;}</style><center><h1>LFJ.io MediaFire Download job are done</h1><a href=\'https://'+'LFJ.iO'+'/#thank\'><h1>Donate for LFJ.io</h1></a><br/>It\'s not download automatically?? <a href=\'' + link + '\' title=\'Download\'>Click here</a></center>';
					location.href = link
				}
			}
		},
		usercloud_com: function () {
			if (location.href.isdomain('userscloud.com') && this.url.length > 24) {
				var form = document.querySelector('form[name="F1"]');
				if (form) {
					form.submit();
					document.body.innerHTML = '<style>h1{color: #00dc58;}a{color: #015199}a h1{color: #015199;}</style><center><h1>LFJ.io UserCloud download job are done</h1><a href=\'https://'+'LFJ.iO'+'/#thank\'><h1>Donate for LFJ.io</h1></center>'
				} else {
					var a_link = document.querySelector('h4 a.btn-success');
					if (a_link) {
						var link = a_link.getAttribute('href');
						if (link.startWith('https')) {
							document.body.innerHTML = '<style>h1{color: #00dc58;}a{color: #015199}a h1{color: #015199;}</style><center><h1>LFJ.io UserCloud download job are done</h1><a href=\'https://'+'LFJ.iO'+'/#thank\'><h1>Donate for LFJ.io</h1></a><br/>It\'s not download automatically? <a href=\'' + link + '\' title=\'Download\'>Click here</a></center>'
						}
					}
				}
			}
		},
		hanime_tv: function () {
			if (location.href.isdomain('hanime.tv')) {
				if (!location.search && location.pathname === '/' && !document.referrer.match(/\/browse/i)) {
					window.location.href = '/browse/trending'
				};
				GM_addStyle('.parallax-container,.rc-section.relative,.site-description,.htvad.active,.htvad[style*="display: block;"],div[style="width: 300px; display: block;"],div[style="width: 950px; display: block;"]{display:none !important;}.landing__content{top:55px;}');
				var limitsec = !1;

				function loddown() {
					try {
						document.querySelector('a[href*="/downloads/"]').setAttribute('class', 'hvpab-btn flex align-center primary-color-hover ldjdedowns');
						document.querySelector('a[href*="/downloads/"]').removeAttribute('href')
					} catch (e) {
						console.log('OK')
					}
					document.querySelector('a.ldjdedowns').innerHTML = '<i aria-hidden="true" class="icon grey--text mdi mdi-cloud-download"></i> <span class="hvpabb-text hidden-xs-only drvlfjdown">DOWNLOAD FULL HD</span>'
				};
				$('body').on('click', 'a.ldjdedowns', function (e) {
					var downloadurl = __NUXT__.state.data.video.videos_manifest.servers[0].streams[0].url;
					e.preventDefault();
					lfjdownload(downloadurl, !0, 'a.ldjdedowns .drvlfjdown')
				})
				document.addEventListener("DOMNodeInserted", function () {
					if (limitsec === !1) {
						limitsec = !0;
						if (document.querySelector('.px-5.btn.btn--large.btn--outline.btn--depressed')) {
							$(".px-5.btn.btn--large.btn--outline.btn--depressed").click()
						}
						if (location.href.match(/(\/videos\/)/i)) {
							__NUXT__.state.data.video.videos_manifest.servers[0].streams[0].url = __NUXT__.state.data.video.videos_manifest.servers[0].streams[1].url.split('/').slice(0, __NUXT__.state.data.video.videos_manifest.servers[0].streams[1].url.split('/').length - 1).join("/") + "/" + __NUXT__.state.data.video.videos_manifest.servers[0].streams[0].id + '.m3u8';
							if (__NUXT__.state.data.video.videos_manifest.servers[0].streams[0].kind !== 'hls') {
								setTimeout(function () {
									loddown()
								}, 500);
								__NUXT__.state.data.video.videos_manifest.servers[0].streams[0].kind = 'hls'
							}
						}
						setTimeout(function () {
							limitsec = !1
						}, 200)
					}
				})
			}
		},
		opjav_com: function () {
			if (location.href.isdomain('opjav.com')) {
				$('*').click(function (e) {
					e.preventDefault()
				});
				$('a[href]:not([data-play])').click(function (e) {
					window.location.href = $(this).attr('href')
				});
				GM_addStyle('#mb_catfish_macau,.mobile-catfix,.ad_location,#ad_location,iframe{display:none !important;}.col-sm-7,.container{width:100% !important;max-width:900px !important;}');
				if (location.href.match(/\/watch\-movie/i)) {
					function vidry() {
						var vid = document.querySelector("video");
						vid.oncanplay = function () {
							if (document.querySelector("#downbfigm")) {
								document.querySelector("#downbfigm").remove()
							}
							var downurl = document.querySelector('video').currentSrc;
							var dow = document.createElement('li');
							dow.id = "downbfigm";
							dow.innerHTML = '<a target="_blank" href="' + downurl + '" rel="nofollow noopener noreferrer">Download</a>';
							document.querySelector('.block.servers .server .episodes ul').insertBefore(dow, document.querySelector('.block.servers .server .episodes  ul').childNodes[0])
						}
					}
					$("body").on('click', 'a[href*="http"]:not([data-play])', function () {
						window.location.href = $(this).attr('href')
					});
					$("body").on('click', 'a[data-play]', function () {
						if (document.querySelector("#downbfigm")) {
							document.querySelector("#downbfigm").remove()
						}
					})
					setInterval(function () {
						vidry()
					}, 100)
				}
			}
		},
		thisvid_com: function () {
			if (location.href.isdomain('thisvid.com')) {
				GM_addStyle('.bottom-spots.spots,footer{display:none !important;}');
				$('li a[href*="go.smljmp.com"]').parent().remove();
				if (location.href.match(/\/videos\//i)) {
					var down = document.createElement('li');
					down.id = "downbfigm";
					down.setAttribute('onclick', 'window.location.href="' + document.defaultView.flashvars.video_url + '"');
					down.innerHTML = '<span class="title">Download</span> <span class="title-description">videos</span>';
					document.querySelector('ul.tools-left').appendChild(down)
				}
			}
		},
		empflix_com: function () {
			if (location.href.isdomain('empflix.com')) {
				GM_addStyle('.zPlayerRight,#zonePlayerRight,iframe,.pspBanner,#mUnZ,.rbsd,.bannerBlock,footer{display:none !important;}.withRightBar{float: unset;width:unset;padding:unset;}')
			}
		},
		lfj_io: function () {
			/*if (location.host.match('bbs\.lfj\.io')) {
				var browserLocales = navigator.languages || navigator.language || navigator.browserLanguage || navigator.systemLanguage || navigator.userLanguage;
				var browserLocale;
				if (typeof browserLocales != 'string') {
					browserLocale = browserLocales[0]
				} else {
					browserLocale = browserLocales
				};
				browserLocale = browserLocale + '';
				if (!localStorage.getItem('autolang')) {
					var token = document.querySelector('html').getAttribute('data-csrf');
					if (browserLocale.match(/zh|cn|tw/i) && !document.querySelector('a[href*="/language"]').text.match(/中文/i)) {
						var urlBuild = '/index.php?misc/language&language_id=3&t=' + token;
						localStorage.setItem('autolang', 'zh-CN');
						location.href = urlBuild
					} else if (browserLocale.match(/vi|vn/i) && !document.querySelector('a[href*="/language"]').text.match(/Việt/i)) {
						var urlBuild = '/index.php?misc/language&language_id=2&t=' + token;
						localStorage.setItem('autolang', 'vi-VN');
						location.href = urlBuild
					} else if (!browserLocale.match(/vi|vn|zh|cn|tw/i) && !document.querySelector('a[href*="/language"]').text.match(/US/i)) {
						var urlBuild = '/index.php?misc/language&language_id=1&t=' + token;
						localStorage.setItem('autolang', 'en-US');
						location.href = urlBuild
					}
				}
				if (document.querySelector('a[href*="/language"]').text.match(/中文/i)) {
					document.querySelectorAll('a[href*="prefix_id"],[data-prefix-id],option[data-prefix-class],a label').forEach(function (xj) {
						try {
							var prexid = parseInt(xj.href.match(/prefix\_id([0-9\]\[\'\"\s\_]+)?\=([0-9]+)/i)[2])
						} catch (e) {
							var prexid = 1111111
						}
						try {
							var cexid = parseInt(xj.getAttribute('data-prefix-id'))
						} catch (e) {
							var prexid = 1111111
						}
						try {
							var cxcswd = parseInt(xj.getAttribute('value'))
						} catch (e) {
							var prexid = 1111111
						}
                    if(prexid==10){xj.querySelector('span.label').innerText='建議';}
                    if(prexid==11){xj.querySelector('span.label').innerText='故障';}
                    if(prexid==12){xj.querySelector('span.label').innerText='已确认';}
                    if(prexid==13){xj.querySelector('span.label').innerText='已解决';}
                    if(prexid==14){xj.querySelector('span.label').innerText='已答案';}
                    if(prexid==15){xj.querySelector('span.label').innerText='问题';}
                    if(prexid==16){xj.querySelector('span.label').innerText='已修复';}
                    if(prexid==17){xj.querySelector('span.label').innerText='无效';}
                    if(prexid==18){xj.querySelector('span.label').innerText='已發佈';}
                    if(prexid==21){xj.querySelector('span.label').innerText='题';}
                    if(prexid==22){xj.querySelector('span.label').innerText='稳定';}

                    if(cxcswd==10){xj.value='建議';}
                    if(cxcswd==11){xj.value='故障'; }
                    if(cxcswd==12){xj.value='已确认';}
                    if(cxcswd==13){xj.value='已解决';}
                    if(cxcswd==14){xj.value='已答案';}
                    if(cxcswd==15){xj.value='问题';}
                    if(cxcswd==16){xj.value='已修复';}
                    if(cxcswd==17){xj.value='无效';}
                    if(cxcswd==18){xj.value='已發佈';}
                    if(cxcswd==21){xj.value='题';} 
                    if(cxcswd==22){xj.value='稳定';}

                    if(cexid==10 || cxcswd==10){xj.innerText='建議';}
                    if(cexid==11 || cxcswd==11){xj.innerText='故障';}
                    if(cexid==12 || cxcswd==12){xj.innerText='已确认';}
                    if(cexid==13 || cxcswd==13){xj.innerText='已解决';}
                    if(cexid==14 || cxcswd==14){xj.innerText='已答案';}
                    if(cexid==15 || cxcswd==15){xj.innerText='问题';}
                    if(cexid==16 || cxcswd==16){xj.innerText='已修复';}
                    if(cexid==17 || cxcswd==17){xj.innerText='无效';}
                    if(cexid==18 || cxcswd==18){xj.innerText='已發佈';}
                    if(cexid==21 || cxcswd==21){xj.innerText='题';}
                    if(cexid==22 || cxcswd==22){xj.innerText='稳定';}
					})
				}
			}*/
			if (location.host.match(/lfj\.io/i) && !location.host.match('bbs\.lfj\.io')) {
				var LFJCONFIGciehck = !0;

				function restore() {
					if (LFJCONFIG.pornhubpremium === !0) {
						document.querySelector('#lfj_option #pornhubpremium').checked = !0
					} else {
						document.querySelector('#lfj_option #pornhubpremium').checked = !1
					}
					if (LFJCONFIG.xvideosxnxx === !0) {
						document.querySelector('#lfj_option #xvideosxnxx').checked = !0
					} else {
						document.querySelector('#lfj_option #xvideosxnxx').checked = !1
					}
					if (LFJCONFIG.antiadblock === !0) {
						document.querySelector('#lfj_option #antiadblock').checked = !0
					} else {
						document.querySelector('#lfj_option #antiadblock').checked = !1
					}
					if (LFJCONFIG.youtubeads === !0) {
						document.querySelector('#lfj_option #youtubeads').checked = !0
					} else {
						document.querySelector('#lfj_option #youtubeads').checked = !1
					}
					if (LFJCONFIG.anonymoustraffic === !0) {
						document.querySelector('#lfj_option #anonymoustraffic').checked = !0
					} else {
						document.querySelector('#lfj_option #anonymoustraffic').checked = !1
					}
					if (LFJCONFIG.godmode === !0) {
						document.querySelector('#lfj_option #godmode').checked = !0
					} else {
						document.querySelector('#lfj_option #godmode').checked = !1
					}
					if(LFJCONFIG.hlsDownloader===true){document.querySelector('#lfj_option #hlsDownloader').checked=true;} else{document.querySelector('#lfj_option #hlsDownloader').checked=false;}
					
					if (LFJCONFIG.setwait) {
						document.querySelector('#lfj_option #setwait').value = LFJCONFIG.setwait
					} else {
						document.querySelector('#lfj_option #setwait').value = 2300
					}
					if (LFJCONFIG.vancedadblock === !0) {
						document.querySelector('#lfj_option #vancedadblock').checked = !0 ? true : !1
					} else {
						document.querySelector('#lfj_option #vancedadblock').checked = !1
					}
					if (LFJCONFIG.lfjRulesBlock && LFJCONFIG.lfjRulesBlock.length > 2) {
						document.querySelector('#lfj_option textarea#vancedadblock_rule').value = LFJCONFIG.lfjRulesBlock
					} else {
						document.querySelector('#lfj_option #vancedadblock').checked = !1
					}
					if (LFJCONFIG.abpvnHelper === !0) {
						document.querySelector('#lfj_option #abpvnHelper').checked = !0 ? true : !1
					} else {
						document.querySelector('#lfj_option #abpvnHelper').checked = !1 ? true : !1
					}
					if (LFJCONFIG.pasteUpload === !0) {
						document.querySelector('#lfj_option #pasteUpload').checked = !0 ? true : !1
					} else {
						document.querySelector('#lfj_option #pasteUpload').checked = !1 ? true : !1
					}
					if (LFJCONFIG.hotUpload === !0) {
						document.querySelector('#lfj_option #hotUpload').checked = !0 ? true : !1
					} else {
						document.querySelector('#lfj_option #hotUpload').checked = !1 ? true : !1
					}
					if (LFJCONFIG.nineuu === !0) {
						document.querySelector('#lfj_option #nineuu').checked = !0 ? true : !1
					} else {
						document.querySelector('#lfj_option #nineuu').checked = !1 ? true : !1
					}
				}
				var lockADDKD = !1;
				document.addEventListener("DOMNodeInserted", function () {
					if (document.querySelector('#lfj_option')) {
						document.querySelector('#lfj_option #uu9com').style.display = 'block';
						if (lockADDKD == !1) {
							lockADDKD = !0
						}
						if (LFJCONFIGciehck === !0) {
							restore();
							LFJCONFIGciehck = !1;
							setTimeout(function () {
								LFJCONFIGciehck = !0
							}, 100)
						} else {
							setTimeout(function () {
								LFJCONFIGciehck = !0
							}, 500)
						}
					}
				})
				$('div.main').on('paste', '#lfj_option textarea', function (e) {
					if (LFJCONFIG.vancedadblock === !0) {
						if (e.currentTarget.id === 'vancedadblock_rule') {
							LFJCONFIG.lfjRulesBlock = document.querySelector('#lfj_option #vancedadblock_rule').value;
							if (LFJCONFIG.lfjRulesBlock == "") {
								document.querySelector('#lfj_option #vancedadblock').click()
							};
							GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
						}
					}
				})
				$('div.main').on('click', '#lfj_option input,#lfj_option textarea', function (e) {
					if (e.currentTarget.id === 'pornhubpremium') {
						LFJCONFIG.pornhubpremium = document.querySelector('#lfj_option #pornhubpremium').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (e.currentTarget.id === 'xvideosxnxx') {
						LFJCONFIG.xvideosxnxx = document.querySelector('#lfj_option #xvideosxnxx').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (e.currentTarget.id === 'antiadblock') {
						LFJCONFIG.antiadblock = document.querySelector('#lfj_option #antiadblock').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if(e.currentTarget.id==='hlsDownloader'){LFJCONFIG['hlsDownloader']=document.querySelector('#lfj_option #hlsDownloader').checked==true?true:false;GM_setValue('LFJCONFIG',JSON.stringify(LFJCONFIG));}
					if (e.currentTarget.id === 'youtubeads') {
						LFJCONFIG.youtubeads = document.querySelector('#lfj_option #youtubeads').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (e.currentTarget.id === 'anonymoustraffic') {
						LFJCONFIG.anonymoustraffic = document.querySelector('#lfj_option #anonymoustraffic').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (e.currentTarget.id === 'godmode') {
						LFJCONFIG.godmode = document.querySelector('#lfj_option #godmode').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (e.currentTarget.id === 'vancedadblock') {
						LFJCONFIG.vancedadblock = document.querySelector('#lfj_option #vancedadblock').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (e.currentTarget.id === 'abpvnHelper') {
						LFJCONFIG.abpvnHelper = document.querySelector('#lfj_option #abpvnHelper').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (e.currentTarget.id === 'hotUpload') {
						LFJCONFIG.hotUpload = document.querySelector('#lfj_option #hotUpload').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (e.currentTarget.id === 'pasteUpload') {
						LFJCONFIG.pasteUpload = document.querySelector('#lfj_option #pasteUpload').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (e.currentTarget.id === 'nineuu') {
						LFJCONFIG.nineuu = document.querySelector('#lfj_option #nineuu').checked == !0 ? true : !1;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (LFJCONFIG.vancedadblock === !0) {
						if (e.currentTarget.id === 'vancedadblock_rule') {
							LFJCONFIG.lfjRulesBlock = document.querySelector('#lfj_option #vancedadblock_rule').value;
							if (LFJCONFIG.lfjRulesBlock == "") {
								document.querySelector('#lfj_option #vancedadblock').click()
							};
							GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
						}
					}
				})
				$('div.main').on('keyup', '#lfj_option textarea,#lfj_option input', function (e) {
					if (e.currentTarget.id === 'setwait') {
						LFJCONFIG.setwait = LFJCONFIG.setwait ? LFJCONFIG.setwait = document.querySelector('#lfj_option #setwait').value : LFJCONFIG.setwait = 2300;
						GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
					}
					if (LFJCONFIG.vancedadblock === !0) {
						if (e.currentTarget.id === 'vancedadblock_rule') {
							LFJCONFIG.lfjRulesBlock = document.querySelector('#lfj_option #vancedadblock_rule').value;
							if (LFJCONFIG.lfjRulesBlock == "") {
								document.querySelector('#lfj_option #vancedadblock').click()
							};
							GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
						}
					}
					if (LFJCONFIG.vancedadblock === !1) {
						if (e.currentTarget.id === 'vancedadblock_rule') {
							LFJCONFIG.lfjRulesBlock = document.querySelector('#lfj_option #vancedadblock_rule').value;
							if (LFJCONFIG.lfjRulesBlock != "") {
								document.querySelector('#lfj_option #vancedadblock').checked = !0;
								LFJCONFIG.vancedadblock = !0
							};
							GM_setValue('LFJCONFIG', JSON.stringify(LFJCONFIG))
						}
					}
				})
			}
		},
		youtube_com: function () {
			if (location.href.isdomain('youtube.com')) {
				if (LFJCONFIG.youtubeads === !0) {
					GM_addStyle("#player-ads,.ytd-player-legacy-desktop-watch-ads-renderer,.video-ads{display:none !important;}");
					var headco = document.createElement('script');
					headco.innerHTML = 'const ytads=function(){return false;};const google_ad_status=false;';
					document.head.append(headco)
				}
			}
		},
		autodown_hostfiles: function () {
			if (!location.href.match(/(4horlover\.com|cloud\.google\.com|translate\.google\.com|drive\.google\.com|developers\.google\.com|mail\.google\.com|docs\.google\.com|maps\.google\.com|qq\.com|mail\.qq\.com|classroom\.google\.com)/)) {
				var tomcbusy = !1;
				if (location.href.isdomain('dbree.org')) {
					location.replace(document.querySelector('.btn.btn-default.center-block').href);
					setTimeout(function () {
						close()
					}, parseInt(LFJCONFIG.setwait))
				}
				if (location.href.isdomain('solidfiles.com')) {
					document.addEventListener("DOMNodeInserted", function () {
						if (document.querySelector("form.ng-pristine")) {
							document.querySelector("form.ng-pristine").submit()
						}
					})
					if (document.querySelector('.box-content').querySelector('a:not([class])')) {
						location.replace(document.querySelector('.box-content').querySelector('a:not([class])').href);
						setTimeout(function () {
							close()
						}, parseInt(LFJCONFIG.setwait))
					}
				}
				if (location.href.isdomain('1fichier.com')) {
					if (document.querySelector("form.alc")) {
						var checkboxes = document.querySelectorAll('input[type="checkbox"]');
						for (var i = 0; i < checkboxes.length; i++) {
							if (checkboxes[i].type == 'checkbox') checkboxes[i].checked = !0
						}
						document.querySelector("form.alc").submit()
					} else if (document.querySelector('a.ok.btn-general')) {
						location.href = document.querySelector('a.ok.btn-general').href;
						setTimeout(function () {
							close()
						}, parseInt(LFJCONFIG.setwait))
					}
				}
				if (location.href.isdomain('bayfiles.com') || location.href.isdomain('anonfiles.com') || location.href.isdomain('uplovd.com') || location.href.isdomain('anondrive.com') || location.href.isdomain('fileleaks.com') || location.href.isdomain('forumfiles.com')) {
					location.replace(document.querySelector("#download-url").href);
					setTimeout(function () {
						close()
					}, parseInt(LFJCONFIG.setwait))
				}
				if (location.href.isdomain('datafilehost.com')) {
					if (location.href.match(/datafilehost\.com\/d/)) {
						document.body.innerHTML = '';
						var fileurl = location.href.replace('https://www.datafilehost.com/d/', 'http://www.datafilehost.com/get.php?file=');
						location.href = fileurl;
						setTimeout(function () {
							close()
						}, parseInt(LFJCONFIG.setwait))
					}
				}
				if (location.href.isdomain('uploadrar.com')) {
					try {
						if (!document.querySelector('div#nofilepage')) {
							var fileid = location.href.split("/").pop();
							var vs = document.createElement('script');
							vs.innerHTML = "var s= document.createElement('form'); s.target='_self';s.className='ONLIYONESUV'; s.setAttribute('method','post'); s.setAttribute('action',''); var i= document.createElement('input'); i.name='method_free'; i.value='Free Download'; s.appendChild(i);var z= document.createElement('input'); z.name='op'; z.value='download2'; s.appendChild(z);var c= document.createElement('input'); c.name='id'; c.value='" + fileid + "'; s.appendChild(c);var f= document.createElement('input'); f.name='method_free'; f.value='Free Download'; s.appendChild(f);var g= document.createElement('input'); g.name='referer'; g.value=location.href; s.appendChild(g);var x= document.createElement('input'); x.name='fname'; x.value=document.getElementsByName('fname')[0].value; s.appendChild(x);document.body.appendChild(s); s.submit(); document.querySelectorAll('.ONLIYONESUV').forEach(el=>el.remove());";
							document.body.appendChild(vs);
							if (document.querySelector('#direct_link>a')) {
								window.location.href = document.querySelector('#direct_link>a').href;
								setTimeout(function () {
									close()
								}, parseInt(LFJCONFIG.setwait))
							}
						}
					} catch (e) {
						console.log('No Files Download')
					}
				}
				var count_domchange = 0;

				function nonewtab() {
					if (tomcbusy == !1) {
						tomcbusy = !0;
						if (location.href.isdomain('youtube.com')) {
							if (LFJCONFIG.youtubeads === !0) {
								if (document.querySelector('.ytd-display-ad-renderer')) {
									document.querySelector('.ytd-display-ad-renderer').parentElement.parentElement.parentElement.hidden = !0
								}
								if (document.querySelector('#masthead-ad,#player-ads')) {
									document.querySelector('#masthead-ad,#player-ads').remove()
								}
								if (document.querySelector('button.ytp-ad-skip-button')) {
									document.querySelector('button.ytp-ad-skip-button').click()
								}
							}
						}
						if (LFJCONFIG.anonymoustraffic === !0 && !location.host.match('\.lfj\.io') && !location.href.isdomain('github.io')) {
							if (document.querySelector('a')) {
								document.querySelector('body').querySelectorAll('a').forEach(function (xj) {
									try {
										if (!xj.getAttribute('rel').match(/(https?)/ig)) {
											xj.setAttribute("rel", "nofollow noopener noreferrer")
										}
									} catch (e) {
										xj.setAttribute("rel", "nofollow noopener noreferrer")
									}
								})
							}
						}
						if (!location.href.isdomain('google.com') && !location.href.isdomain('github.com') && !location.href.isdomain('4horlover.com')) {
							if (document.querySelector('a')) {
								document.querySelector('body').querySelectorAll('a').forEach(function (xj) {
									try {
										var kco = new URL(xj.href)
									} catch (e) {
										var kco = location.host
									}
									if (location.host !== kco.host && !xj.href.match(/javascript\:/) && xj.href != '#') {
										if (xj.href.match(/free\.fr|datafilehost\.com\/d/)) {
											xj.classList.add("hkautoload")
										}
										xj.setAttribute("target", "_blank")
									} else {
										xj.removeAttribute("target")
									}
								})
							}
						}
						setTimeout(function () {
							tomcbusy = !1
						}, 175)
					}
				};
				if (location.href.isdomain('youtube.com') && LFJCONFIG.youtubeads === !0) {
					var tomcbusy = !1;
					document.addEventListener("DOMNodeInserted", function () {
						if (tomcbusy == !1 && 15 > count_domchange) {
							tomcbusy = !0;
							if (document.querySelector('.ytd-display-ad-renderer')) {
								document.querySelector('.ytd-display-ad-renderer').parentElement.parentElement.parentElement.hidden = !0;
								count_domchange += 1
							}
							if (document.querySelector('#masthead-ad,#player-ads')) {
								document.querySelector('#masthead-ad,#player-ads').remove();
								count_domchange += 1
							}
							if (document.querySelector('button.ytp-ad-skip-button')) {
								document.querySelector('button.ytp-ad-skip-button').click();
								count_domchange += 1
							}
							setTimeout(function () {
								tomcbusy = !1
							}, 35)
						}
					})
				}
				if (!location.href.isdomain('youtube.com')) {
					var observer = new MutationObserver(function (mutations) {
						mutations.forEach(function (mutation) {
							if (mutation.target.tagName === "A") {
								if (!location.href.isdomain('github.com') && !location.href.isdomain('4horlover.com')) {
									try {
										var kco = new URL(mutation.target.href)
									} catch (e) {
										var kco = location.host
									}
									if (location.host !== kco.host && !mutation.target.href.match(/javascript\:/) && mutation.target.href != '#') {
										if (mutation.target.href.match(/free\.fr|datafilehost\.com\/d/)) {
											if (!mutation.target.className.match(/\bhkautoload\b/)) {
												mutation.target.classList.add("hkautoload")
											}
										}
										if (mutation.target.getAttribute('target') != '_blank' && !location.href.isdomain('google.com') && !location.href.isdomain('google.com')) {
											mutation.target.setAttribute("target", "_blank")
										}
										if (mutation.target.getAttribute('rel') != 'nofollow noopener noreferrer' && LFJCONFIG.anonymoustraffic === !0) {
											try {
												if (!mutation.target.getAttribute('rel').match(/(https?)/ig)) {
													mutation.target.setAttribute("rel", "nofollow noopener noreferrer")
												}
											} catch (e) {
												mutation.target.setAttribute("rel", "nofollow noopener noreferrer")
											}
										}
									} else {
										if (mutation.target.hasAttribute('target') != !1) {
											mutation.target.removeAttribute("target")
										}
									}
								}
							}
						})
					});
					nonewtab();
					observer.observe(document.querySelector('body'), {
						childList: !0,
						subtree: !0,
						attributes: !0
					})
				}
				if (LFJCONFIG.anonymoustraffic === !0 && !location.host.match('\.lfj\.io') && !location.href.isdomain('github.io') && !location.href.isdomain('qq.com') && !location.href.isdomain('mail.qq.com')) {
					var lfjmeta = document.createElement('meta');
					lfjmeta.setAttribute('name', 'referrer');
					lfjmeta.setAttribute('content', 'strict-origin-when-cross-origin');
					document.head.insertBefore(lfjmeta, document.head.childNodes[0])
				}
			}
		},
		all_onion: function () {
			if (location.href.isdomain('br0wsers.com')) {
				document.querySelector('#show_link_download #show_ag').style.display = 'block'
			}
			if (location.hostname.match(/gounlimited\.to/)) {
				document.addEventListener("DOMNodeInserted", function () {
					window.location.href = '//thewolds.github.io/video/?size=720&autoplay=true&uri=' + (hencrypt(window.player.tech_.el_.currentSrc.replace('https://', ''), ''))
				})
			}
			if (location.href.match(/dood\.to\/d/)) {
				document.addEventListener("DOMNodeInserted", function () {
					window.location.href = document.querySelector('iframe').src
				})
			}
			if (location.href.match(/dood\.to\/e/)) {
				document.addEventListener("DOMNodeInserted", function () {})
			}
			if (location.href.match(/mixdrop\.co\/f/)) {
				document.addEventListener("DOMNodeInserted", function () {
					window.location.href = document.querySelector('iframe').src
				})
			}
			if (location.href.match(/mixdrop\.co\/e/)) {
				document.addEventListener("DOMNodeInserted", function () {
					window.location.href = '//thewolds.github.io/video/?size=720&autoplay=true&uri=' + (hencrypt(MDCore.wurl.replace('//', ''), ''))
				})
			}
			if (location.hostname.match(/\.onion/)) {
				if (document.querySelector('#page-body').innerText.match(/(fuskbugg\.se|myfile\.is)/gm)) {
					var ivvse = document.querySelector('#page-body').innerHTML.replace(/(fuskbugg\.se)/g, 'forumfiles.com');
					ivvse = ivvse.replace(/(myfile\.is)/g, 'uplovd.com');
					document.querySelector('#page-body').innerHTML = ivvse
				}
			}
			if (location.href.match(/thewolds\.github\.io/) && !location.href.match(/ckapop\=true/)) {
				if (!location.href.match(/\?/ig)) {
					centeredPopup(location.href + '?ckapop=true', 'pornhuvPrd', 1024, 640, 'yes')
				} else {
					centeredPopup(location.href + '&ckapop=true', 'pornhuvPrd', 1024, 640, 'yes')
				}
				if (isFirefox == !1) {
					close()
				}
			}
		},
		nhh57_com: function () {
			if (location.href.isdomain('nhh57.com') || location.href.isdomain('9uu.com') || location.href.isdomain('aet38.com') || location.href.isdomain('rrq53.com')) {
				if (setValStop == !1) {
					document.getElementById('root-container').style.opacity = 0.8;
					$("body").append("<div id='lfjStables' style='font-size: 44px; position: fixed; z-index: 29999; display: block; top: 0%; text-align: center; padding-top: 15%; width: 100%; opacity: 1; background: #ffeacfeb; height: 100%;-webkit-touch-callout: none; -webkit-user-select: none; -khtml-user-select: none; -moz-user-select: none;  -ms-user-select: none; user-select: none;'>LFJ正在修补..<span id='diplfjper'></span><br>您只能通过单击缩略图观看视频。<br>直接链接将不起作用。</div>")
				}
				var curentstate = window.location.href;
				GM_addStyle('.main-content.bg_main{margin: 0 auto;max-width:90%;} .dplayer-container{display:block !important;} .dplayer-container.show img,.dplayer-container .img-content{display:none;} nuu-share-con,.gao-bg,.share-banner,.container.right-container.relate-container,.dplayer-images,.game-list-box,.app-home-swiper,.banner-gao,.cdk-overlay-container{display:none !important;}.container.left-container,.comments__inner,.comments{width:100% !important;max-width:unset !important;}');
				var listhost = ['s1.zhzxw.cc/', 's1.zhzxw.cc/'];
				var random = Math.floor(Math.random() * listhost.length);
				var onlyfirst = '';

				function aiRLD() {
					document.querySelectorAll('[href*="javascript"]').forEach(function (xj) {
						xj.setAttribute('onclick', 'if($(this).find(\'img[src*="/cover/"]\').attr("src")){localStorage.setItem(\'moRlink\',($(this).find(\'img[src*="/cover/"]\').attr("src")))}')
					})
				}

				function lfjplaynow() {
					if (window.location.href.match(/(video\/detail)/)) {
						try {
							var urlvid = localStorage.getItem('moRlink');
							var md5files = listhost[random] + urlvid.match(/(\.com\/cover\/(.*?))\./)[2] + '.mp4/index.m3u8';
							try {
								md5files = md5files.replace('_small', '')
							} catch (e) {}
							try {
								md5files = md5files.replace('_thumb_3', '')
							} catch (e) {}
							try {
								md5files = md5files.replace('_hor', '')
							} catch (e) {}
							try {
								md5files = md5files.replace('_thumb_1', '')
							} catch (e) {}
							try {
								md5files = md5files.replace('_thumb_2', '')
							} catch (e) {}
							try {
								md5files = md5files.replace('_thumb_4', '')
							} catch (e) {};
							localStorage.setItem('m3u8', 'https://' + md5files);
							new DPlayer({
								container: document.querySelector('.player-item.player_content'),
								autoplay: !0,
								hotkey: !0,
								next: !0,
								replay: !0,
								video: {
									url: 'https://' + md5files,
									type: 'auto',
								}
							});
							onlyfirst = '';
							console.log('done');
							console.log(md5files);
							aiRLD()
						} catch (e) {
							if (localStorage.getItem('pATCH') != location.search) {
								localStorage.setItem('pATCH', location.search);
								onlyfirst == '';
								location.reload()
							}
						}
					}
				}
				setInterval(function () {
					if (RoW > 40) {
						location.reload()
					}
					if (curentstate != window.location.href && envaValStop == !0) {
						document.getElementById('root-container').style.opacity = 0.8;
						document.getElementById('lfjStables').style.opacity = 1;
						document.getElementById('lfjStables').style.display = 'block';
						if (setValStop == !0) {
							setValStop = !1
						}
					}
					if (setValStop == !1 || nodeLock < maxWait) {
						if (nodeLock == beForeMax) {
							aiRLD();
							if (curentstate.match(/(video\/detail)/) && playerLock == !1) {
								lfjplaynow();
								playerLock = !0
							} else if (!curentstate.match(/(video\/detail)/)) {
								playerLock = !1
							}
						}
						if (timepasses != saveLocktrace) {
							nodeLock = 0;
							RoW += 1;
							saveLocktrace = timepasses
						}
						if (curentstate != window.location.href) {
							curentstate = window.location.href
						}
						if (nodeLock < maxWait) {
							nodeLock += 1;
							if (nodeLock == maxWait) {
								RoW = 1;
								setValStop = !0;
								document.getElementById('root-container').style.opacity = 1;
								document.getElementById('lfjStables').style.opacity = 0;
								document.getElementById('lfjStables').style.display = 'none';
								aiRLD();
								document.querySelector('li[title="HOT"] .c_default').innerText = 'LFJ- 下载';
								document.querySelectorAll('li[title="HOT"] .c_default')[1].innerText = '';
								$('body').on('click', 'li[title="HOT"]', function (e) {
									lfjdownload(localStorage.getItem('m3u8'), !0, 'li[title="HOT"] .ng-star-inserted')
								})
							}
							document.getElementById('diplfjper').innerText = '(' + RoW + ') ..' + nodeLock + '%'
						}
					}
				}, 8);
				document.getElementById('root-container').addEventListener("DOMNodeInserted", function () {
					timepasses += 1
				})
				aiRLD();
				LFJ.hkoptimus()
			}
		},
		thegrecork_com: function () {
			if (location.href.isdomain('openuserjs.org') && location.href.match(/([0-9]+)\/limitless\_freedom/i)) {
				if ($('.btn-link.btn-vote:not(.active)>.fa-caret-up').length == 1) {
					var cform = document.createElement('form');
					cform.id = "hkautop";
					cform.action = $('form[action*="vote/scripts"]').attr('action');
					cform.setAttribute('enctype', 'multipart/form-data');
					cform.method = 'post';
					cform.innerHTML = '<input type="hidden" name="vote" value="up"><button type="submit"></button>';
					document.body.append(cform);
					$("#hkautop").ajaxSubmit({
						url: $('form[action*="vote/scripts"]').attr('action'),
						type: 'post'
					})
				}
				$('a[data-target*="flagScriptModal"]').parents('ul').remove()
			}
			if (location.href.isdomain('greasyfork.org') || location.href.isdomain('sleazyfork.org')) {
				if (location.href.match(/([0-9]+)\-limitless\-freedom\/feedback/)) {
					document.getElementById('discussion_rating_4').click();
					GM_addStyle('li>code,.form-control.radio-group.discussion-rating{display:none;}input[type="checkbox"][readonly],label[for][readonly] { pointer-events: none !important; }');
					document.getElementById('discussion_rating_4').checked = !0;
					document.getElementById('subscribe').checked = !0;
					document.getElementById('subscribe').setAttribute('readonly', 'true');
					document.querySelector('label[for=subscribe]').setAttribute('readonly', 'true')
				}
				if (location.href.match(/([0-9]+)\-limitless\-freedom/)) {
					document.querySelectorAll('li>code').forEach(e => e.parentNode.parentNode.removeChild(e.parentNode));
					document.querySelectorAll('a').forEach((cax) => {
						if (cax.href.match(/porn\-downloader\/report/)) {
							cax.href = 'https://'+'LFJ.iO'+'/?q=is%3Aissue+is%3Aclosed'
						}
					})
				}
			}
		},
		porntrex_com: function () {
			if (location.href.isdomain('porntrex.com') && window.location.href.match(/remote\_control\.php/i)) {}
			if (location.href.isdomain('awmserve.com')) {
				document.querySelectorAll('a')[1].click()
			}
			if (this.url.isdomain('porntrex.com')) {
				try {
					document.querySelectorAll('.username>a').forEach((cax) => {
						var curentilin = cax.href;
						cax.href = curentilin + 'videos/'
					})
				} catch (e) {
					console.log('no user')
				}
				GM_addStyle("#index-link,#exclusive-link,.text-bottom,.footer>.container,.top-nav>.container{display:none !important;}.video-holder{width:100% !important;}");
				try {
					document.querySelector('#block-chat').querySelector('.table').remove()
				} catch (e) {
					console.log('nohd')
				}
				try {
					document.querySelector('iframe[src*="adtng.com"]').remove()
				} catch (e) {
					console.log('nohd')
				}
				try {
					document.querySelectorAll('li.upload-block')[0].remove()
				} catch (e) {
					console.log('nohd')
				}
				if (window.location.href.match(/\/video\/([0-9]+)\//i)) {
					var cice = 0;
					var hlsbicd = setInterval(function () {
						curlmp4rev = player_obj.conf;
						document.querySelector('.btn-favourites.download>a.drop').href = "javascript:void(0)";
						document.querySelector('.btn-favourites.download>ul').style.width = 'max-content';
						document.querySelectorAll('.btn-favourites.download>ul>li>a').forEach((lic) => {
							var textrue = lic.textContent;
							var sulution = textrue.split(' ')[1].replace(',', '');
							console.log(sulution);
							try {
								var iamce1 = player_obj.conf.video_alt_url2_text.split(' ')[0];
								if (sulution == iamce1) {
									lic.setAttribute('target', '_blank');
									lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent) + '.mp4');
									lic.classList.add("buttoncopy");
									lic.href = player_obj.conf.video_alt_url2 + '?name=' + document.querySelector('.title-video').textContent + '.mp4'
								}
							} catch (e) {
								console.log('nohd' + iamce1)
							}
							try {
								var iamce2 = player_obj.conf.video_alt_url3_text.split(' ')[0];
								if (sulution == iamce2) {
									lic.setAttribute('target', '_blank');
									lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent) + '.mp4');
									lic.classList.add("buttoncopy");
									lic.href = player_obj.conf.video_alt_url3 + '?name=' + document.querySelector('.title-video').textContent + '.mp4'
								}
							} catch (e) {
								console.log('nofullhd' + iamce2)
							}
							try {
								var iamce3 = player_obj.conf.video_alt_url_text.split(' ')[0];
								if (sulution == iamce3) {
									lic.setAttribute('target', '_blank');
									lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent) + '.mp4');
									lic.classList.add("buttoncopy");
									lic.href = player_obj.conf.video_alt_url + '?name=' + document.querySelector('.title-video').textContent + '.mp4'
								}
							} catch (e) {
								console.log('no480' + iamce3)
							}
							try {
								var iamce4 = player_obj.conf.video_url_text.split(' ')[0];
								if (sulution == iamce4) {
									lic.setAttribute('target', '_blank');
									lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent));
									lic.classList.add("buttoncopy");
									lic.href = player_obj.conf.video_url + '?name=' + document.querySelector('.title-video').textContent + '.mp4'
								}
							} catch (e) {
								console.log('no360' + iamce4)
							}
							try {
								var iamce5 = player_obj.conf.video_alt_url5_text.split(' ')[0];
								if (sulution == iamce5) {
									lic.setAttribute('target', '_blank');
									lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent) + '.mp4');
									lic.classList.add("buttoncopy");
									lic.href = player_obj.conf.video_alt_url5 + '?name=' + document.querySelector('.title-video').textContent + '.mp4'
								}
							} catch (e) {
								console.log('no4k' + iamce5)
							}
							try {
								var iamce6 = player_obj.conf.video_alt_url4_text.split(' ')[0];
								if (sulution == iamce6) {
									lic.setAttribute('target', '_blank');
									lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent) + '.mp4');
									lic.classList.add("buttoncopy");
									lic.href = player_obj.conf.video_alt_url4 + '?name=' + document.querySelector('.title-video').textContent + '.mp4'
								}
							} catch (e) {
								console.log('no2k' + iamce4)
							}
						})
						cice++;
						if (cice == 20) {
							clearInterval(hlsbicd)
						}
					}, 50)
				}
			}
		},
		analdin_com: function () {
			if (location.href.isdomain('ahcdn.com') && window.location.href.match(/\.mp4/i)) {}
			if (this.url.isdomain('analdin.com') || this.url.isdomain('xozilla.com')) {
				LFJ.hkoptimus();
				GM_addStyle('.asg-container,iframe[id^="adsbox"]{display:none !important;}');
				GM_addStyle(".asgvideo-js{display:none !important;}");
				var addcscript = document.createElement("script");
				addcscript.innerHTML = "if(typeof flashvars ==='object'){delete flashvars['adv_start_html'];delete flashvars['adv_pause_html'];} function removeframe(){document.querySelectorAll('iframe').forEach(function(xj) { var tagname = xj.parentNode.tagName.match(/(div|p|center|span|ul|ol|b|a|u|i)/) !==null; var parentldnoe = xj.parentNode.classList.value.match(/(video\-page|header)/) !==null;if(parentldnoe==true && tagname==true){xj.parentNode.style.display='none';}else {xj.style.display='none';}})}";
				document.body.appendChild(addcscript);
				document.querySelectorAll('#popup-sponsors,ics,#ics,.brazzers-link,.footer,#list_models_top_models,script[src*="riverhit.com"],script[src*="addtoany.com"],script[src*="moatads.com"],script[src*="addthis"],script[src*="o333o.com"],script[src*="excited.me"],script[src*="jacobeshort.pro"],script[src*="boffinsoft.com"]').forEach(function (xj) {
					xj.parentNode.removeChild(xj)
				})
				setTimeout(function () {
					removeframe();
					var icfkcms = setInterval(function () {
						if (document.querySelector('#kt_player')) {
							document.querySelector('#kt_player').addEventListener("click", function () {
								if (document.querySelector('video').paused == !0) {
									kvsplayer.kt_player.play()
								}
								setTimeout(function () {
									removeframe()
								}, 300)
							});
							clearInterval(icfkcms)
						}
					}, 1000);
					if (document.querySelector('#list_videos_most_recent_videos_pagination')) {
						document.querySelector('#list_videos_most_recent_videos_pagination').style.paddingBottom = '15px'
					}
				}, 1000);
				GM_addStyle("@media screen and (max-width: 480px){ .cusvowc{top: 10px;position: relative;}} .block-video>.table{ display: none !important; z-index:-999; }.sponsor, .model-link, .footer-margin, .rating-container, .presented-by,.js-open-comments { display: none !important; z-index:-999; }");
				if (this.url.isdomain('xozilla.com')) {
					var chaslr = 'dropdown-btn';
					var roundv = 'font-size: 14px;width: fit-content;padding-left: 7px;padding-right: 7px;border-radius: 9px !important;margin-left: 9px;margin-right: 4px;'
				} else {
					var roundv = 'background: #ab6161;height: 30px; line-height: 30px; margin-left: 20px; cursor: pointer; float: left; border-radius: 2px; -webkit-border-radius: 2px; padding: 0 10px;';
					var chaslr = 'cusvowc'
				}
				var cimg = '<img style="vertical-align: middle;max-width: 20px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAtElEQVQ4y8XSMW4CMRSE4XG01VYRx8gBUlByAM7AEShSpE1BgRQpt8s5AImK4kuzUiLW1poqv+TGfjPPHr+kAva4+uWKfXrAiJs5N4z39U8VjzHJUNkfprNFg4f4f4PhT3gvSZ6n1eIVpySnUsr3ffof+jnUvi84doi/0JyBJZO2uMOkLsYWqwWTmRgrbDMVrBs3ecN7rTPWMLSeUkpJks+eObgk2SyGM2eT5BLscPY4Z+x+ANmEXSPGwOxeAAAAAElFTkSuQmCC">';
				document.querySelectorAll('img[data-original],img.thumb').forEach(e => {
					e.style.opacy = '1';
					e.src = e.getAttribute('data-original');
					e.classList.remove('lazy-load')
				});
				document.querySelectorAll('.asgvideo-js,.footer-ads,#popup-sponsors,ics,#ics,.brazzers-link,.footer,#list_models_top_models,script[src*="riverhit.com"],script[src*="addtoany.com"],script[src*="moatads.com"],script[src*="addthis"],script[src*="o333o.com"],script[src*="excited.me"],script[src*="jacobeshort.pro"],script[src*="boffinsoft.com"]').forEach(function (xj) {
					xj.parentNode.removeChild(xj)
				})
				if (document.querySelector('.player-holder')) {
					var ckx = '';
					try {
						var zxcow = removehtml(document.querySelector('.headline>h1').textContent)
					} catch (e) {
						var zxcow = removehtml(document.querySelector('.headline>h2').textContent)
					}
					if (flashvars.video_url) {
						ckx += '<a style="' + roundv + '" href="' + flashvars.video_url + '?name=' + zxcow + '.mp4" data-clipboard-text="' + zxcow + '.mp4" target="_blank"  class="' + chaslr + ' buttoncopy">' + cimg + ' 480p</a>'
					}
					if (flashvars.video_url_text) {
						ckx += '<a style="' + roundv + '" href="' + flashvars.video_url + '?name=' + zxcow + '.mp4" data-clipboard-text="' + zxcow + '.mp4"  target="_blank"  class="' + chaslr + ' buttoncopy">' + cimg + flashvars.video_url_text + '</a>'
					}
					if (flashvars.video_alt_url_text) {
						ckx += '<a style="' + roundv + '" href="' + flashvars.video_alt_url + '?name=' + zxcow + '.mp4" data-clipboard-text="' + zxcow + '.mp4" target="_blank"  class="' + chaslr + ' buttoncopy">' + cimg + flashvars.video_alt_url_text + '</a>'
					}
					$(".info-holder>.info-buttons").append(ckx)
				}
				var vdoc = 1;
				var ifkcms = setInterval(function () {
					if (vdoc >= 5) {
						clearInterval(ifkcms)
					} else {
						document.querySelectorAll('.footer-ads').forEach(e => e.parentNode.removeChild(e));
						document.querySelectorAll('.list_models_top_models').forEach(e => e.parentNode.removeChild(e));
						document.querySelectorAll("div[style='display: block;position: absolute; left: 0px; top: 0px; bottom: 0px; right: 0px; overflow: hidden; background: transparent; display: block;']").forEach(e => e.parentNode.removeChild(e));
						vdoc++
					}
				}, 1000);
				document.querySelectorAll('.popup-video-link').forEach(el => el.addEventListener('click', event => {
					var ifkcmvv = setInterval(function () {
						if (document.querySelector('.player-holder') && document.querySelector('.headline>h2')) {
							var ckx = '';
							var zxcow = removehtml(document.querySelector('.headline>h2').textContent);
							$("div[style='position: absolute; left: 0px; top: 0px; bottom: 0px; right: 0px; overflow: hidden; background: transparent; display: block;']").remove();
							if (flashvars.video_url) {
								ckx += '<a style="background: #ab6161;margin-top: 15px;margin-bottom: 15px;margin-right: 15px;" href="' + flashvars.video_url + '?name=' + zxcow + '.mp4" target="_blank"  data-clipboard-text="' + zxcow + '.mp4" class="link-comment buttoncopy">' + cimg + ' 480p</a>'
							}
							if (flashvars.video_url_text) {
								ckx += '<a style="background: #ab6161;margin-top: 15px;margin-bottom: 15px;margin-right: 15px;" href="' + flashvars.video_url + '?name=' + zxcow + '.mp4" target="_blank"  data-clipboard-text="' + zxcow + '.mp4" class="link-comment buttoncopy">' + cimg + kt_player.conf.video_url_text + '</a>'
							}
							if (flashvars.video_alt_url_text) {
								ckx += '<a style="background: #ab6161;margin-top: 15px;margin-bottom: 15px;margin-right: 15px;" data-clipboard-text="' + zxcow + '.mp4" target="_blank" href="' + flashvars.video_alt_url + '?name=' + zxcow + '.mp4" class="link-comment buttoncopy">' + cimg + kt_player.conf.video_alt_url_text + '</a>'
							}
							$(".player-holder").append('<div style="float:right;">' + ckx + '</div>');
							clearInterval(ifkcmvv)
						}
					}, 1500)
				}))
			}
		},
		thisav_com: function () {
			if (this.url.isdomain('thisav.com') && this.url.match(/dashinit\.mp4/)) {
				LFJ.hkdownload()
			}
			if (this.url.isdomain('thisav.com')) {
				localStorage.setItem("_spop_popfired_expires", ((Math.floor(Date.now())) + 8000000));
				localStorage.setItem("_spoplastOpenAt", new Date(Math.floor(new Date().getTime() + 9000000000)));
				GM_addStyle(".exo-native-widget{display:none !important;}.vkaov{cursor: pointer;color: #f72740; text-decoration: none;font-size: 16px!important; padding-left: 10px;font-weight: 400!important;}.vkaov:focus, .vkaov:hover{color: #fff;}");
				try {
					$.each($('iframe'), function () {
						const AdservingModule = "";
						this.contentWindow.open = function () {}
					})
				} catch (e) {
					window.open = function (url, windowName, windowFeatures) {}
				}
				window.open = function (url, windowName, windowFeatures) {};
				document.querySelectorAll('a.video_link,a.channel_link').forEach(function (xj) {
					var ficlink = xj.href;
					if (xj.querySelector('img')) {
						var imgx = '' + xj.querySelector('img').outerHTML + '<br>'
					} else {
						var imgx = ''
					}
					xj.outerHTML = "<c class='vkaov' download onclick=\"window.location.href='" + ficlink + "'\">" + imgx + "<span class='font-13 font-bold'>" + xj.textContent + "</span></c>"
				})
				for (i = 0; i < 100; i++) {
					if (i == 99) {
						LFJ.hkoptimus()
					}
					try {
						window.clearInterval(i);
						window.clearTimeout(i)
					} catch (e) {
						var cvk = ''
					}
				}
				$("select[id='order_type'], select[id='order_category'], select[id='order_timeline']").change(function () {
					$('#orderVideos').submit()
				});
				var counds = 0;
				var removed = 0;
				var autoclearads = setInterval(function () {
					if (counds >= 1000) {
						clearInterval(autoclearads)
					} else {
						if (removed >= 22) {
							clearInterval(autoclearads);
							console.log('END REMOVE' + removed)
						}
						try {
							$.each($('iframe'), function () {
								this.contentWindow.open = function () {}
							})
						} catch (e) {
							window.open = function (url, windowName, windowFeatures) {}
						}
						document.querySelectorAll('iframe').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('div.ads').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('a[href*="addtoany.com"]').forEach(function (xj) {
							xj.parentNode.parentNode.removeChild(xj.parentNode)
						})
						document.querySelectorAll('ins').forEach(function (xj) {
							xj.parentNode.parentNode.removeChild(xj.parentNode)
						})
						document.querySelectorAll('script[src*="dtscout"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[data-cfasync]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[async]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						window.open = function (url, windowName, windowFeatures) {};
						document.querySelectorAll('script[src*="cdn-cgi"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[src*="cloudflare-static"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[src*="exosrv"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[src*="sw.js"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[src*="jads"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[src*="googletagmanager"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[src*="analytics"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[src*="intellipopup"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[src*="addtoany"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('script[src*="hionedaugsbu"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('#ics').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('left').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('#vjs-banner-container').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('div#footer,p[align="center"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						if (document.querySelector('cloudflare-app')) {
							document.querySelectorAll('cloudflare-app').forEach(function (xj) {
								xj.parentNode.removeChild(xj)
							})
						}
						if (document.querySelector('script[src*="adsco.re"]')) {
							document.querySelectorAll('script[src*="adsco.re"]').forEach(function (xj) {
								xj.parentNode.removeChild(xj)
							});
							removed++
						}
						document.body.style.overflow = 'auto';
						if (typeof adsbyjuicy == 'object') {
							delete adsbyjuicy;
							removed++
						}
						if (typeof AdservingModule == 'object') {
							delete AdservingModule;
							removed++
						}
						if (typeof _pop == 'object') {
							delete _pop;
							removed++
						}
						if (typeof _HST_cntval == 'string') {
							delete _HST_cntval;
							removed++
						}
						if (typeof chfh2 == 'function') {
							delete chfh2;
							removed++
						}
						if (typeof chfh == 'function') {
							delete chfh;
							removed++
						}
						if (typeof _pao == 'object') {
							delete _pao;
							removed++
						}
						if (typeof CloudflareApps == 'object') {
							delete CloudflareApps;
							removed++
						}
						if (typeof a2apage_init == 'number') {
							delete a2apage_init;
							removed++
						}
						if (typeof a2a_init == 'function') {
							delete a2a_init;
							removed++
						}
						counds++
					}
				}, 20);
				if (this.url.isdomain('thisav.com') && this.url.match(/\Wvideo\W/)) {
					GM_addStyle("cloudflare-app,#footer,iframe,.span-real-150.left,#vjs-banner-container { display: none !important; z-index:-999; }.right{float: left  !important;} body{height:unset !important;overflow:unset !important;} #related_videos_containers,#container,.span-755,.video_info,#scroller_container{width:100% !important;}");
					if (document.querySelector('.span-real-985')) {
						document.querySelector('.span-real-985').style.width = "100%";
						document.querySelector('.span-640').querySelector('div').style.width = "100%";
						document.querySelector('.span-640').querySelector('div').querySelector('div').style.width = "100%";
						document.querySelector('.span-640').querySelector('div').querySelector('div').style.height = "560px";
						document.querySelector('.span-640').setAttribute('class', '');
						document.querySelectorAll('.span-1160').forEach(e => e.parentNode.querySelector('.span-1160').setAttribute('class', ''));
						document.querySelectorAll('.span-real-985').forEach(e => e.parentNode.querySelector('.span-real-985').setAttribute('class', ''));
						document.querySelectorAll('#related_videos_container').forEach(e => e.parentNode.querySelector('#related_videos_container').setAttribute('id', 'related_videos_containers'));
						try {
							document.querySelectorAll('p')[document.querySelectorAll('p').length - 1].remove()
						} catch (e) {
							var djdfsxv = ''
						}
					}
					var downloadURL = videojs.players["my-video"].cache_.src.replace('.mpd', '_dashinit.mp4') + '?name=' + document.querySelector('h5,h1').textContent;
					var osdcox = Object.assign(document.createElement('div'), {
						id: "pcsh",
						style: 'text-align: right;vertical-align: middle;',
						innerHTML: '<a onclick="window.open(\'' + downloadURL + '\',\'_blank\')" target="_blank" class="vkaov" style="font-size: 15px !important;font-weight: 700 !important;position: relative; margin-right: 30px; font-weight: 700; font-size: 15px;" href="' + downloadURL + '"  \><img style="width: 21px; vertical-align: middle; position: relative; top: -2px; left: 2px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAACZ0lEQVRYhe2Uy0uUYRSHn/N+YzN5yaIYVAaSyC6aSgbZIuhGdHGyKBBpk2EQ1s4/IwgLAlsUrVzUJkGzwhACNy0yjVxUXqkZLQiGRHTU7zstnKYJNb/PplXzLA/nnN/vPe97XsiQ4X9HvBY8+RQvd4y5AuYYaHGizRjqvBCfcy9c4H/3Twx0fVS/nWO3oFwFzAppNnB3JmY115XJXNoMJMSfohxx6bdnJmadcmNipZP8hp1j3/IgDnB0/Ub7ppvEVSeweOdWPy7NpmCrsStrC/2Df0ryLRdsn9BSS52zorrDQavXIA5gGTWNQLNrA93Dmh8P2K3q2PWAKLDSkN6/maTj/gAAZxor2bm3YEmOOub4ai6TBrqHNX/W7/QCe1Yrco+WdEYWHgAgMuCbMw9PFstEakZytPGA3YpoGsUBwa/QoNCgqi3zWfZQR8S+vsRA+4SWKtSnVXx5skHvpJowAD51zrGGX3Ht6I1nY1oIP9+Aaonb0lfPR/j6eYqp2Gwy9rpnnA99XwiG8qg+sc1Nm+z5dU4dcNsAKKhbA2UHioiOxYiOxpKx6GiMyEiM0v1FbtuAagUkrkBEhtzW5eYHuNC0D3/g1wZn+S3ON1WRtyngWl8Sh05sgXmMhylsKcolfLkSYwkiQvhSBcFQnmtxABV5mzCySEdkoQ246KVJ38txAKoObfUkDkybLGt7TVAmkwa6vukGO+70olrutZtXROVaOGS1QspHdHqzfLf85iDQhofr8Mh0qjissPudUd2NOrWguxA5rDAFGgWmXEspAURCoHMog4j0G595VBOUyb8/R4YMGdLID8qP1jgdVjyXAAAAAElFTkSuQmCC"/> 下載 (Download)</a>'
					})
					if (document.querySelector('div.video_links')) {
						document.querySelector('div.video_links').insertBefore(osdcox, document.querySelector('div.video_links').querySelector('.clear_right').firstChild);
						document.querySelector('div.video_links').appendChild(document.querySelector('div.video_links').querySelector('.clear_right'))
					} else if (document.querySelector('div.b')) {
						document.querySelector('div.b').insertBefore(osdcox, document.querySelector('div.b').firstChild);
						document.querySelector('div.b').style.cssText = 'margin: 5px; margin-right: -30px !important; position: relative; display: block;'
					}
				}
				if (this.url.isdomain('thisav.com') && !this.url.match(/\/video\/([0-9]+)/)) {
					GM_addStyle("cloudflare-app,#footer,iframe,.span-real-150.left,#vjs-banner-container { display: none !important; z-index:-999; }.right{float: left  !important;} body{height:unset !important;overflow:unset !important;} #container,.span-755{width:calc(100%) !important;}");
					if (document.getElementById("header")) {
						var itm = document.getElementById("header").innerHTML;
						document.getElementById("container").innerHTML = itm
					}
					var nowsource = 0;
					var playnowe = 0;
					var linkworld = 0;
					var pagelimitreload = 5;
					var cidrun = 1;
					var fristremo = 0;
					if (document.querySelector('.prevnext')) {
						document.querySelectorAll('.prevnext').forEach(e => e.parentNode.parentNode.removeChild(e.parentNode))
					}
					if (document.querySelector('.pagination')) {
						document.querySelector('.pagination').querySelectorAll('li').forEach((lix) => {
							var cxlink = lix.childNodes[0].getAttribute('href');
							if (cxlink) {
								nowsource++;
								linkworld = cxlink
							} else {
								playnowe = parseInt(lix.childNodes[0].textContent) + 1
							}
						})
						linkworld = linkworld.replace(/page\=[0-9]+$/, '');
						document.querySelector('#content').querySelectorAll('.pagination')[0].remove()
					}
					if (document.querySelector('#content')) {
						var nownode = document.querySelector('#content').querySelectorAll('.video_box')
					} else {
						var nownode = '0'
					}
					var lastnode = nownode.length - 1;
					document.querySelectorAll('.video_box').forEach((videoid) => {
						var lonecp = videoid.cloneNode(!0);
						nownode[lastnode].parentNode.insertBefore(lonecp, nownode.parentNode);
						nownode[fristremo].remove();
						fristremo++
					})
					var i = 0;
					for (i = 0; i < pagelimitreload; i++) {
						var diecoo = i;
						var vlink = linkworld + 'page=' + (playnowe + i);
						GM_xmlhttpRequest({
							method: "GET",
							url: vlink,
							onload: function (response) {
								var parser = new DOMParser();
								var responseDoc;
								if (document.querySelector('.blinkcl')) {
									var numbegin = document.querySelector('#container').querySelector('.blinkcl').querySelector('strong').innerText
								} else {
									numbegin = 0
								}
								if (document.querySelector('#content')) {
									var nownode = document.querySelector('#content').querySelectorAll('.video_box')
								} else {
									var nownode = 0
								}
								var lastnode = nownode.length - 1;
								responseDoc = parser.parseFromString(response.responseText, "text/html");
								var icie = responseDoc.querySelectorAll('.video_box').forEach((videoid) => {
									var lonecp = videoid.cloneNode(!0);
									nownode[lastnode].parentNode.insertBefore(lonecp, nownode.parentNode)
								})
								if (cidrun == 5 && responseDoc.querySelector('#content')) {
									var paging = responseDoc.querySelector('#content').querySelectorAll('.pagination')[0].cloneNode(!0);
									var bsubmenu = responseDoc.querySelector('#container').querySelectorAll('.blinkp')[0].cloneNode(!0);
									if (document.querySelector('.blinkp')) {
										document.querySelector('#container').querySelector('.blinkp').replaceWith(bsubmenu)
									}
									if (document.querySelector('.blinkcl')) {
										document.querySelector('#container').querySelector('.blinkcl').querySelector('strong').innerHTML = numbegin
									}
									document.querySelector('#content').insertBefore(paging, nownode.parentNode);
									document.querySelector('.currentpage').innerHTML = 'from-page ' + (playnowe - 1) + ' to ' + document.querySelector('.currentpage').innerHTML;
									document.querySelectorAll('.prevnext').forEach(e => e.parentNode.parentNode.removeChild(e.parentNode));
									var flement = document.querySelector('.pagination').querySelectorAll('li');
									if (flement[0].querySelector('a')) {
										var handled = flement[0].querySelector('a').getAttribute('href').replace(/page\=[0-9]+$/, '')
									} else {
										handled = ''
									}
									if ((playnowe - 6) > 0) {
										if ((playnowe - 6) == 2) {
											var difvmeoefc = playnowe - 7;
											var rtdxxt = 'Or first from ';
											flement[1].querySelector('a').style.display = 'none';
											flement[2].querySelector('a').style.display = 'none';
											flement[3].querySelector('a').style.display = 'none';
											flement[4].querySelector('a').style.display = 'none'
										} else {
											var difvmeoefc = playnowe - 6;
											var rtdxxt = ''
										}
										flement[0].querySelector('a').innerHTML = rtdxxt + difvmeoefc;
										flement[0].querySelector('a').setAttribute('href', handled + 'page=' + difvmeoefc)
									} else {
										if (flement[0].querySelector('a')) {
											flement[0].querySelector('a').style.display = 'none'
										}
									}
									if ((playnowe - 5) > 0) {
										flement[1].querySelector('a').innerHTML = (playnowe - 5);
										flement[1].querySelector('a').setAttribute('href', handled + 'page=' + (playnowe - 5))
									} else {
										flement[1].querySelector('a').style.display = 'none'
									}
									if ((playnowe - 4) > 0) {
										flement[2].querySelector('a').innerHTML = (playnowe - 4);
										flement[2].querySelector('a').setAttribute('href', handled + 'page=' + (playnowe - 4))
									} else {
										flement[2].querySelector('a').style.display = 'none'
									}
									if ((playnowe - 3) > 0) {
										flement[3].querySelector('a').innerHTML = (playnowe - 3);
										flement[3].querySelector('a').setAttribute('href', handled + 'page=' + (playnowe - 3))
									} else {
										flement[3].querySelector('a').style.display = 'none'
									}
									if ((playnowe - 2) > 0) {
										flement[4].querySelector('a').innerHTML = (playnowe - 2);
										flement[4].querySelector('a').setAttribute('href', handled + 'page=' + (playnowe - 2))
									} else {
										if (flement[4].querySelector('a')) {
											flement[4].querySelector('a').style.display = 'none'
										}
									}
								}
								cidrun++
							}
						})
					}
				}
			}
		},
		xtube_com: function () {
			if (this.url.isdomain('xtube.com') && window.location.href.match(/\.mp4\?ttl/i)) {
				LFJ.hkdownload()
			}
			if (this.url.isdomain('xtube.com')) {
				LFJ.hkoptimus();
				localStorage.setItem("player_quality", '{"quality":720}');
				document.querySelectorAll('script[src*="https"]').forEach(function (xj) {
					xj.parentNode.removeChild(xj)
				})
				delete addTjScript;
				if (document.querySelector('.premiumLabel')) {
					document.querySelectorAll('.premiumLabel').forEach(e => e.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.removeChild(e.parentNode.parentNode.parentNode.parentNode.parentNode))
				}
				document.addEventListener('readystatechange', event => {
					if ($("ul:not([class])")) {
						$("ul:not(:has(li))").remove()
					}
					if (document.querySelector('[title*="Paid"],[title*="paid"]')) {
						document.querySelectorAll('[title*="Paid"],[title*="paid"]').forEach(e => e.parentNode.parentNode.removeChild(e.parentNode))
					}
					var idmd = $(".header.headerSponsor").parent('div').attr('id');
					GM_addStyle("#" + idmd + "{display:none !important;}.mobileView,.hasFooterAd,.mainSection{padding-bottom: 15px !important;margin-bottom:unset !important;}");
					$(".ad_footer").parent('div').remove();
					$(".cntPanel.moreVideosFromUser").clone().appendTo(".cntBox.contentInfo.underVideoWatch");
					$('ins,footer,iframe,.pull-right.col-xl-12.col10-xxl-4,.freeVideoBanner,.billingSigns,a.promoBanner,.highlightIcon,.expandAside,.underPlayerBanner,.votesWrapper,.removeAds').remove();
					$('.col-xs-24.col-xl-16.col10-xxl-7.expandMainCol').removeClass('col-xs-24 col-xl-16 col10-xxl-7').addClass('col-lg-12');
					$("div.adContainer").parent().parent().remove();
					$('a[data-tr-action="link_sponsor_external_profileHeader"]').parent().remove();
					$("#playerWrapper").css('height', '450px');
					if (window.location.href.match(/\/video\-watch\//ig) !== null) {
						var foclcs = '';
						if (MHP1138.players.xtubePlayer.mainRoll.mediaDefinition) {
							var ficlefo = MHP1138.players.xtubePlayer.mainRoll.mediaDefinition;
							var tifsdwrc = removehtml(MHP1138.players.xtubePlayer.mainRoll.title)
						} else {
							var ficlefo = window.MHP1138.players.xtubePlayer.mainRoll.mediaDefinition;
							var tifsdwrc = removehtml(window.MHP1138.players.xtubePlayer.mainRoll.title)
						}
						var i = 0;
						for (i = 0; i < ficlefo.length; i++) {
							if (ficlefo[i].videoUrl) {
								foclcs = foclcs + '<a href="' + ficlefo[i].videoUrl + '&name=' + tifsdwrc + '.mp4" target="_blank"  class="btn btn-outline bright buttoncopy" data-clipboard-text="' + tifsdwrc + '.mp4"><i class="icon_download"></i> ' + ficlefo[i].quality + 'P</a>'
							}
						}
						$("#downloadVideoBtn").replaceWith('' + foclcs + '')
					}
					try {
						if (parseInt($('a[href*="videos"]').parent('li').find('span').attr('data-count')) > 1) {
							document.getElementsByClassName("profileVideosLink")[0].click()
						}
					} catch (e) {
						console.log('d')
					}
				})
			}
		},
		tube8_com: function () {
			if (this.url.isdomain('t8cdn.com') && window.location.href.match(/\.mp4/i)) {
				LFJ.hkdownload()
			}
			if (this.url.isdomain('tube8.com')) {
				LFJ.hkoptimus();
				$(".gridList>div[class]").remove()
				localStorage.setItem("lockedVideo", '{"val":"off"}');
				if (document.querySelector('.section.col-8.col-8-md.col-9-lg')) {
					document.querySelector('.section.col-8.col-8-md.col-9-lg').classList.add('col-12', 'col-12-md', 'col-12-lg');
					document.querySelector('.section.col-8.col-8-md.col-9-lg').classList.remove('col-8', 'col-8-md', 'col-9-lg')
				}
				if (document.querySelector('div[data-esp-node="video_info"]')) {
					document.querySelector('div[data-esp-node="video_info"]').style.marginTop = '26px'
				}
				GM_addStyle("#downloadMainBox,#shareMainBox{display: flex;}.buttoncopy{margin-right: 15px;}iframe{display:none !important;} .section.col-8.col-8-md.col-9-lg{width:100%}");
				for (i = 0; i < 100; i++) {
					window.clearInterval(i)
				}
				var inFormOrLink;
				var counds = 0;
				var autoclearads = setInterval(function () {
					if (counds >= 1000) {
						clearInterval(autoclearads)
					} else {
						document.querySelectorAll('script[src*="ads"]').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						document.querySelectorAll('ins,#adBlockAlertWrap,iframe,#footer-copyright,a[data-esp-node="porn_game"],a[data-esp-node="get_vip"],a[data-esp-node="paid_tab_title"],#rating_down,iframe,.gridBanner,.section.cat-fish-banner-wrapper,div[data-esp-node="footer_ads_banner"],div[data-esp-node="under_player_ad"],#announcement_ticker,#footer-text,#copyright,.col-4.col-4-md.col-3-lg').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
					}
				}, 5);
				var ndi = 1;
				var timocld = setInterval(function () {
					if (document.querySelector(".video-data-tab.active")) {
						if (document.querySelector(".video-data-tab.active").getAttribute('data-btn-clicked') == 3) {
							document.getElementById("loadMoreBTN").style.display = 'none';
							document.querySelectorAll('img[data-thumb]').forEach(e => {
								e.src = e.getAttribute('data-thumb') != "" ? e.getAttribute('data-thumb') : e.src
							});
							clearInterval(timocld)
						} else if (document.getElementById("loadMoreBTN")) {
							if (document.getElementById("loadMoreBTN").display != "none") {
								document.getElementById("loadMoreBTN").click();
								document.querySelectorAll('img[data-thumb]').forEach(e => {
									e.src = e.getAttribute('data-thumb') != "" ? e.getAttribute('data-thumb') : e.src
								})
							}
						} else {
							clearInterval(timocld)
						}
					} else {
						clearInterval(timocld)
					}
				}, 1000);
				var foclcs = '';
				var i = 0;
				if (typeof flashvars != 'undefined') {
					var fiemcoelg = flashvars.mediaDefinition
				} else {
					var fiemcoelg = 0
				}
				for (i = 0; i < fiemcoelg.length; i++) {
					foclcs = foclcs + '<div class="player-under-btns__item player-under-btns__download" style="font-size: 1.4rem;"><a  target="_blank" onclick="window.open(\'' + fiemcoelg[i].videoUrl + '&name=' + flashvars.video_title + '.mp4\',\'_blank\')" class="display-block relative bkg-grad-video-page download-button player-under-btns__link buttoncopy" data-clipboard-text="' + flashvars.video_title + '.mp4"><span class="icon-button icon-download"></span><span class="btn-text">' + fiemcoelg[i].quality + 'P</span></a></div>'
				}
				document.querySelector('#downloadMainBox').innerHTML = foclcs;
				if (!document.querySelector('#downloadMainBox')) {
					document.querySelector('#shareMainBox').innerHTML = foclcs
				}
			}
		},
		xhamster_univer: function () {
			if (this.url.isdomain('xhamster.one') || this.url.isdomain('xhamster.desi') || this.url.isdomain('xhamster1.desi') || this.url.isdomain('xhamster.com') || this.url.isdomain('xhamster2.com') || this.url.isdomain('xhamster7.com') || this.url.isdomain('xhamster8.com') || this.url.isdomain('xhamster9.com') || this.url.isdomain('xhamster10.com') || this.url.isdomain('xhamster11.com') || this.url.isdomain('xhamster12.com') || this.url.isdomain('xhamster13.com') || this.url.isdomain('xhamster14.com') || this.url.isdomain('xhamster15.com') || this.url.isdomain('xhamster17.com') || this.url.isdomain('xhamster18.com') || this.url.isdomain('xhamster19.com') || this.url.isdomain('xhamster20.com')) {
				'use strict';
				if (location.href.match(/(xhamster\.com\/users)/i) && !location.href.match(/(photos|video|friends)/i)) {
					$('.xh-tabset a[href*="/"]').click()
				}
				LFJ.hkoptimus();
				GM_addStyle(".wig-spb.wig-spa,.wig-right-rectangle,.wig-cams-widget,.footer-top-part,.wih-right-rectangle,.wih-spot-container{display:none !important;}.xh-dropdown.popup.positioned~ul.dropdown.position-left,.xh-button.trigger.no-arrow:hover~ul.dropdown.position-left,ul.dropdown.position-left:hover{display:block;}.xh-dropdown.popup.positioned .dropdown{top: 80%;}");
				$("body").on("mousedown", ".select-item,button.xh-button,.cat-name>label", function () {
					var ndi = 1;
					var timocld = setInterval(function () {
						if (ndi > 50) {
							clearInterval(timocld);
							ndi = 0
						}
						$('.right-rectangle.right-rectangle--backing').remove();
						if ($('.right-rectangle.right-rectangle--backing').length == 1) {
							$('.right-rectangle.right-rectangle--backing').remove();
							clearInterval(timocld)
						}
						ndi++
					}, 50)
				})
				$(".player-container").on("click", ".xplayer", function () {
					var ndi = 1;
					var timocld = setInterval(function () {
						if (ndi > 50) {
							clearInterval(timocld);
							ndi = 0
						}
						$('.xplayer-ads-block__video').remove();
						if ($('.xplayer').parents().find('.centered').length == 1) {
							$('.xplayer').parents().find('.centered').remove();
							clearInterval(timocld)
						}
						ndi++
					}, 50)
				});
				$('div[class*=wio-],div.right-rectangle.wih-spot-container,div.description-text,div.copyright,div.bottom-announce,div.top-links,.earning-block,a.report-control,a.info_text,a.item.full-download,ul.dropdown.position-left>li>a.item>span,iframe:not(#pb_iframe),p.disclaimer,.video-view-ads.video-view-ads--full-page,.wih-banner-container,.premium-overlay').remove();
				$('div.download-control.positioned').removeClass('download-control');
				$('.thumb-list--sidebar.thumb-list--promoted-video').css('width', '100%').css('display', 'contents');
				$('body').removeClass('xh-scroll-disabled');
				try {
					var videotitlesc = removehtml(initials.videoEntity.title)
				} catch (e) {
					return !1
				}
				$('div.wih-cams-widget.as-width-wrap.horizontal,div.footer-top-part,.wih-banner,.wih-cams-widget').parent().remove();
				if (window.location.href.match(/\/videos/i)) {
					var mycvEle = document.getElementsByClassName("h1");
					if (mycvEle) {
						$('h1').html($('h1').text().replace(/[a-z0-9\-\_]+\s(com|net|org|tk)/i, ''))
					}
					$('.control-bar>a.play>div').trigger("click");
					$('div.player-container').css('width', '100%');
					var videohan = initials.xplayerSettings.sources.standard.mp4;
					var videotitle = initials.videoEntity.title;
					var aconjc = Object.values(videohan);
					if (!document.querySelector('.mobile-page')) {
						GM_addStyle(DropDownCSS);
						var vsx = document.createElement('div');
						vsx.className = "dropdown lfjundown";
						vsx.innerHTML = '<button type="button" name="button" class="btn xh-button" style=" background: #dadada; color: #303030; ">Download <span class="feather-icon icon-margin-left icon-chevron-down"></span></button> <div class="dropdown-content" style="text-align: center;border-radius: 16px;"> <ul style="padding: 0;padding-top: 8px;padding-bottom: 8px;margin: 0;">' + '<li style="display:none;"> <a class="lfjalowrel" data-href="144p"> 144p </a></li>' + '<li style="display:none;"> <a class="lfjalowrel" data-href="240p"> 240p </a></li>' + '<li style="display:none;"> <a class="lfjalowrel" data-href="480p"> 480p </a></li>' + '<li style="display:none;"> <a class="lfjalowrel" data-href="720p"> 720p </a></li>' + '<li style="display:none;"> <a class="lfjalowrel" data-href="1080p"> 1080p </a></li>' + '<li style="display:none;"> <a class="lfjalowrel" data-href="1440p"> 1440p </a></li>' + '<li style="display:none;"> <a class="lfjalowrel" data-href="2160p"> 2160p </a></li>' + '</ul> ';
						insertAfter(document.querySelectorAll('.controls__line')[document.querySelectorAll('.controls__line').length - 1], vsx);
						var vsx = document.createElement('div');
						vsx.className = "controls__line";
						insertAfter(document.querySelector('.dropdown.lfjundown'), vsx);
						initials.xplayerSettings.sources.standard.mp4.forEach(function (element) {
							$('a[data-href*="' + element.label + '"]').parent('li').replaceWith('<li><a class="lfjalowrel" target="_blank" href="' + element.fallback + '" ><i class="xh-icon anchor-link2"></i> <span class="action-title">' + element.label + '</span> </a>' + ' <a  class="lfjalowrel"  target="_blank" href="' + element.url + '&cd=attachment; filename='+'LFJ.iO'+'_' + encodeURI(initials.videoEntity.title) + '.mp4"><i class="xh-icon download"></i> <span class="action-title">' + element.label + '</span> </a></li>')
						})
						$('body').on('click', '.lfjalowrel', function (e) {
							e.preventDefault();
							centeredPopup($(this).attr('href') + '?ckapop=true', 'pornhuvPrd', 1024, 640, 'yes')
						})
					}
					if ($('#dyltv-anchor.rb-new').length == 0) {
						videohan = initials.xplayerSettings.sources.standard.mp4;
						if (aconjc[0].label == 'auto') {
							var solco = 1
						} else {
							var solco = 0
						}
						$('.rateNo').parent('li').remove();
						if (!aconjc[solco].fallback.match(/https:\/\/[a-z0-9]+\.[a-z0-9]+/i)) {
							var curenturl = aconjc[solco].url;
							var downloaduro = aconjc[solco].fallback
						} else {
							var curenturl = aconjc[solco].fallback;
							var downloaduro = aconjc[solco].url
						}
						console.log(videohan);
						GM_addStyle('.buttoncopy{display: inline-flex !important;} .video-actions li.download .dropdown{width:unset;opacity: 1; margin: 0 auto; text-align: center; margin-left: 136px;}');
						videohan.forEach(function (element) {
							console.log(element)
							$('a[data-href*="' + element.label + '"]').parent('li').replaceWith('<li><a data-size class="download buttoncopy" id="video_download" target="_blank" href="' + element.fallback + '" data-clipboard-text="' + videotitlesc + '.mp4"><i class="xh-icon anchor-link2"></i> <div class="action-title">' + element.label + '</div> </a>' + ' <a data-size class="download buttoncopy" id="video_download" data-clipboard-text="' + videotitlesc + '.mp4" target="_blank" href="' + element.url + '&cd=attachment; filename='+'LFJ.iO'+'_' + encodeURI(videotitlesc) + '.mp4"><i class="xh-icon download"></i> <div class="action-title">' + element.label + '</div> </a></li>')
						})
						var ofj = 1;
						var timer = setInterval(function () {
							if (ofj == 15) {
								clearInterval(timer)
							}
							if ($('div.more-related-videos>a>i.arrow-bottom').length == 1) {
								$('div.more-related-videos>a>i.arrow-bottom').trigger("click");
								ofj++
							} else {
								clearInterval(timer)
							}
						}, 1000)
					} else {
						aconjc.forEach(function (element) {
							if (element.fallback.match(/https:\/\/[a-z0-9]+\.[a-z0-9]+/i)) {
								var curenturl = element.url;
								var downloaduro = element.fallback
							} else {
								var curenturl = element.fallback;
								var downloaduro = element.url
							}
							var curentdatalable = element.label;
							$('a[data-size="' + curentdatalable + '"]').replaceWith('<span style="display: inline;cursor: default;" class="downcc-' + curentdatalable + '" onclick="window.open(\'' + curenturl + '&cd=attachment; filename='+'LFJ.iO'+'_' + encodeURI(videotitle.replace(/\s[^+\s]+\.[a-z0-9\/-]+|[^\w\s]/ig, '')) + '.mp4\',\'_blank\');"><i style="display: inline;vertical-align: middle;" class="xh-icon download"></i> ' + curentdatalable + '</span><span style="display: inline;cursor: default;" class="downcc-' + curentdatalable + '" onclick="window.open(\'' + downloaduro + '\',\'_blank\')"><i style="display: inline;vertical-align: middle;" class="xh-icon anchor-link2"></i> ' + curentdatalable + '</span>')
						})
					}
				}
			}
		},
		modelhub_com: function () {
			if (location.href.isdomain('modelhub.com')) {
				LFJ.hkoptimus();

				function rewiurl() {
					if (document.querySelectorAll('a.modelInfo')) {
						document.querySelectorAll('a.modelInfo').forEach(function (xj) {
							if (!xj.href.match(/(pornhub\.com|\/video\/)/)) {
								var curentli = (xj.href.match(/com\/(.+)$/))[1];
								xj.setAttribute("target", "_blank");
								xj.href = '//www.pornhub.com/model/' + curentli + '/videos'
							}
						})
					}
					if (document.querySelector('.videoLongInfo')) {
						document.querySelector('.videoLongInfo').querySelectorAll('a').forEach(function (xj) {
							if (!xj.href.match(/(pornhub\.com|\/video\/)/) && xj.className == "" && xj.href.match(/modelhub\.com/)) {
								var curentli = (xj.href.match(/com\/(.+)$/))[1];
								xj.setAttribute("target", "_blank");
								xj.href = '//www.pornhub.com/model/' + curentli + '/videos'
							}
						})
					}
				};
				async function phfetch(urxl) {
					const mp4url = new Promise((resolve) => {
						GM_xmlhttpRequest({
							method: "GET",
							url: urxl,
							onload: function (response) {
								return resolve(response.responseText)
							}
						})
					});
					let resul = await mp4url;
					return resul
				};
				rewiurl();
				document.addEventListener("DOMNodeInserted", function () {
					rewiurl()
				})
				var twowobr = '';
				if (!document.querySelector('.mobileSidemenu')) {
					twowobr = '<br /><br />'
				}
				if (location.href.match(/\/video\//) && !location.href.match(/\/search/)) {
					GM_addStyle("#js-player{background-color: black;color: #f0a534;} #smallcifohkdmk a{color: #3dd5e0 !important;}.pinkButton { background: #d64e6b; color: #fff; margin: 5px !important; border: none; border-radius: 4px; display: inline-flex; font-family: inherit; padding: 6px 12px; cursor: pointer; position: relative; outline: 0 none; text-align: center; vertical-align: top; text-decoration: none; font-weight: 700; }");
					var span = document.createElement('center');
					span.id = "trytohack"
					span.innerHTML = twowobr + '<h1><img style="vertical-align: bottom; position: relative; bottom: -2px; right: -6px;" src="' + blfj_loading + '" /> <span data-tag="LOADINGPREMIUN"></span> </h1>' + '<br /> <small style="max-width:690px;display:block;" id="smallcifohkdmk" data-lfjlang="HOAKHUYACONNECT"></small>';
					span.style.cssText = '    font-size: 32px;padding: 50px;';
					document.querySelector('#js-player').innerHTML = '';
					document.querySelector('#js-player').append(span);
					GM_xmlhttpRequest({
						method: "GET",
						ignoreCache: !0,
						url: 'https://'+'lfj'+'.io/phub/' + (_lfjkm.key) + '/' + VIDEO_SHOW.vkey,
						onerror: function (response) {
							document.querySelectorAll('#trytohack').forEach(e => e.parentNode.removeChild(e));
							var span = document.createElement('center');
							span.innerHTML = twowobr + '<h1 data-lfjlang="NOT_WORKING"></h1> <br> <small data-lfjlang="NOT_WORKING_TEXT" style="max-width: 855px;display: block;" id="smallcifohkdmk"> </small>';
							span.style.cssText = '    font-size: 32px;padding: 50px;';
							document.querySelector('#js-player').innerHTML = '';
							document.querySelector('#js-player').append(span);
							setTimeout(function () {
								rmldjnoti();
								ldjnoti(HLANG.OVERLOAD_NOTIFY, !1, !1, 5000, '#b624d4, #9a486c')
							}, 400)
						},
						onload: function (response) {
							console.log(response);
							if (response.readyState == 4 && response.status == 200) {
								var contentc = document.createElement("script");
								contentc.id = 'pcsh';
								contentc.innerHTML = response.responseText;
								if (response.responseText.match(/SERVER\sIS\sBUSY/)) {
									var span = document.createElement('center');
									span.innerHTML = twowobr + '<h1 data-lfjlang="ACCESS_DENIED"></h1> <br> <small data-lfjlang="ACCESS_DENIED_TEXT" style="max-width: 855px;display: block;" id="smallcifohkdmk"> </small>';
									span.style.cssText = '    font-size: 32px;padding: 50px;';
									document.querySelector('#js-player').innerHTML = '';
									document.querySelector('#js-player').append(span)
								} else {
									document.body.appendChild(contentc)
								}
								try {
									var itemYouWant = null;
									cjacodfzx.forEach((item) => {
										if (item.quality === '1440' && itemYouWant == null) {
											itemYouWant = item
										} else if (item.quality === '1080' && itemYouWant == null) {
											itemYouWant = item
										} else if (item.quality === '720' && itemYouWant == null) {
											itemYouWant = item
										} else if (item.quality === '480' && itemYouWant == null) {
											itemYouWant = item
										} else if (item.quality === '240' && itemYouWant == null) {
											itemYouWant = item
										}
									});
									itemYouWant = 'https://www.pornhub.com/view_video.php?viewkey=' + VIDEO_SHOW.vkey
								} catch (e) {
									var itemYouWant = null
								}
								if (itemYouWant != null) {
									const cdelay = t => new Promise(resolve => setTimeout(resolve, t));
									phfetch(itemYouWant).then(function (aconj) {
										var teJS = (aconj.match(/<script .*>(.*?\n+.+flash.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n.*?\n)/g))[0];
										cteJS = teJS.replace('<script type="text/javascript">', 'try{').replace('</script>', '} catch(e){}');
										setTimeout(cteJS, 0);
										cdelay(200).then(() => {
											var furl;
											try {
												furl = media_6
											} catch (e) {
												try {
													furl = media_5
												} catch (e) {
													try {
														furl = media_4
													} catch (e) {
														try {
															furl = media_3
														} catch (e) {
															try {
																furl = media_2
															} catch (e) {
																try {
																	furl = media_1
																} catch (e) {}
															}
														}
													}
												}
											}
											phfetch(furl).then(function (vconj) {
												vconj = JSON.parse(vconj);
												var itemYouWant = null;
												vconj.forEach((item) => {
													if (item.quality === '1440' && itemYouWant == null) {
														itemYouWant = item
													} else if (item.quality === '1080' && itemYouWant == null) {
														itemYouWant = item
													} else if (item.quality === '720' && itemYouWant == null) {
														itemYouWant = item
													} else if (item.quality === '480' && itemYouWant == null) {
														itemYouWant = item
													} else if (item.quality === '240' && itemYouWant == null) {
														itemYouWant = item
													}
												});
												console.log(itemYouWant);
												document.querySelector('#js-player').innerHTML = '';
												var videlem = document.createElement("video");
												videlem.id = "hacksuccescs";
												videlem.setAttribute("controls", "");
												videlem.style.cssText = 'max-height:100%;max-width:100%;width:100%;';
												videlem.setAttribute('preload', 'auto');
												var sourceMP4 = document.createElement("source");
												sourceMP4.type = "video/mp4";
												sourceMP4.src = itemYouWant.videoUrl;
												sourceMP4.setAttribute('type', 'video/mp4');
												videlem.appendChild(sourceMP4);
												document.querySelector('#js-player').append(videlem);
												var icchtml = '';
												var vconj = Object.values(vconj);
												for (i = 0; i < vconj.length; i++) {
													if (vconj[i].format == 'mp4') {
														icchtml += '<a class="downloadBtn clsocmbtin pinkButton" onmousedown="document.querySelector(\'#hacksuccescs\').pause();var intilme=document.querySelector(\'#hacksuccescs\').currentTime;document.querySelector(\'#hacksuccescs>source\').src=\'' + vconj[i].videoUrl + '\';document.querySelector(\'#hacksuccescs\').load();document.querySelector(\'#hacksuccescs\').play();document.querySelector(\'#hacksuccescs\').currentTime=(intilme-1);" onclick="setTimeout(function(){ window.open(\'' + vconj[i].videoUrl + '&=' + removehtml(eval("flashvars_" + hkcim).video_title) + '\',\'_blank\');},200)" style="margin-right: 5px;"><div class="buttoncopy"  data-clipboard-text="' + removehtml(eval("flashvars_" + hkcim).video_title) + '.mp4" style="width: max-content;">⬇ ' + vconj[i].quality + 'P</div></a>'
													}
												}
												var butoncl = document.createElement('div');
												butoncl.innerHTML = icchtml + '<p data-lfjlang="MOUSE_EVENT" style="margin: 0.2em 0 0.2em;"> </p>';
												butoncl.style.cssText = 'border-bottom: 1px solid #f90!important; }';
												butoncl.className = "customremoved";
												insertAfter(document.getElementById("js-player"), butoncl)
											})
										})
									})
								}
							} else {
								var text1 = 'NOT_WORKING';
								var text2 = 'NOT_WORKING_TEXT';
								if (response.status == 602) {
									text1 = 'ACCESS_DENIED';
									text2 = 'ACCESS_DENIED_TEXT'
								}
								document.querySelectorAll('#trytohack').forEach(e => e.parentNode.removeChild(e));
								var span = document.createElement('center');
								span.innerHTML = twowobr + '<h1 data-lfjlang="' + text1 + '"></h1> <br> <small style="max-width: 855px;display: block;" data-lfjlang="' + text2 + '" id="smallcifohkdmk"></small>';
								span.style.cssText = '    font-size: 32px;padding: 50px;';
								document.querySelector('#js-player').innerHTML = '';
								document.querySelector('#js-player').append(span);
								setTimeout(function () {
									rmldjnoti()
								}, 400)
							}
						}
					})
				}
			}
		},
		porn_hub: function () {
			if (this.url.match(/\.mp4/) && this.url.isdomain('phncdn.com') || this.url.match(/\.mp4/) && this.url.isdomain('phprcdn.com')) {
				LFJ.hkdownload()
			}
			if (location.href.isdomain('pornhubpremium.com')) {
				if (document.querySelector('#expired-enter-modal') || document.querySelector('#movieBoxContainer')) {
					ldjnoti(HLANG.WRONGPAGE, 'mid', !1, 15000, '#960d4b, #ac0976')
				}
			}
			if (this.url.match(/interstitial/) && this.url.isdomain('pornhub.com') || this.url.match(/interstitial/) && this.url.isdomain('pornhubpremium.com') || this.url.match(/interstitial/) && this.url.isdomain('pornhub.org')) {
				clearModalCookie();
				window.location.href = $('a[href*="/view_video"]').attr('href')
			} else if (location.href.isdomain('pornhub.com') || location.href.isdomain('pornhubpremium.com') || location.href.isdomain('pornhub.org')) {
				if (document.querySelector('div h1 span') && document.querySelector('div ul li a[href="/support"]') && !this.url.match(/view\_video\.php/) && !this.url.match(/(\/playlist\/)/i)) {
					localStorage.removeItem('fvodxte');
					window.history.back()
				}
				try {
					var premium_downed = parseInt(localStorage.getItem("premium_down"))
				} catch (e) {
					var premium_downed
				}
				var timenoew = Math.floor(Date.now() / 1000);
				var downfor = timenoew - premium_downed;
				if (downfor < 900 && typeof localStorage.getItem("premium_down") == 'string') {
					document.querySelectorAll('a[href*="promo=premium"]').forEach(e => e.href = e.href.replace('?promo=premium', ''))
				}
				if (typeof localStorage.getItem("premium_down") == 'string' && downfor > 900 || localStorage.getItem("premium_down") == null) {
					if (typeof localStorage.getItem("premium_down") == 'string' && downfor > 900) {
						localStorage.removeItem('premium_down')
					}
					if (document.querySelector('div.pornhub_logo_gay') || document.querySelector('img[src*="_logo_gay"]')) {
						document.querySelector('img[itemprop="logo"]').src = "https://di.phncdn.com/www-static/images/movie-box/logo-gay.png";
						document.querySelector('img[itemprop="logo"]').parentNode.href = '/gay/video?promo=premium'
					} else {
						document.querySelector('img[itemprop="logo"]').src = "https://di.phncdn.com/www-static/images/movie-box/logo.png";
						document.querySelector('img[itemprop="logo"]').parentNode.href = '/video?promo=premium'
					}
					if (this.url.match(/\/users/) && this.url.isdomain('pornhub.com') || this.url.match(/\/users/) && this.url.isdomain('pornhub.org')) {
						document.querySelector('div[class="badge-username"]').innerHTML = '<span class="premium-icon flag tooltipTrig" data-title="Premium User"></span>'
					}
				}
				LFJ.hkoptimus();
				GM_addStyle('#vpContentContainer{display:unset!important;}iframe[marginwidth="0"]{display:no!important;}');
				var islogedinyet = document.getElementById("profileMenuDropdown");
				if (!islogedinyet && localStorage.getItem("wasalert") != "true") {
					alert('To active download button, you need logedin');
					localStorage.setItem("wasalert", "true")
				}
				setTimeout(function () {
					if (document.getElementById('communityProfileMenu')) {
						document.getElementById('communityProfileMenu').scrollIntoView()
					}
				}, 1200);
				if (document.querySelector('a.more_recommended_btn.nav-videoRecommended,a.more_p2v_btn.nav-p2v') !== null) {
					document.querySelector('a.more_recommended_btn.nav-videoRecommended,a.more_p2v_btn.nav-p2v').addEventListener("click", function () {
						setTimeout(function () {
							try {
								var solufonc = document.querySelector('#recommendedVideosVPage ul,#paidItems').querySelectorAll('li').length
							} catch (e) {
								var solufonc = 0
							}
							for (i = 0; i < solufonc; i++) {
								document.querySelector('#relatedVideosCenter').innerHTML += document.querySelector('#recommendedVideosVPage ul,#paidItems').querySelectorAll('li')[i].outerHTML
							}
						}, 500)
					})
				}
				if (document.querySelector('#paidItems')) {
					setTimeout(function () {
						try {
							var solufonc = document.querySelector('#paidItems').querySelectorAll('li').length
						} catch (e) {
							var solufonc = 0
						}
						for (i = 0; i < solufonc; i++) {
							document.querySelector('#relatedVideosCenter').innerHTML += document.querySelector('#paidItems').querySelectorAll('li')[i].outerHTML
						}
					}, 500)
				}
				var ofj = 1;
				var timer = setInterval(function () {
					if (ofj == 1) {
						clearInterval(timer)
					}
					var mycEle = document.getElementById("loadMoreRelatedVideosCenter");
					var icmRci = document.querySelector("a.more_recommended_btn.nav-videoRecommended");
					if (mycEle == null) {
						mycEle = document.getElementById("moreVideoRelated")
					}
					if (icmRci == null) {
						icmRci = mycEle
					}
					if (icmRci) {
						icmRci.click();
						ofj++
					}
					if (document.getElementById("loadMoreRelatedVideosCenter")) {
						document.getElementById("loadMoreRelatedVideosCenter").click();
						ofj++
					}
					if (document.querySelector('div.js-relatedRecommended:not(.allRelatedVideos) #loadMoreRelatedVideosCenter')) {
						document.querySelector('div.js-relatedRecommended:not(.allRelatedVideos) #loadMoreRelatedVideosCenter').click()
					} else if (document.querySelector("a.more_recommended_btn.nav-videoRecommended")) {
						if (getComputedStyle(document.querySelector("a.more_recommended_btn.nav-videoRecommended"), null).display != "none") {
							document.querySelector("a.more_recommended_btn.nav-videoRecommended").href = "javascript:void(0)";
							document.querySelector("a.more_recommended_btn.nav-videoRecommended").click();
							ofj++
						}
					} else {
						clearInterval(timer)
					}
					document.querySelectorAll('div.positionRelative.singleVideo').forEach((vidurl) => {
						var dg = document.createElement('i');
						dg.className = "premiumIcon cl tooltipTrig";
						if (vidurl.querySelector('div.duration.thumbOverlay.hideInUserStream') && !vidurl.querySelector('div.duration.thumbOverlay.hideInUserStream').querySelector('i') && !location.href.match(/\=modelhub/)) {
							vidurl.querySelector('div.duration.thumbOverlay.hideInUserStream').appendChild(dg)
						}
					})
					document.querySelectorAll('a[data-related-url]').forEach((vidurl) => {
						var dv = document.createElement('i');
						dv.className = "premiumIcon cl tooltipTrig";
						dv.setAttribute('data-title', 'Premium Video');
						if (vidurl.querySelector('div.js-noFade') && !vidurl.querySelector('div.js-noFade').querySelector('i') && !location.href.match(/\=modelhub/)) {
							vidurl.querySelector('div.js-noFade').appendChild(dv)
						}
						if (!vidurl.href.match(/ajax\_related\_search/)) {
							vidurl.href = '/view_video.php?viewkey=' + vidurl.getAttribute("data-related-url").replace('/video/ajax_related_video?vkey=', '')
						} else {
							vidurl.href = vidurl.href.replace(/\/view\_video\.php\?viewkey\=/ig, '');
							vidurl.href = vidurl.href.replace(/ajax\_related\_/ig, '')
						}
					})
				}, 1500);
				localStorage.setItem("player_quality", '{"quality":"1440"}');
				setTimeout(function () {
					if (document.querySelector('div.js-relatedRecommended:not(.allRelatedVideos) #loadMoreRelatedVideosCenter')) {
						document.querySelector('div.js-relatedRecommended:not(.allRelatedVideos) #loadMoreRelatedVideosCenter').click()
					}
				}, 2500);
				if (LFJCONFIG.pornhubpremium == !0) {
					GM_addStyle(".recommendedSection,.adContainer,.premiumAdvert,.ad-tabSplit,.headerUpgradePremiumBtn.removeAdLink,.videoList>li .videoWrapper .premiumLockedVideo,.pinkButton i{display:none !important;}.premiumLockedVideo.tooltipTrig,#relatedVideosVPage{display:none;}#main-container div#hd-leftColVideoPage{width:100% !important;}.pinkButton{background: #d64e6b; color: #fff; margin: 5px !important; border: none; border-radius: 4px; display: inline-flex; font-family: inherit; padding: 6px 12px; cursor: pointer; position: relative; outline: 0 none; text-align: center; vertical-align: top; text-decoration: none; font-weight: 700; }");
					try {
						if (document.getElementById('under-player-playlists')) {
							document.querySelector('a.greyButton.light.more_p2v_btn.nav-p2v').style.cssText = 'margin: 0 0 auto; display: block; padding: 18px';
							document.getElementById('under-player-playlists').appendChild(document.getElementById('p2vVideosVPage'));
							document.getElementById('under-player-playlists').appendChild(document.getElementById('relatedVideosVPage'))
						}
					} catch (e) {
						var kdvc = !1
					}
					if (document.getElementById('main-container') && document.getElementById('under-player-comments')) {
						document.getElementById('main-container').appendChild(document.getElementById('under-player-comments'))
					}
					if (document.querySelector('div.video-wrapper.premiumLocked') !== null || document.querySelector('div#userPremium') !== null || document.querySelector('div#lockedPlayer') !== null || document.querySelector('div#js-player.playerPreviewWrapper') !== null) {
						setTimeout(function () {
							ldjnoti(HLANG.PREMIUM_FOUND, 'mid', !1, 15000, '#960d4b, #ac0976')
						}, 200);
						if (document.querySelector('div.video-wrapper.premiumLocked')) {
							document.querySelectorAll('div.video-wrapper.premiumLocked').forEach(e => e.parentNode.removeChild(e))
						}
						if (document.querySelector('#userPremium')) {
							document.querySelectorAll('#userPremium').forEach(e => e.parentNode.removeChild(e))
						}
						if (document.querySelector('#lockedPlayer')) {
							document.querySelectorAll('.orangeButton.purchaseButton.js-purchaseButton').forEach(e => e.parentNode.removeChild(e));
							document.querySelectorAll('#lockedPlayer').forEach(e => e.parentNode.removeChild(e));
							if (document.getElementById('hd-rightColVideoPage')) {
								document.getElementById('hd-leftColVideoPage').appendChild(document.getElementById('hd-rightColVideoPage'))
							}
							if (document.getElementById('under-player-playlists')) {
								if (document.getElementById('relatedVideosVPage')) {
									document.getElementById('under-player-playlists').appendChild(document.getElementById('relatedVideosVPage'))
								}
								if (document.getElementById('p2vVideosVPage')) {
									document.getElementById('under-player-playlists').appendChild(document.getElementById('p2vVideosVPage'))
								}
							} else {
								if (document.getElementById('relatedVideosVPage')) {
									document.getElementById('hd-leftColVideoPage').appendChild(document.getElementById('relatedVideosVPage'))
								}
								if (document.getElementById('p2vVideosVPage')) {
									document.getElementById('hd-leftColVideoPage').appendChild(document.getElementById('p2vVideosVPage'))
								}
							}
						}
						if (document.querySelector('div.logoLockedContent')) {
							document.querySelectorAll('div.logoLockedContent').forEach(e => e.parentNode.removeChild(e))
						}
						if (document.querySelector('div.playerWrapper')) {
							document.querySelectorAll('div.playerWrapper').forEach(e => e.parentNode.removeChild(e));
							document.querySelectorAll('.orangeButton.purchaseButton.js-purchaseButton.js-mixpanel').forEach(e => e.parentNode.removeChild(e));
							document.querySelectorAll('.saleVideoLogMessage').forEach(e => e.parentNode.removeChild(e));
							document.querySelectorAll('#premiumFeaturesContainer').forEach(e => e.parentNode.removeChild(e))
						}
						if (document.querySelector('div.premiumLockedVideo.tooltipTrig')) {
							document.querySelectorAll('div.premiumLockedVideo.tooltipTrig').forEach(e => e.parentNode.removeChild(e))
						}
						if (document.querySelector('div#premiumFeaturesContainer')) {
							document.querySelectorAll('div#premiumFeaturesContainer').forEach(e => e.parentNode.removeChild(e))
						}
						if (document.querySelector('div.lockedOrangeButton')) {
							document.querySelectorAll('div.lockedOrangeButton').forEach(e => e.parentNode.removeChild(e))
						}
						if (document.querySelector('div.private-vid-title')) {
							document.querySelectorAll('div.private-vid-title,img.privateOverlay').forEach(e => e.parentNode.removeChild(e))
						}
						if (document.querySelector('div.lockedPremiumTitle')) {
							document.querySelectorAll('div.lockedPremiumTitle').forEach(e => e.parentNode.removeChild(e))
						}
						var span = document.createElement('center');
						span.id = "trytohack"
						span.innerHTML = '<h1><img style="vertical-align: bottom; position: relative; bottom: 8px; right: -16px;" src="' + blfj_loading + '" /> <span data-tag="LOADINGPREMIUN"></span> </h1>' + '<br /> <small id="smallcifohkdmk" data-lfjlang="HOAKHUYACONNECT"></small>';
						span.style.cssText = '    font-size: 32px;padding: 50px;';
						if (document.querySelector('#main-container')) {
							document.querySelector('#main-container').insertBefore(span, document.querySelector('#main-container').firstChild)
						}
						if (document.querySelector('#videoShow')) {
							document.querySelector('#videoShow').insertBefore(span, document.querySelector('#videoShow').firstChild)
						}
						GM_xmlhttpRequest({
							method: "GET",
							ignoreCache: !0,
							url: 'https://'+'LFJ.iO'+'/phub/' + (_lfjkm.key) + '/' + VIDEO_SHOW.vkey,
							onerror: function (response) {
								document.querySelectorAll('#trytohack').forEach(e => e.parentNode.removeChild(e));
								var span = document.createElement('center');
								localStorage.setItem("premium_down", Math.floor(Date.now() / 1000));
								document.querySelectorAll('a[href*="promo=premium"]').forEach(e => e.href = e.href.replace('?promo=premium', ''));
								span.innerHTML = '<h1 data-lfjlang="NOT_WORKING"></h1> <br> <small data-lfjlang="NOT_WORKING_TEXT" style="max-width: 855px;display: block;" id="smallcifohkdmk"> </small>';
								span.style.cssText = '    font-size: 32px;padding: 50px;';
								if (document.querySelector('#main-container')) {
									document.querySelector('#main-container').insertBefore(span, document.querySelector('#main-container').firstChild)
								}
								if (document.querySelector('#videoShow')) {
									document.querySelector('#videoShow').insertBefore(span, document.querySelector('#videoShow').firstChild)
								}
								setTimeout(function () {
									rmldjnoti();
									ldjnoti(HLANG.OVERLOAD_NOTIFY, 'mid', !1, 15000, '#b624d4, #9a486c')
								}, 400)
							},
							onload: function (response) {
								if (response.readyState == 4 && response.status == 200) {
									var contentc = document.createElement("script");
									contentc.id = 'pcsh'
									if (!response.responseText.match(/\<title\>Error/)) {
										contentc.innerHTML = response.responseText;
										try {
											document.body.appendChild(contentc)
										} catch (e) {
											return ''
										}
									} else {
										localStorage.setItem("premium_down", Math.floor(Date.now() / 1000));
										document.querySelectorAll('a[href*="promo=premium"]').forEach(e => e.href = e.href.replace('?promo=premium', ''))
									}
									try {
										if (JSON.parse(localStorage.getItem('plus_showOnlypopUP')) == !0) {
											var vardvo = '';
											if (cjacodfzx.length > 1) {
												vardvo = '&ur2=' + (hencrypt(cjacodfzx[1].videoUrl.replace('https://', ''), '')) + '&uz2=' + cjacodfzx[1].quality
											}
											if (cjacodfzx.length > 2) {
												vardvo += '&ur3=' + (hencrypt(cjacodfzx[2].videoUrl.replace('https://', ''), '')) + '&uz3=' + cjacodfzx[2].quality
											}
											var cdfvxc = 'https://thewolds.github.io/video/?uri=' + (hencrypt(cjacodfzx[0].videoUrl.replace('https://', ''), '')) + '&size=' + cjacodfzx[0].quality + vardvo + '&autoplay=true&ckapop=true';
											centeredPopup(cdfvxc, 'pornhuvPrd', 1024, 640, 'yes');
											if (isFirefox == !1) {
												close()
											}
										}
										var itemYouWant = null;
										cjacodfzx.forEach((item) => {
											if (item.quality === '1440' && itemYouWant == null) {
												itemYouWant = item
											} else if (item.quality === '1080' && itemYouWant == null) {
												itemYouWant = item
											} else if (item.quality === '720' && itemYouWant == null) {
												itemYouWant = item
											} else if (item.quality === '480' && itemYouWant == null) {
												itemYouWant = item
											} else if (item.quality === '240' && itemYouWant == null) {
												itemYouWant = item
											}
										});
										GM_addStyle("#pb_iframe{display:block !important;}");
										var videlem = document.createElement("div");
										videlem.id = "hacksuccescs";
										videlem.style.cssText = 'max-width:100%; width:100%; max-height:650px !important;';
										var sourceMP4 = document.createElement("video");
										sourceMP4.setAttribute('controls', '');
										sourceMP4.setAttribute('autoplay', '');
										sourceMP4.setAttribute('crossorigin', 'anonymous');
										sourceMP4.setAttribute('allowfullscreen', '');
										sourceMP4.setAttribute('sandbox', '');
										sourceMP4.style.cssText = 'height: 100%; width: 100%;max-height:650px !important;';
										sourceMP4.src = itemYouWant.videoUrl;
										sourceMP4.id = 'pb_iframe';
										videlem.appendChild(sourceMP4);
										if (document.querySelector('#main-container')) {
											document.querySelector('#main-container').insertBefore(videlem, document.querySelector('#main-container').firstChild)
										}
										if (document.querySelector('#videoShow')) {
											document.querySelector('#videoShow').insertBefore(videlem, document.querySelector('#videoShow').firstChild)
										}
										setTimeout(function () {
											rmldjnoti();
											ldjnoti(HLANG.UNLOCKED, 'mid', !1, 3000)
										}, 400);
										var span = document.createElement('center');
										span.id = "hacksuccess"
										span.innerHTML = '<h2 data-lfjlang="PREMIUM_READY"></h2>';
										span.style.cssText = '    font-size: 20px;padding: 10px;';
										if (document.querySelector('#main-container')) {
											document.querySelector('#main-container').insertBefore(span, document.querySelector('#main-container').firstChild)
										}
										document.querySelectorAll('#trytohack').forEach(e => e.parentNode.removeChild(e));
										var icchtml = '';
										var aconj = Object.values(cjacodfzx);
										for (i = 0; i < aconj.length; i++) {
											if (aconj[i].format == 'mp4') {
												icchtml += '<a class="downloadBtn clsocmbtin pinkButton" onmousedown="document.querySelector(\'#pb_iframe\').src=\'' + aconj[i].videoUrl + '\';" onclick="setTimeout(function(){ window.open(\'' + aconj[i].videoUrl + '&=' + removehtml(eval("flashvars_" + hkcim).video_title) + '\',\'_blank\');},200)" style="margin-right: 5px;"><div class="buttoncopy"  data-clipboard-text="' + removehtml(eval("flashvars_" + hkcim).video_title) + '.mp4" style="width: max-content;">⬇ ' + aconj[i].quality + 'P</div></a>'
											}
										}
										var butoncl = document.createElement('div');
										butoncl.innerHTML = '<h1 class="title" style="margin-bottom: 15px;">' + removehtml(eval("flashvars_" + hkcim).video_title) + '</h1>' + icchtml + '<p data-lfjlang="MOUSE_EVENT" style="margin: 0.5em 0 1.5em;"> </p>';
										butoncl.style.cssText = 'border-bottom: 1px solid #f90!important; padding-bottom: 30px; padding-left: 30px; }';
										butoncl.className = "customremoved";
										insertAfter(document.getElementById("hacksuccescs"), butoncl);
										document.querySelector('video#hacksuccescs').querySelector('source').addEventListener('error', function (event) {
											if (!location.href.startWith('https://www.pornhub.com') && isNaN(document.querySelector('video#hacksuccescs').duration) || !location.href.startWith('https://www.pornhub.org') && isNaN(document.querySelector('video#hacksuccescs').duration)) {
												ldjnoti(HLANG.FIXINGVIEWABLE, 'mid', !1, 15000, '#b624d4, #9a486c');
												var cioul = document.createElement('ul');
												cioul.className = 'languages dropdownWrapper';
												var cioc = document.createElement('li');
												cioc.className = 'en alpha';
												var cioss = document.createElement('a');
												cioss.href = window.location.href.replace(/\/\/([a-z]{2})\./, '//www.');
												cioss.setAttribute('data-lang', 'en');
												cioss.setAttribute('data-root', 'pornhub.org');
												cioss.id = "cjxsc";
												cioss.setAttribute('onclick', "ga('send', 'event', 'Language Flags Footer', 'click', 'English');");
												cioul.append(cioc);
												cioc.append(cioss);
												document.body.append(cioul);
												var myDate = new Date();
												myDate.setMonth(myDate.getMonth() + 12);
												document.cookie = 'get_viewable' + "=" + location.href + ";domain=.pornhub.org;path=/;expires=" + myDate;
												setTimeout(function () {
													document.querySelector('#cjxsc').click()
												}, 2300)
											}
										})
										document.querySelector('video#hacksuccescs').addEventListener('durationchange', function (event) {
											if (location.href.startWith('https://www.pornhub.com') && document.cookie.match('(^|;) *get\_viewable=([^;]*)') !== null && isNaN(document.querySelector('video#hacksuccescs').duration) == !1 || location.href.startWith('https://www.pornhub.org') && document.cookie.match('(^|;) *get\_viewable=([^;]*)') !== null && isNaN(document.querySelector('video#hacksuccescs').duration) == !1) {
												ldjnoti(HLANG.FIXINGVIEWABLE, 'mid', !1, 15000, '#b624d4, #9a486c');
												if (document.cookie.match('(^|;) *get\_viewable=([^;]*)')[2] != "OK") {
													var cioul = document.createElement('ul');
													cioul.className = 'languages dropdownWrapper';
													var cioc = document.createElement('li');
													cioc.className = document.cookie.match('(^|;) *get\_viewable=[^;]*\:\/\/([^;]*)\.pornhub\.org')[2];
													var cioss = document.createElement('a');
													cioss.href = document.cookie.match('(^|;) *get\_viewable=([^;]*)')[2];
													cioss.setAttribute('data-lang', document.cookie.match('(^|;) *get\_viewable=[^;]*\:\/\/([^;]*)\.pornhub\.org')[2]);
													cioss.setAttribute('data-root', 'pornhub.org');
													cioss.id = "cjxsc";
													cioss.setAttribute('onclick', "ga('send', 'event', 'Language Flags Footer', 'click', 'English');");
													cioul.append(cioc);
													cioc.append(cioss);
													document.body.append(cioul);
													setTimeout(function () {
														document.querySelector('#cjxsc').click()
													}, 2300)
												}
											}
											if (!location.href.startWith('https://www.pornhub.com') && document.cookie.match('(^|;) *get\_viewable=([^;]*)') !== null && isNaN(document.querySelector('video#hacksuccescs').duration) == !1 || !location.href.startWith('https://www.pornhub.org') && document.cookie.match('(^|;) *get\_viewable=([^;]*)') !== null && isNaN(document.querySelector('video#hacksuccescs').duration) == !1) {
												var myDate = new Date();
												myDate.setMonth(myDate.getMonth() - 12);
												document.cookie = 'get_viewable' + "=OK;domain=.pornhub.org;path=/;expires=" + myDate
											}
										})
									} catch (e) {
										if (document.querySelector('#hacksuccescs') == null) {
											document.querySelectorAll('#trytohack').forEach(e => e.parentNode.removeChild(e));
											var span = document.createElement('center');
											span.innerHTML = '<h1><span data-lfjlang="OVERLOAD_H1"></span> [<a data-lfjlang="OVERLOAD_A" onclick="location.reload();" style="user-select: none;"></a>]</h1><br /> <small data-lfjlang="OVERLOAD_TEXT"></small>';
											span.style.cssText = '    font-size: 32px;padding: 50px;';
											if (document.querySelector('#main-container')) {
												document.querySelector('#main-container').insertBefore(span, document.querySelector('#main-container').firstChild)
											}
											if (document.querySelector('#videoShow')) {
												document.querySelector('#videoShow').insertBefore(span, document.querySelector('#videoShow').firstChild)
											}
											setTimeout(function () {
												rmldjnoti();
												ldjnoti(HLANG.OVERLOAD_NOTIFY, 'mid', !1, 15000, '#b624d4, #9a486c')
											}, 400)
										}
									}
								} else {
									if (response.status != 602) {
										var text1 = 'NOT_WORKING';
										var text2 = 'NOT_WORKING_TEXT';
										localStorage.setItem("premium_down", Math.floor(Date.now() / 1000));
										document.querySelectorAll('a[href*="promo=premium"]').forEach(e => e.href = e.href.replace('?promo=premium', ''))
									}
									if (response.status == 602) {
										text1 = 'ACCESS_DENIED';
										text2 = 'ACCESS_DENIED_TEXT'
									}
									document.querySelectorAll('#trytohack').forEach(e => e.parentNode.removeChild(e));
									var span = document.createElement('center');
									span.innerHTML = '<h1 data-lfjlang="' + text1 + '"></h1> <br> <small style="max-width: 855px;display: block;" data-lfjlang="' + text2 + '" id="smallcifohkdmk"></small>';
									span.style.cssText = '    font-size: 32px;padding: 50px;';
									if (document.querySelector('#main-container')) {
										document.querySelector('#main-container').insertBefore(span, document.querySelector('#main-container').firstChild)
									}
									if (document.querySelector('#videoShow')) {
										document.querySelector('#videoShow').insertBefore(span, document.querySelector('#videoShow').firstChild)
									}
									setTimeout(function () {
										rmldjnoti()
									}, 400)
								}
							}
						})
					}
				}

				function showpop(sokcoe) {
					console.log(sokcoe);
					if (JSON.parse(localStorage.getItem('plus_showOnlypopUP')) == !0) {
						var cclpdfd = '';
						var vardvo = '';
						var sizexf = '';
						if (sokcoe['1440']) {
							cclpdfd = sokcoe['1440'];
							sizexf = 1440
						} else if (sokcoe['1080']) {
							cclpdfd = sokcoe['1080'];
							sizexf = 1080
						} else if (sokcoe['720']) {
							cclpdfd = sokcoe['720'];
							sizexf = 720
						} else if (sokcoe['480']) {
							cclpdfd = sokcoe['480'];
							sizexf = 480
						}
						if (sokcoe['1440']) {
							vardvo = '&ur2=' + (hencrypt(sokcoe['1080'].replace('https://', ''), '')) + '&uz2=1080' + '&ur3=' + (hencrypt(sokcoe['720'].replace('https://', ''), '')) + '&uz3=720'
						} else if (sokcoe['1080']) {
							vardvo = '&ur2=' + (hencrypt(cokcoe['720'].replace('https://', ''), '')) + '&uz2=720' + '&ur3=' + (hencrypt(sokcoe['480'].replace('https://', ''), '')) + '&uz3=480'
						} else if (sokcoe['720']) {
							vardvo = '&ur2=' + (hencrypt(sokcoe['480'].replace('https://', ''), '')) + '&uz2=480'
						}
						var cdfvxc = 'https://thewolds.github.io/video/?uri=' + (hencrypt(cclpdfd.replace('https://', ''), '')) + '&size=' + sizexf + vardvo + '&autoplay=true&ckapop=true';
						window.location.replace(cdfvxc)
					}
				}
				async function phfetch(url) {
					const mp4url = new Promise((resolve) => {
						fetch(url, {
							method: 'get'
						}).then(res => res.json()).then(res => {
							return resolve(res)
						})
					});
					let resul = await mp4url;
					return resul
				}
				const Ox93dof = ' ';
				var andendurl = '';
				if (localStorage.getItem("fvodxte") && localStorage.getItem("fvodxte") != "rs") {
					andendurl = '?o=' + localStorage.getItem("fvodxte")
				}
				var oginalci = '';

				function removeQuery(query) {
					var ifr = document.querySelectorAll(query);
					if (ifr.length > 0)
						for (var i = 0; i < ifr.length; i++) ifr[i].parentNode.removeChild(ifr[i]);
				}
				removeQuery("iframe:not(#pb_iframe)");
				removeQuery(".home-ad-container");
				removeQuery(".adblockWhitelisted");
				removeQuery(".browse-ad-container");
				removeQuery(".playlist-ad-container");
				removeQuery(".categoryMessage.orangeTheme");
				removeQuery(".communityAds");
				removeQuery(".photo-ad-container");
				removeQuery("#advertisementBox");
				removeQuery('script[src*="trafficjunky.com"]');
				removeQuery("videoPageAds");
				var vdoc = 1;
				var ifkcms = setInterval(function () {
					if (vdoc >= 5) {
						clearInterval(ifkcms)
					} else {
						if (document.querySelector('iframe[allowtransparency]')) {
							document.querySelector('iframe[allowtransparency]').remove()
						}
						try {
							document.querySelector('ul#hotVideosSection').querySelectorAll('.alpha').forEach(e => e.parentNode.removeChild(e))
						} catch (e) {
							console.log('mod')
						}
						try {
							document.querySelector('ul#videoCategory').querySelectorAll('.alpha').forEach(e => e.parentNode.removeChild(e))
						} catch (e) {
							console.log('mod')
						}
						document.querySelectorAll('img[src*="data:image"]').forEach((al) => {
							if (al.getAttribute('data-src')) {
								al.setAttribute("src", al.getAttribute('data-src'))
							}
						})
						vdoc++
					}
				}, 1000);
				if (document.querySelector('div.js-paidDownload,#topBannerSlider')) {
					document.querySelectorAll('div.js-paidDownload,#topBannerSlider').forEach(function (xj) {
						xj.parentNode.parentNode.removeChild(xj.parentNode)
					})
				}
				if (document.querySelector('div#downloadMessage>.downloadBtn') !== null) {
					document.querySelectorAll('div[data-mixpanel-listing]').forEach(e => e.parentNode.removeChild(e))
				}
				document.querySelectorAll('ul#hotVideosSection>.alpha,div.videoPurchaseFlowModal,div>.ad-link,.removeAdLink.removeAdsStyle,#headerUpgradePremiumBtn,.abAlertShown,#pb_block,li.sniperModeEngaged.alpha,iframe:not(#pb_iframe),div.hd.clear,h1.title>small>div,i.isMe,.title-container>.isMe.tooltipTrig,#androidAppBar,footer,.footerContentWrapper,#getVerified,a.translationTab,.pay2Download,div.videoFanClubButton.js-tipsTrigger.js-mixpanel,#js-networkBar,.getVerified,.upgradeToPremium,.becomeTranslator').forEach(e => e.parentNode.removeChild(e));
				document.querySelectorAll('.uploaderLink').forEach(function (xj) {
					var dicx = xj.href;
					if (!dicx.match(/\/pornstar\/([a-z0-9_-]+)\/videos\//gi)) {
						xj.href = dicx + '/videos'
					}
				})
				document.querySelectorAll('.usernameWrap>a,.usernameBadgesWrapper>a').forEach(function (xj) {
					var dicx = xj.href;
					if (!dicx.match(/\/videos/)) {
						xj.href = dicx + '/videos'
					}
				})
				const cv8rdegex = /\/users\/([a-z0-9_-]+)/gmi;
				const cxcod1x = /\/video\/search/gmi;
				var fucrmx8x = window.location.href;
				if (fucrmx8x.match(/\/users\/([a-z0-9_-]+)/gi)) {
					var rescs2cs = fucrmx8x.match(/\/users\/([a-z0-9_-]+)/gi)[0].replace('/users/', '');
					var myuser = $('#profileMenuDropdown li a[title]').text();
					if (rescs2cs != myuser) {
						if (!fucrmx8x.match(/\/users\/([a-z0-9_-]+)\//gi)) {
							window.location.href = '//' + location.hostname + '/users/' + rescs2cs + '/videos'
						}
						if (fucrmx8x.match(/\/users\/([a-z0-9_-]+)\/videos/gi) && !fucrmx8x.match(/\/users\/([a-z0-9_-]+)\/videos\//gi)) {
							var kcivmx = $('.omega>span>a').attr('href');
							window.location.href = '//' + location.hostname + '/users/' + rescs2cs + '/videos/public' + andendurl
						}
						if ($(".emptyWrapper,.empty").length == 1 && fucrmx8x.match(/\/videos\/public/gi)) {
							window.location.href = '//' + location.hostname + '/users/' + rescs2cs + '/videos/favorites' + andendurl
						}
						if ($(".emptyWrapper,.empty").length == 1 && fucrmx8x.match(/\/videos\/favorites/gi)) {
							window.location.href = '//' + location.hostname + '/users/' + rescs2cs + '/videos/recent' + andendurl
						}
					}
				}
				if (fucrmx8x.match(/\/video\/search/gmi) && !fucrmx8x.match(/\Wo\=([a-z0-9]+)/gmi)) {
					var ineurl = fucrmx8x.replace(/\Wo\=([a-z0-9]+)/gi, '');
					ineurl = ineurl + '&o=' + localStorage.getItem("fvodxte");
					if (localStorage.getItem("fvodxte") != "rs" && localStorage.getItem("fvodxte")) {
						if (document.querySelector('ul.filterListItem.dropdownWrapper a[href*="' + localStorage.getItem("fvodxte") + '"]')) {
							window.location.href = ineurl
						}
					}
				}
				$('.tabWrapper').on('click', '.playlistTab', function (e) {
					localStorage.setItem("useron_tour", 'list')
				})
				$('.tabWrapper').on('click', 'a[href*="related"]', function (e) {
					localStorage.setItem("useron_tour", 'dexuat')
				})
				$('.subFilterWrapper,.filterListItem').on('click', 'a:first', function (e) {
					localStorage.setItem("fvodxte", 'rs')
				})
				$('.subFilterWrapper,.filterListItem').on('click', 'a[href*="o=mv"]', function (e) {
					localStorage.setItem("fvodxte", 'mv')
				})
				$('.subFilterWrapper,.filterListItem').on('click', 'a[href*="o=mr"]', function (e) {
					localStorage.setItem("fvodxte", 'mr')
				})
				$('.subFilterWrapper,.filterListItem').on('click', 'a[href*="o=tr"]', function (e) {
					localStorage.setItem("fvodxte", 'tr')
				})
				$('.subFilterWrapper,.filterListItem').on('click', 'a[href*="o=lg"]', function (e) {
					localStorage.setItem("fvodxte", 'lg')
				})
				$('.subFilterWrapper,.filterListItem').on('click', 'a[href*="o=ht"]', function (e) {
					localStorage.setItem("fvodxte", 'ht')
				})
				$('.subFilterWrapper,.filterListItem').on('click', 'a[href*="o=cm"]', function (e) {
					localStorage.setItem("fvodxte", 'cm')
				})
				setTimeout(function () {
					if (localStorage.getItem("useron_tour") == 'dexuat') {
						$('a[href*="related"]').trigger("click")
					} else if (localStorage.getItem("useron_tour") == 'list') {
						$('a[href*="playlist"]').trigger("click")
					}
				}, 1200);
				var tite = document.querySelector('div.votes-fav-wrap');
				var cokcoe = [];
				if (tite !== null) {
					var icchtml = '';
					try {
						var iccvox = eval("flashvars_" + ad_player_id);
						var dfatav = iccvox.mediaDefinitions;
						if (!dfatav) {
							var dfatav = window["flashvars_" + ad_player_id].mediaDefinitions;
							console.log('windows xic')
						}
						var aconj = Object.values(dfatav);
						var countmp4 = 0;
						if (document.querySelectorAll('a.downloadBtn[href*=".mp4"]').length == 0) {
							var urldetected = '';
							for (i = 0; i < aconj.length; i++) {
								if (aconj[i].format == 'mp4' && aconj[i].videoUrl != "") {
									urldetected = aconj[i].videoUrl
								}
							}
							if (urldetected.match(/(get\_media)/ig)) {
								phfetch(urldetected).then(function (aconj) {
									console.log('ph-newmod-patched');
									for (i = 0; i < aconj.length; i++) {
										cokcoe[aconj[i].quality] = aconj[i].videoUrl;
										icchtml += '<a class="downloadBtn pinkButton" target="_blank" download="' + removehtml(iccvox.video_title) + '" style="margin-right: 5px;" href="' + aconj[i].videoUrl + '&name=' + removehtml(iccvox.video_title) + '"><div class="buttoncopy" data-clipboard-text="' + removehtml(iccvox.video_title) + '.mp4" style="width: max-content;">⬇ ' + aconj[i].quality + 'P</div></a>'
									}
									tite.innerHTML += '<div style="text-align:center;display: inline-flex;margin-top: 22px;margin-bottom: 10px;position: relative;">' + icchtml + '</div>';
									showpop(cokcoe)
								})
							}
						}
					} catch (e) {
						console.log('c')
					}
					document.querySelectorAll('a.downloadBtn[href*="/140P_"]').forEach(e => e.parentNode.removeChild(e));
					document.querySelectorAll('a.downloadBtn').forEach(function (xj) {
						var ind = xj.innerText.replace(/([a-z\s]+)?([0-9]+)([a-z\s]+)?/i, '$2');
						cokcoe[ind] = xj.href
					});
					var dtab = document.querySelector('div.download-tab>.contentWrapper');
					if (dtab == null) {
						dtab = document.querySelector('div.download-tab>.js-InitialFreeAccount')
					}
					if (dtab == null) {
						dtab = document.querySelector('div.modalWrapper>.modal-body')
					}
					try {
						var htlx = dtab.innerHTML.replace(/greyButton/g, 'pinkButton')
					} catch (e) {
						var htlx = dtab.innerHTML.replace(/orangeButton/g, 'pinkButton')
					}
					if (!htlx.match(/(480|720|240)/gmi)) {
						tite.innerHTML += '<div style="text-align:center;display: inline-flex;margin-top: 22px;margin-bottom: 10px;position: relative;">' + icchtml + '</div>'
					} else {
						tite.innerHTML += '<div style="text-align:center;display: inline-flex;margin-top: 22px;margin-bottom: 10px;position: relative;">' + htlx + '</div>';
						showpop(cokcoe)
					}
				} else {
					document.querySelectorAll('a[href*="/140P_"]').forEach(e => e.parentNode.removeChild(e));
					var dlbar = document.querySelector('div.downloadBar');
					try {
						if (dlbar.innerHTML.match(/240p|360p/i)) {
							dlbar.style.display = "block"
						}
					} catch (e) {
						console.log('no for download free')
					}
					var icchtml = '';
					try {
						var covsofg = eval("flashvars_" + VIDEO_SHOW.playerId.split("_")[1]);
						var cokcoe = [];
						var dfatav = covsofg.mediaDefinitions;
						if (!dfatav) {
							var covsofg = window["flashvars_" + loadScriptUniqueId[0]];
							var dfatav = covsofg.mediaDefinitions
						}
						var aconjc = Object.values(dfatav);
						var urldetected;
						aconjc.forEach(function (element) {
							if (element.format == "mp4" && element.videoUrl != "") {
								urldetected = element.videoUrl
							}
						})
						if (urldetected.match(/(get\_media)/ig)) {
							console.log(urldetected);
							phfetch(urldetected).then(function (element) {
								console.log('ph-newmod-patched');
								for (i = 0; i < element.length; i++) {
									cokcoe[element[i].quality] = element[i].videoUrl;
									icchtml += '<a download="' + removehtml(covsofg.video_title) + '" target="_blank" style="background: #d64e6b;color: #fff;margin: 5px !important;border: none; border-radius: 4px; display: inline-flex; font-family: inherit; padding: 6px 15px; cursor: pointer; position: relative; outline: 0 none; text-align: center;vertical-align: top; text-decoration: none; font-weight: 700;" href="' + element[i].videoUrl + '&name=' + removehtml(covsofg.video_title) + '" data-title="' + element[i].quality + '" class="buttoncopy" data-clipboard-text="' + removehtml(covsofg.video_title) + '.mp4">Download <span>' + element[i].quality + ' P</span></a>'
								}
								var titec = document.querySelector('h1.floatLeft');
								titec.innerHTML += '</br><small class="downloadMessage" style="text-align:center;">' + icchtml + '</small>';
								showpop(cokcoe)
							})
						}
					} catch (e) {
						console.log('f')
					}
				}
				console.log("success")
			}
		},
		horlover_com: function () {
			if (this.url.isdomain('4horlover.com') && this.url.match(/\Wp\=/)) {
				function onlyUnique(value, index, self) {
					return self.indexOf(value) === index
				}
				document.cookie = "age_gate=22;";
				var kc = 0;
				document.querySelector('html').innerHTML = '<head></head><body><main><div class="entry-content"></div></main></body>';
				setTimeout(function () {
					document.querySelector('html').innerHTML = '<head></head><body><main><div class="entry-content"></div></main></body>'
				}, 100);
				document.addEventListener("DOMNodeInserted", function () {
					$("script,iframe").remove()
				})
				setTimeout(function () {
					$("body").removeClass('post-template-default single single-post postid-51255 single-format-standard sidebar').css('visibility', '').css('display', 'block');
					var cdf = document.createElement('link');
					cdf.setAttribute('rel', 'stylesheet');
					cdf.type = 'text/css';
					cdf.setAttribute('media', 'all');
					cdf.href = 'https://4horlover.com/wp-content/themes/puro/style.css';
					document.head.appendChild(cdf);
					$("#secondary,#masthead,#colophon").remove();
					$('head').append('<style type="text/css" class="customcss">img{padding-top: 15px;}#page,main{max-width:1000px;padding:0 2%;margin: 0 auto;} iframe{display:none;} body{background-color:black;} p{color: white;}#banner_ad{z-index:-8888;} #primary{width:100% !important;padding:unset !important;border:unset !important;} div > center > p > b{font-size:2em;color:#b3ffb3;} div > vlcp.cl{width:100%;height:1px;display:block;border-top: 2px solid #ffcccc;padding-top: 2px;}</style>');
					var urlv;
					var count = 0;
					var ifmcount = 0;
					var imglistt = {};

					function loadncsdfi(urlv) {
						$.ajaxSetup({
							xhr: function () {
								return new XMLHttpRequest
							}
						});
						$.ajax({
							type: "GET",
							url: urlv,
							success: function (data) {
								var jxhtml = $(data).find('center');
								try {
									jxhtml = $(jxhtml).html().replace("<br>Preview", "Preview").replace("\nPreview", "Preview")
								} catch (e) {
									console.log('skip 1');
									jxhtml = ''
								}
								tvtle = $(data).filter('title').text().replace(/\s[^+\s]+\.[a-z0-9\/-]+|[^\w\s]|4\s?h\s?o\s?r\s?l\s?o\s?v\s?e\s?r\s?|4(\s+)?h(\s+)?o(\s+)?r(\s+)?l(\s+)?o(\s+)?v(\s+)?e(\s+)?r(\s+)?/ig, '');
								tvtle = tvtle + ' LFJ';
								urlv = $(data).find('a[rel="prev"]').attr('href');
								try {
									if (jxhtml.match(/Preview/i)) {
										$('.entry-content').append("<vlcp class='cl'></vlcp><center><p><b class='novome'>" + tvtle + "</b></p></center><canv>" + jxhtml + "</canv>")
									}
								} catch (e) {
									console.log('f')
								}
								var fixmr48 = 0;
								$('.entry-content').find('a[href*="http://"],a[href*="https://"]').each(function () {
									var urlcsqa = $(this).attr("href");
									if (!urlcsqa.match(/authuser\=/)) {
										$(this).attr("midiv", fixmr48);
										$(this).replaceWith('<a onclick="window.open(\'' + $(this).attr("href").replace('https://drive.google.com/open?', 'https://drive.google.com/uc?export=download&') + ',\'_blank\'\')" midiv="' + fixmr48 + '" href="' + $(this).attr("href") + '"  target="_blank">Online</a>')
									}
									fixmr48++
								})
								var fixmrw = 0;
								$('.entry-content').find('a[href*="/drive.google.com"]').each(function () {
									var urlcsqa = $(this).attr("href").replace('https://drive.google.com/open?id=', 'https://drive.google.com/file/d/').replace('com/file/d', 'com/a/sv.hcmutrans.edu.vn/file/d').replace('/view?usp=sharing', '');
									if (!urlcsqa.match(/authuser\=/)) {
										$(this).attr("midix", fixmrw);
										$(this).replaceWith('<a onclick="window.open(\'' + urlcsqa + '/view?usp=sharing&authuser=4,\'_blank\'\')" href="' + urlcsqa + '/view?usp=sharing&authuser=4" midix="' + fixmrw + '" target="_blank">Download cFile <span style="color: #f2f2f2;">(password: 4horlover)</span></a>')
									}
									fixmrw++
								})
								$('p').each(function () {
									var $this = $(this);
									if ($this.html().replace(/\s| |\:/g, '').length == 0)
										$this.remove()
								});
								var nowcx = fixmrw;
								if (nowcx < 2) {
									var cnowcx = nowcx - 1
								} else {
									var cnowcx = nowcx - 2
								}
								$(".entry-content").find('a[target="_blank"]:not(a > img),img[src*="4horlover.com/wp-content"][width][height]').each(function () {
									var uri = $(this).attr('href');
									var imgc = !1;
									if (uri == null) {
										var uri = $(this).attr('src');
										imgc = !0
									}
									if (uri.match(/\.png|\.jpg/im) != null) {
										imgc = !1;
										console.log('PAFNHERE');
										if ($.inArray(uri, imglistt) == -1) {
											console.log(imglistt);
											if (imgc == !0) {
												var nextidoc = cnowcx + 1;
												$(this).parent('a').parent('p').parent('canv').find('p:has(a[midix="' + cnowcx + '"])').append('<center><img  border="0" src="' + uri + '" style="max-width:100%;margin-top: 5px;display: block; margin: auto;" /></center>');
												console.log(uri);
												cnowcx++;
												$(this).parent('a').remove();
												$(this).remove();
												var numofimg = $('img[src="' + uri + '"]');
												if (numofimg.length > 1) {
													for (i = 1; i < numofimg.length; i++) {
														numofimg[i].remove()
													}
												}
											} else {
												$(this).parent('p').append('<batn></batn><img  border="0" src="' + uri + '" style="max-width:100%;margin-top: 5px;display: block; margin: auto;" height="467" />');
												$(this).remove()
											}
											$('.entry-footer,a[rel="prev"],div.entry-meta,b:not(p > b),b:not(.novome)').remove();
											imglistt[ifmcount++] = uri
										}
										$(".entry-content").find('img[width="400"],img[width="225"]').each(function () {
											var uri = $(this).attr('src');
											$('<img  border="0" src="' + uri + '" style="max-width:100%;margin-top: 5px;display: block; margin: auto;" height="467" >').insertAfter($(this).parent('a').parent('p').parent('canv'));
											$(this).parent("a").remove()
										})
									}
								})
								if (count > 15) {
									$('.entry-content').append('<div style="position: relative;margin: 0 0 auto;width: 100%;text-align: center;"><h1><a href="' + urlv + '" style="font-size: 142%;vertical-align: middle;">< prevos</a></h1></div>')
								} else {
									$("vlcp:first").removeClass("cl");
									count++;
									loadncsdfi(urlv)
								}
							}
						})
					}
					try {
						var lengix = document.querySelector('.age-gate-message').innerHTML.length
					} catch (e) {
						var lengix = 0
					}
					if (lengix > 10) {
						document.cookie = "age_gate=22;";
						window.location.reload(!0)
					} else {
						loadncsdfi(window.location.href)
					}
					LFJ.hkoptimus()
				}, 1000)
			} else if (this.url.isdomain('4horlover.com')) {
				if (!window.location.href.match(/\Wp\=/)) {
					try {
						var noco = 0;
						var idkxs = '';
						for (i = 0; i < 4; i++) {
							if (idkxs == '') {
								if (document.querySelectorAll('h2.entry-title')[noco].querySelector('a').text.match(/link update|([0-9]+)\/([0-9]+)/)) {
									noco++
								}
								if (!document.querySelectorAll('h2.entry-title')[noco].querySelector('a').text.match(/link update|\W\s?([0-9]+)\/([0-9]+)/)) {
									idkxs = document.querySelectorAll('h2.entry-title')[noco].querySelector('a').href
								}
							}
						}
						window.location.href = idkxs
					} catch (e) {
						if (!window.location.href.match(/\wp\-content\/uploads/i)) {
							document.cookie = "age_gate=22;";
							window.location.reload(!0)
						}
					}
				}
			}
		},
		xvideos_com: function () {
			if (this.url.isdomain('xvideos-cdn.com') && window.location.href.match(/\.mp4/) || this.url.isdomain('xnxx-cdn.com') && window.location.href.match(/\.mp4/)) {
				LFJ.hkdownload()
			}
			if (location.href.isdomain('xvideos.red') || location.href.isdomain('xnxx.com')) {
				if (document.querySelector('h1.main-slider__item-title') || document.querySelector('.button.btn-primary.nav-btn.signup') || document.querySelector('.main-slider__item-btn.button btn-primary') || document.querySelector('h1.main-slider__item-title')) {
					ldjnoti(HLANG.WRONGPAGEXV, 'mid', !1, 15000, '#960d4b, #ac0976');
					setTimeout(function () {
						if (location.href.isdomain('xnxx.com')) {
							document.querySelector('span[onclick]').setAttribute('onclick', 'window.location.href="https://www.xnxx.com/gold/videos"')
						}
					}, 500)
				}
			}
			if (this.url.isdomain('xvideos.com') || this.url.isdomain('xvideos.es') || this.url.isdomain('xvideos4.com') || this.url.isdomain('xvideos5.com') || this.url.isdomain('xnxx.com') || location.href.match('proxier\.php') || this.url.isdomain('xnxx2.com') || this.url.isdomain('xnxx.es') || this.url.isdomain('xvideos.red')) {
				GM_addStyle(".lfjNodisplay,.thumb-block.thumb-ad,.thumb-block-pagin-next{display:none !important;}.tour-pushs,.page-title.channel.lighter,.x-overlay.x-overlay-box.premium-popup-form.opened,.x-overlay.x-overlay-box.auto-width-popup{display:none;}");
				LFJ.hkoptimus();
				if (window.location.href.match(/\Wsort\=([a-z0-9_-]+)/i)) {
					var sortcx = window.location.href.match(/\Wsort\=([a-z0-9_-]+)/i)[1];
					if (sortcx) {
						localStorage.setItem("sort_js", sortcx)
					}
				}
				if (window.location.href.match(/\Wdatef\=([a-z0-9_-]+)/i)) {
					var datefx = window.location.href.match(/\Wdatef\=([a-z0-9_-]+)/i)[1];
					if (datefx) {
						localStorage.setItem("datef_js", datefx)
					}
				}
				if (window.location.href.match(/\Wquality\=([a-z0-9_-]+)/i)) {
					var qualityx = window.location.href.match(/\Wquality\=([a-z0-9_-]+)/i)[1];
					if (qualityx) {
						localStorage.setItem("quality_js", qualityx)
					}
				}
				if (window.location.href.match(/\Wdurf\=([a-z0-9_-]+)/i)) {
					var durfx = window.location.href.match(/\Wdurf\=([a-z0-9_-]+)/i)[1];
					if (durfx) {
						localStorage.setItem("durf_js", durfx)
					}
				};
				if ($("div.filters-column").length >= 2 && window.location.href.match(/\?k\=/i)) {
					var newurl = window.location.href;
					if (!window.location.href.match(/\?/i)) {
						newurl = newurl + '?'
					} else {
						newurl = newurl + '&'
					}
					if (!window.location.href.match(/\Wsort\=([a-z0-9_-]+)/i) && localStorage.getItem("sort_js")) {
						newurl = newurl + 'sort=' + localStorage.getItem("sort_js")
					}
					if (!window.location.href.match(/\Wdatef\=([a-z0-9_-]+)/i) && localStorage.getItem("datef_js")) {
						newurl = newurl + '&datef=' + localStorage.getItem("datef_js")
					}
					if (!window.location.href.match(/\Wquality\=([a-z0-9_-]+)/i) && localStorage.getItem("quality_js")) {
						newurl = newurl + '&quality=' + localStorage.getItem("quality_js")
					}
					if (!window.location.href.match(/\Wdurf\=([a-z0-9_-]+)/i) && localStorage.getItem("durf_js")) {
						newurl = newurl + '&durf=' + localStorage.getItem("durf_js")
					}
					if (window.location.href + '&' != newurl) {
						window.location.href = newurl
					}
				}
				if (window.location.href.match(/\W(profiles|amateur\-channels)\/([a-z0-9_-]+)/i) && !window.location.href.match(/\#\_tab/i)) {
					var odcknum = !0;
					var videonum = 0;
					var dcldcsd = setInterval(function () {
						if (window.location.href.match(/(tabFavorites|tabVideos)/img)) {
							odcknum = !1;
							clearInterval(dcldcsd)
						}
						document.querySelectorAll('.tab-buttons')[0].querySelectorAll('.navbadge').forEach(function (e) {
							var hidlc = parseInt(e.innerHTML);
							var idc = e.parentNode.id;
							if (idc.match(/(tab\-videos)/i) && hidlc > 0 && !window.location.href.match(/\#\_tabVideos/i) && odcknum == !0) {
								e.parentNode.click();
								videonum = hidlc
							}
							if (idc.match(/(tab\-favorites)/i) && hidlc > 0 && !window.location.href.match(/\#\_tabFavorites/i) && odcknum == !0 && videonum == 0) {
								e.parentNode.click()
							}
						})
					}, 250)
				}
				if (window.location.href.match(/\/hits\//i)) {
					localStorage.setItem("hits_js", 'hits')
				}
				if (window.location.href.match(/\/year\//i)) {
					localStorage.setItem("date_js", 'year')
				}
				if (window.location.href.match(/\/month\//i)) {
					localStorage.setItem("date_js", 'month')
				}
				if (window.location.href.match(/\/hd\-only\//i)) {
					localStorage.setItem("hd_js", 'hd-only')
				}
				if (window.location.href.match(/\/20min\+\//i)) {
					localStorage.setItem("durf_js", '20min+')
				}
				if (window.location.href.match(/\/(([0-9]{2})+\-([0-9]{2})+([a-z0-9]+))\//i)) {
					localStorage.setItem("durf_js", window.location.href.match(/\/(([0-9]{2})+\-([0-9]{2})+([a-z0-9]+))\//i)[1])
				}
				$('div.ul').on('click', 'a[href*="search/"]', function (e) {
					var cids_uel = $(this).attr('href');
					if (!cids_uel.match(/\/hits\//i)) {
						localStorage.setItem("hits_js", '')
					}
					if (!cids_uel.match(/\/year|month\//i)) {
						localStorage.setItem("date_js", '')
					}
					if (!cids_uel.match(/\/hd\-only\//i)) {
						localStorage.setItem("hd_js", '')
					}
					if (!cids_uel.match(/\/20min\+|(([0-9]{2})+\-([0-9]{2})+([a-z0-9]+))\//i)) {
						localStorage.setItem("durf_js", '')
					}
				})
				if ($("div#listing-page-filters-block").length >= 1 && window.location.href.match(/\/search/i)) {
					var ocd = 'https://' + window.location.hostname + '/search';
					var dcocd = window.location.pathname.replace(/\/search/i, "");
					if (!window.location.href.match(/\/hits\//i) && localStorage.getItem("hits_js")) {
						ocd = ocd + '/' + localStorage.getItem("hits_js")
					}
					if (!window.location.href.match(/\/year|month\//i) && localStorage.getItem("date_js")) {
						ocd = ocd + '/' + localStorage.getItem("date_js")
					}
					if (!window.location.href.match(/\/hd\-only\//i) && localStorage.getItem("hd_js")) {
						ocd = ocd + '/' + localStorage.getItem("hd_js")
					}
					if (!window.location.href.match(/\/(([0-9]{2})+\-([0-9]{2})+([a-z0-9]+))|20min\+\//i) && localStorage.getItem("durf_js")) {
						ocd = ocd + '/' + localStorage.getItem("durf_js")
					}
					if (ocd + dcocd != window.location.href) {
						window.location.href = ocd + dcocd
					}
				}
				var is_xnxx = document.querySelector('#video-views-votes');
				if (this.url.isdomain('xnxx.com')) {
					$('span.icon.download').parent('a').remove();
					var divfcr = 'metadata-btn hide-if-zero-33';
					var civmdec = '#video-votes>.vote-actions'
				} else {
					var divfcr = 'btn btn-default';
					var civmdec = '#video-views-votes>.vote-actions'
				}
				if (LFJCONFIG.xvideosxnxx == !0) {
					if (window.location.href.match(/(\/new|\/gay)/)) {
						$("body").on('mouseenter', '.x-popup .main-cat-switcher,.popup-opened .main-cat-switcher', function (e) {
							localStorage.removeItem('node')
						});
						$('ul li a.last-page').html('100').attr('href', window.location.pathname.split('/')[1] + '/100');

						function xvnode(nai, page) {
							document.querySelector('#content .mozaique').classList.add('lfjNodisplay');
							if (nai === !1 || !localStorage.getItem('node')) {
								var cixc = page.split('||');
								document.querySelectorAll('#content .mozaique .thumb-block').forEach(function (xj) {
									xj.classList.add('lfjNodisplay')
								})
								GM_xmlhttpRequest({
									method: "GET",
									withCredentials: !0,
									url: 'https://dl.hoakhuya.com/redjq.php?page=' + cixc[0] + '&sex=' + (xv.conf.dyn.page_main_cat ? xv.conf.dyn.page_main_cat : window.location.pathname.split('/')[1]),
									dataType: "json",
									onload: function (data) {
										var jsonx = JSON.parse(data.responseText).html;
										var odkc = JSON.stringify($(jsonx).find(".mozaique").html());
										$("ul li a.active").text(cixc[0]);
										localStorage.setItem('node', odkc);
										if (nai === !1) {
											location.href = cixc[1]
										} else {
											history.go(0)
										}
									}
								})
							} else if (!document.querySelector('body[class*="newnode"]') && localStorage.getItem('node')) {
								return applines()
							}
						}
						if (!document.querySelector('body[class*="newnode"]') || !localStorage.getItem('node')) {
							xvnode(!0, '0')
						}
						$("body").on('click', '#main div ul li a', function (e) {
							e.preventDefault();
							xvnode(!1, $(this).text() + "||" + $(this).attr('href'));
							$("ul li a.active").removeClass('active');
							$(this).html('<img src="' + blfj_loading + '" style="max-width:16px;">').addClass('active')
						})
					}
					if (this.url.isdomain('xvideos.com') || this.url.isdomain('xvideos.es') || this.url.isdomain('xvideos4.com') || this.url.isdomain('xvideos5.com')) {
						var logolnk = 'new/1';
						if (xv.conf.dyn.user_main_cat === 'gay') {
							logolnk = 'gay'
						}
						if (!location.href.match('proxier\.php')) {
							document.getElementById('site-logo-link').href = '/' + logolnk;
							if (!location.search && location.pathname === '/' && !document.referrer.match(/\/new/i)) {
								window.location.href = '/new/1'
							}
						}
						$('#main,#profile-tabs').on('click', '.thumb a[href*="/video"],.thumb-under a[href*="/video"]', function (e) {
							e.preventDefault();
							var czd = $(this).attr('href').split('/').pop();
							if (czd.length > 500) {
								location.href = $(this).attr('href');
								return
							}
							var idlc = $(this).attr('href').split('/')[1].replace('video', '');
							if (!idlc) {
								idlc = $(this).parents('.thumb-block').attr('data-id')
							}
							if (idlc) {
								var url = 'https://'+'LFJ.iO'+'/red/' + (_lfjkm.key) + '/' + idlc;
								centeredPopup(url, 'pornhuvPrd', 1024, 640, 'yes')
							}
						})
					}
					if (this.url.isdomain('xnxx.com') || this.url.isdomain('xnxx2.com') || location.href.match('proxier\.php') || this.url.isdomain('xnxx.es')) {
						if (!location.href.match('proxier\.php')) {
							var logolnk = '';
							if (xv.conf.dyn.user_main_cat === 'gay') {
								logolnk = '-gay'
							}
							document.querySelector('.logo-xnxx a').href = '/gold/videos' + logolnk;
							if (!location.search && location.pathname === '/' && !document.referrer.match(/\/gold/i)) {
								window.location.href = '/gold/videos'
							}
						}
						$('#content,#gold-videos').on('click', '.thumb a[href*="/gold/"],.thumb-under a[href*="/gold/"],.thumb-under a[href*="=gold/"],.thumb a[href*="=gold/"]', function (e) {
							e.preventDefault();
							var idlc = $(this).parent().find('img[data-id]').attr('data-id');
							if (!idlc) {
								idlc = $(this).parents('.thumb-block').attr('data-id')
							}
							if (idlc) {
								var url = 'https://'+'LFJ.iO'+'/red/' + (_lfjkm.key) + '/' + idlc;
								centeredPopup(url, 'pornhuvPrd', 1024, 640, 'yes')
							}
						})
					}
				}
				if (window.location.href.match(/\Wxvideos\.[a-z0-9]{2,4}\/video[0-9]+\//i) || window.location.href.match(/\Wxnxx\.[a-z0-9]{2,4}\/video\W[a-z0-9]+\//i)) {
					$('body').on('click', 'a.lfjdownloadhls', function (e) {
						e.preventDefault();
						lfjdownload($(this).attr('href'), !0, '.lfjdownloadhls span:not([class])')
					})
					var hlsbicd = setInterval(function () {
						try {
							if (window.html5player || html5player) {
								if (html5player !== 'null') {
									var videotitles = removehtml(html5player.video_title);
									var hiflh = html5player.url_high + '&h=' + videotitles;
									var lowxe = html5player.url_low + '&h=' + videotitles;
									var iceodsx720 = html5player.hlsobj._events.hlsKeyLoaded[0].context.streamController.fragCurrent.baseurl
								} else {
									var videotitles = removehtml(window.html5player.video_title);
									var hiflh = window.html5player.url_high + '&h=' + videotitles;
									var lowxe = window.html5player.url_low + '&h=' + videotitles;
									var iceodsx720 = window.html5player.hlsobj._events.hlsKeyLoaded[0].context.streamController.fragCurrent.baseurl
								}
								if (iceodsx720.match(/hls\-720p/i)) {
									var bh35720p = '<a class="' + divfcr + ' buttoncopy btn btn-default lfjdownloadhls" href="' + iceodsx720 + '"  data-clipboard-text="' + videotitles + '.mp4"><span class="icon download"></span><span>HLS 720P</span></a>'
								} else if (iceodsx720.match(/hls\-1080p/i)) {
									var bh35720p = '<a class="' + divfcr + ' buttoncopy btn btn-default lfjdownloadhls" href="' + iceodsx720 + '"  data-clipboard-text="' + videotitles + '.mp4"><span class="icon download"></span><span>HLS 1080P</span></a>'
								} else {
									var bh35720p = ''
								}
								$('' + civmdec + '').append(bh35720p);
								$('' + civmdec + '').append('<a class="' + divfcr + ' buttoncopy btn btn-default" href="' + hiflh + '" target="_blank"  data-clipboard-text="' + videotitles + '.mp4"><span class="icon download " ></span><span>640P</span></a>');
								$('' + civmdec + '').append('<a class="' + divfcr + ' buttoncopy btn btn-default" href="' + lowxe + '" target="_blank" data-clipboard-text="' + videotitles + '.mp4"><span class="icon download"></span><span>360P</span></a>');
								clearInterval(hlsbicd)
							}
						} catch (e) {
							console.log('ds')
						}
					}, 150)
				}
				if (is_xnxx == !0) {
					setTimeout(function () {
						$("div.tab-buttons").children()[1].remove();
						$("div.tab-buttons").children()[2].remove()
					}, 100);
					$("#video-ad,#footer").remove();
					var timer = setInterval(function () {
						if ($("a.btn.btn-default.show-more").css('display') == 'block') {
							$("a.btn.btn-default.show-more").trigger("click")
						} else {
							clearInterval(timer)
						}
					}, 1000)
				} else {
					localStorage.setItem("forcequality", '{"value":8,"expire":' + ((Math.floor(Date.now() / 1000)) + 80000) + '}');
					var timer = setInterval(function () {
						if ($("a.btn.btn-default.show-more").css('display') == 'block') {
							$("a.btn.btn-default.show-more").trigger("click")
						} else {
							clearInterval(timer)
						}
					}, 1000);
					$("#video-ad,#ad-header-mobile,footer,#ad-footer,.remove-ads,span.nb-views,.thumb-block.thumb-ad").remove();
					$("div#video-player-bg").css('width', '100%');
					setTimeout(function () {
						$("#tabComments_bottom_page").remove();
						$("ul.tab-buttons").find('li>a>span.icon.download').parent('a').parent('li').hide();
						$("ul.tab-buttons").find('li>a>span.icon.report').parent('a').parent('li').hide();
						$("ul.tab-buttons").find('li>a>span.icon.share-small').parent('a').parent('li').hide()
					}, 100)
				}
			}
		},
		hoakhuya_com: function () {
			if (this.url.isdomain(''+'lfj'+'.io') && !location.href.match('proxier\.php')) {
				var curentSetting = GM_getValue('LFJCONFIG') ? hencrypt(JSON.stringify(LFJCONFIG), 'lfj') : {};
				var cifgc = GM_getValue('client') ? GM_getValue('client') : '';
				var GM_data = {
					script: {
						'author': GM_info.script.author,
						'homepage': GM_info.script.homepage,
						'copyright': GM_info.script.copyright,
						'name': GM_info.script.name,
						'version': GM_info.script.version,
						'uid': GM_info.uuid,
						'setting': curentSetting,
						'cid': cifgc
					},
					'handler': {
						'name': GM_info.scriptHandler,
						'version': GM_info.version,
                        'origin':'sleazyfork'
					}
				};
				document.head.appendChild(Object.assign(document.createElement('script'), {
					innerHTML: "var GM_info=JSON.parse('" + (JSON.stringify(GM_data)) + "');if(GM_info.script.setting.length>2){GM_info.script.setting=JSON.parse(hdecrypt(GM_info.script.setting,'lfj'));}"
				}))
			}
		},
		appupdate: function () {
			if (document.querySelector("p,div,a,i,u,b,title,p,script,style,link") != null) {
				var issupported = _lfjkm.sites.includes(mainhostname.replace('\\', ''));
				if (issupported === !0) {
					var curent = parseInt(Math.floor(Date.now() / 1000));
					var expiredcc = curent + 84600;
					var urlupdate = 'https://'+'LFJ.iO'+'/lfj.user.js?_=' + new Date().getTime();
					GM_xmlhttpRequest({
						method: "GET",
						url: urlupdate,
						onload: function (response) {
							var newversion = parseInt(response.responseText.match(/version(.+)$/im)[1].replace(/\s/g, ""));
							var nowversion = parseInt(GM_info.script.version);
							if (newversion > nowversion) {
								GM_registerMenuCommand("Report issue", gmclixclick_mustupdate);
								GM_registerMenuCommand("Update to latest version", gmclixclick_reinstall);
								if (document.querySelector("#trytohack,#hacksuccescs,#hacksuccess,#hacksuccescs,.customremoved")) {
									document.querySelector("#trytohack,#hacksuccescs,#hacksuccess,#hacksuccescs,.customremoved").remove();
									setTimeout(function () {
										document.querySelector("#trytohack,#hacksuccescs,#hacksuccess,#hacksuccescs,.customremoved").remove()
									}, 500);
									var span = document.createElement('center');
									span.id = "trytohackC"
									span.style.cssText = '    font-size: 32px;padding: 50px;';
									if (document.querySelector('#main-container')) {
										span.innerHTML = "<h3 style='text-transform: unset; max-width: 400px; padding: 93px;' data-lfjlang='PLEASE_UPDATE_TOUSE'></h3>";
										document.querySelector('#main-container').insertBefore(span, document.querySelector('#main-container').firstChild)
									}
									if (document.querySelector('#videoShow')) {
										span.innerHTML = "<h3 style='text-transform: unset; max-width: 400px; padding: 20px;' data-lfjlang='PLEASE_UPDATE_TOUSE'></h3>";
										document.querySelector('#videoShow').insertBefore(span, document.querySelector('#videoShow').firstChild)
									}
									document.querySelector('#videoShow,#main-container').setAttribute('id', 'd54d')
								}
							} else {
								GM_registerMenuCommand('Report issue', gmclixclick_issuse);
								GM_registerMenuCommand('Write a review', gmclixclick_treview)
							}
							if (newversion > nowversion && localStorage.getItem('update_remind') < curent) {
								try {
									var newupdatetxt = response.responseText.match(/\/\/UDT\#\!(.+)$/im)[0].replace("//UDT#!", "")
								} catch (e) {
									var newupdatetxt = '<li>Improved script</li>'
								}
								try {
									var updateurli = response.responseText.match(/\/\/DUR\#\!(.+)$/im)[0].replace("//DUR#!", "")
								} catch (e) {
									var updateurli = 'https://'+'lfj'+'.io/lfj.user.js?_=' + new Date().getTime()
								}
								var maxwidth = '45em !important';
								var h2fontsize = '22';
								var maxfont = '100%;';
								if (window.location.href.match(/(xhamster\.)/i)) {
									maxwidth = '34em !important'
								} else if (window.location.href.match(/(xvideos\.|xnxx\.)/i)) {
									maxwidth = '45em !important';
									h2fontsize = '22';
									maxfont = '80%'
								} else if (window.location.href.match(/(pornhub\.)/i)) {
									maxwidth = '40em !important';
									h2fontsize = '20'
								} else if (window.location.href.match(/(4horlover\.)/i)) {
									maxwidth = '31em !important';
									h2fontsize = '20';
									maxfont = '60%'
								} else if (window.location.href.match(/(tube8\.)/i)) {
									maxwidth = '40em !important';
									h2fontsize = '20'
								} else if (window.location.href.match(/(xtube\.)/i)) {
									maxwidth = '38em !important'
								} else if (window.location.href.match(/(thisav\.)/i)) {
									maxwidth = '40em !important';
									h2fontsize = '20'
								} else if (window.location.href.match(/(porntrex\.)/i)) {
									maxwidth = '40em !important';
									h2fontsize = 23
								} else if (window.location.href.match(/(modelhub\.)/i)) {
									maxwidth = '31em !important';
									h2fontsize = 23
								}
								var htmccs = '<style>.c5d8v2cd>li{list-style:unset;text-transform: none !important;margin-bottom: 10px;} code>li{padding-top: 5px;}.hkoverlay { z-index:3210;position: fixed; top: 0; bottom: 0; left: 0; right: 0; background: rgba(0, 0, 0, 0.7); transition: opacity 500ms; visibility: visible; opacity: 1; }' + '.hkoverlay:target { visibility: hidden; opacity: 0; } .hkpopup { margin: 70px auto !important; padding: 20px !important; padding-top: 10px; background: #03243af5; border-radius: 5px; width: 60%;text-align: left; max-width: ' + maxwidth + '; position: relative; transition: all 1s ease-in-out; }' + '.hkpopup h2 { margin-top: 0; color: #e9e9e9; font-family: Tahoma, Arial, sans-serif;text-transform: unset; }.hkbutton { display: inline-block; border-radius: 4px; background-color: #C60689; border: none; color: #FFFFFF; text-align: center; font-size: 16px; padding: 10px; width: fit-content; transition: all 0.5s; cursor: pointer; margin: 3px; } .hkbutton span { cursor: pointer; display: inline-block; position: relative; transition: 0.5s; } .hkbutton span:after { content: \'\\00bb\'; position: absolute; opacity: 0; top: 0; right: -20px; transition: 0.5s; } .hkbutton:hover span { padding-right: 10px; } .hkbutton:hover span:after { opacity: 1; right: 0; }' + '.hkpopup .hkclose { position: absolute; top: 4px; right: 13px; transition: all 200ms; font-size: 30px; font-weight: bold; text-decoration: none; color: #e9e9e9; }' + '.hkpopup .hkclose:hover { color: #06D85F; }.hkpopup .hkcontent { max-height: 30%; overflow: auto; width: 100% !important;} @media screen and (max-width: 780px){ .hkpopup{ width: 96%;max-width:45em;    display: block; } }</style>' + '<div id="hoakhuyapop" class="hkoverlay">' + '<div class="hkpopup">' + '<h2 style="font-size: ' + h2fontsize + 'px !important;margin: 8px 0;font-weight: 700;line-height: 1.1;display: block;"><img  src="' + blfj_logo + '" style="max-width:70px; vertical-align: middle; margin-right: 5px;    display: inline;" /><span data-lfjlang="NEW_VERSION_DLB"></span></h2>' + '<a onclick="localStorage.setItem(\'update_remind\', parseInt(Math.floor(Date.now() / 1000))+42300);" class="hkclose" href="#hoakhuyapop">×</a>' + '<div class="hkcontent" style="display: inline-block;color:#6ed9d2;font-size: 12px !important;line-height: 1.5;">' + '<span  data-lfjlang="NEW_VERSION_T1"></span> #<u>' + nowversion + '</u>. <span  data-lfjlang="NEW_VERSION_T2"></span>' + '<h3 style="display: block;background-color: #322106;color: #ccc;font-size: 1.1em;font-weight: 700;line-height: 1;margin: 0;padding: 21x;text-transform: uppercase;position: relative;margin-top: 10px;padding: 10px;"><span  data-lfjlang="CHANGE_LOG"></span> #<u>' + newversion + '</u></h3>' + '<div class="c5d8v2cd" style="background-color: #194b6c;font-size: 1.05em !important;font-weight: 600;color: goldenrod;line-height: 1.2;padding: 21px;text-transform: uppercase;position: relative;margin-top: 1px;font-family: monospace;">' + '' + newupdatetxt + '<div>' + '<div style="margin-top: 20px; text-align: right;margin-right: 20px;"><button onclick="window.open(\'http://'+'LFJ.iO'+'/?ref=1/\', \'_blank\')" class="hkbutton" style="vertical-align:middle;background-color: #607d8b;"><span class="hkbutton0" style="font-size: ' + maxfont + '">' + HLANG.HOMEPAGE + '</span></button> <button onclick="try{if(document.getElementsByClassName(\'hkbutton1\')[0].innerHTML.match(/(refresh|刷新|tải\\slại)/gim).length==1){location.reload();}} catch(e){document.getElementsByClassName(\'loadingimg\')[0].style.display=\'inline\';document.getElementsByClassName(\'hkbutton1\')[0].innerHTML=\'' + HLANG.ONDOWNLOAD + '\';setTimeout(function(){window.location.href=\'' + updateurli + '\';document.getElementsByClassName(\'hkbutton1\')[0].innerHTML=\'' + HLANG.OPEN_WINDOW + '\';document.getElementsByClassName(\'loadingimg\')[0].style.display=\'none\';}, 1500);setTimeout(function(){document.getElementsByClassName(\'hkbutton1\')[0].innerHTML=\'' + HLANG.REFESH + '\';}, 6000);}; " class="hkbutton" style="vertical-align:middle"><span class="hkbutton1" style="font-size: ' + maxfont + '">' + HLANG.UPNOW + '</span><img class="loadingimg" style="vertical-align: middle; display: none;" src="data:image/gif;base64,R0lGODlhGAAYAPcAAAAAAAEBAQICAgMDAwQEBAUFBQYGBgcHBwgICAkJCQoKCgsLCwwMDA0NDQ4ODg8PDxAQEBERERISEhMTExQUFBUVFRYWFhcXFxgYGBkZGRoaGhsbGxwcHB0dHR4eHh8fHyAgICEhISIiIiMjIyQkJCUlJSYmJicnJygoKCkpKSoqKisrKywsLC0tLS4uLi8vLzAwMDExMTIyMjMzMzQ0NDU1NTY2Njc3Nzg4ODk5OTo6Ojs7Ozw8PD09PT4+Pj8/P0BAQEFBQUJCQkNDQ0REREVFRUZGRkdHR0hISElJSUpKSktLS0xMTE1NTU5OTk9PT1BQUFFRUVJSUlNTU1RUVFVVVVZWVldXV1hYWFlZWVpaWltbW1xcXF1dXV5eXl9fX2BgYGFhYWJiYmNjY2RkZGVlZWZmZmdnZ2hoaGlpaW9ja3tZcIVPdJFCeJ80faomgLQbg7sThsANh8MJiMQHiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMYGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicYKi8gSj8oakssglcwll84rms8ync83n9A7odA/otBEpNBIpc9Nps5Sp81Xp8peqMdoqcNzqb9/qrqJq7eSq7ScrLKirbCorq+vr7CwsLGxsbKysrOzs7S0tLW1tba2tre3t7i4uLm5ubq6uru7u7y8vL29vb6+vr+/v8DAwMHBwcLCwsPDw8TExMXFxcbGxsfHx8jIyMnJycrKysvLy8zMzM3Nzc7Ozs/Pz9DQ0NHR0dLS0tPT09TU1NXV1dbW1tfX19jY2NnZ2dra2tvb29zc3N3d3d7e3t/f3+Dg4OHh4eLi4ubk5evo6u7r7fHt8PPv8vXx9Pfz9vj2+Pr5+vz8/Pz8/P39/f7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v///yH/C05FVFNDQVBFMi4wAwEAAAAh+QQAAwAAACwAAAAAGAAYAAAIrQATCRxIsKDBgwgTKlzIkGCof/9CNRxYauDDiBQXlvqHqlMqdRDVpeqE6l9FhBshqly58uTBkhDNoSJFCpU5lagUeoKYsyBMTwpV/SOHkNw/VQhDhVrHEWHJdUoNtkS5UqpKUghJVS2oFGRPgyXVRT2Y6p85hDdTKezEEyzETgpTDkVVqhQqoxBdGpTLsq/eghtLeVLF9N86VZ4Ca7QIUaLAvwsvOp5IubLlywEBACH5BAADAAAALAAAAAAYABgAhwAAAAEBAQICAgMDAwQEBAUFBQYGBgcHBwgICAkJCQoKCgsLCwwMDA0NDQ4ODg8PDxAQEBERERISEhMTExQUFBUVFRYWFhcXFxgYGBkZGRoaGhsbGxwcHB0dHR4eHh8fHyAgICEhISIiIiMjIyQkJCUlJSYmJicnJygoKCkpKSoqKisrKywsLC0tLS4uLi8vLzAwMDExMTIyMjMzMzQ0NDU1NTY2Njc3Nzg4ODk5OTo6Ojs7Ozw8PD09PT4+Pj8/P0BAQEFBQUJCQkNDQ0REREVFRUZGRkdHR0hISElJSUpKSktLS0xMTE1NTU5OTk9PT1BQUFFRUVJSUlNTU1RUVFVVVVZWVldXV1hYWFlZWVpaWltbW1xcXF1dXV5eXl9fX2BgYGFhYWJiYmNjY2RkZGVlZWZmZmdnZ2hoaGlpaW9ja3tZcIVPdJFCeJ80faomgLQbg7sThsANh8MJiMQHiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMYGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUHicQKicQSjMQbjsImkMI2lsFGmr9UnbxioLlvobSAo66PpKmepqmpqaqqqqurq6ysrK2tra6urq+vr7CwsLGxsbKysrOzs7S0tLW1tba2tre3t7i4uLm5ubq6uru7u7y8vL29vb6+vr+/v8DAwMHBwcLCwsPDw8TExMXFxcbGxsfHx8jIyMnJycrKysvLy8zMzM3Nzc7Ozs/Pz9DQ0NHR0dLS0tPT09TU1NXV1dbW1tfX19jY2NnZ2dra2tvb29zc3N3d3d7e3t/f3+Dg4OHh4eXh5Onj5+3l6/Ho7vTp8PXr8vbs8/jv9fnx9/r1+fv3+vz6/P37/f79/f7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v///wi8ABMJHEiwoMGDCBMqXMiwoKh/5kg1FBhKmSeBpP79EzVRlLp/4qRp1CiOoyeOCT2RG8lSo7Jx6kIpVKZRXSlRooKZY6ks4cN/5C4OVElSaEFSosRBNDr04zSEOzUGQ2hKI0KWKA3+RKo140aEP60e1GgKYbCR5hBO+6eOqUBPO0tKNOhJ6b9xTD2N05jVIE20wXCW+vivZ8JQ6sj9bakRr0JRF5OynKZUXd/HGud6UiZzIqmdlyeKHk16dEAAIfkEAAMAAAAsAAAAABgAGACHAAAAAQEBAgICAwMDBAQEBQUFBgYGBwcHCAgICQkJCgoKCwsLDAwMDQ0NDg4ODw8PEBAQEREREhISExMTFBQUFRUVFhYWFxcXGBgYGRkZGhoaGxsbHBwcHR0dHh4eHx8fICAgISEhIiIiIyMjJCQkJSUlJiYmJycnKCgoKSkpKioqKysrLCwsLS0tLi4uLy8vMDAwMTExMjIyMzMzNDQ0NTU1NjY2Nzc3ODg4OTk5Ojo6Ozs7PDw8PT09Pj4+Pz8/QEBAQUFBQkJCQ0NDRERERUVFRkZGR0dHSEhISUlJSkpKS0tLTExMTU1NTk5OT09PUFBQUVFRUlJSU1NTVFRUVVVVVlZWV1dXWFhYWVlZWlpaW1tbXFxcXV1dXl5eX19fYGBgYWFhYmJiY2NjZGRkZWVlZmZmZ2dnaGhoaWlpb2Nre1lwhU90kUJ4nzR9qiaAtBuDuxOGwA2HwwmIxAeIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxgaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQeJxhGNxxmQxyGSxiqUxDOWwj+Yv0yau1qct2qesIChrY2jqZ6mqampraersqWutqSwuqKyv520xJe2yJK3zYu40IW404C41Xy41ni42HW42HO42XG42nC42m+42m64226422242224226422653HC63XK73XS83na93nm+3nu/333A34DB34TC34jD34vE34zF347F3pDF3pPG3pfH35vJ35/K36LL3qTM36vO4LLR4brU48DX5MXa5svd58/g6NTi6tjk69zm7d/p7t/q8ODr8eDs8uHt8+Hu9OHu9eLv9eLw9uPw9uPx9+Xy+Oby+ej0+er0+uz2++/3+/H4/PP5/PT6/Pb6/fj7/vv9/vz9/v3+/v3+/v7+/v7+/v7+/v7+/v7+/v7+////CLwAEwkcSLCgwYMIEypcyFCgqIGf3k172FBUtn+hEolK9u9fr4YaO57rSPIjyHQkU/57ppEiwmkd0w0TtRGeyH/ZDorq1atjN08EPXVL6XIgzI7wgBb0hDJdRoM2OyZD+KwjQk8c/xUlKKrj1oFdtSIMm0ypwY4sD2b9l+5gqJHnzA709I7kNINhfcoV2pHn10Ta2HZ8l4ymsJErFdJMVFWlSJCJeqZEKbah5GQZQ/3T9lfntKRgIYseTRpkQAAh+QQAAwAAACwAAAAAGAAYAIcAAAABAQECAgIDAwMEBAQFBQUGBgYHBwcICAgJCQkKCgoLCwsMDAwNDQ0ODg4PDw8QEBARERESEhITExMUFBQVFRUWFhYXFxcYGBgZGRkaGhobGxscHBwdHR0eHh4fHx8gICAhISEiIiIjIyMkJCQlJSUmJiYnJycoKCgpKSkqKiorKyssLCwtLS0uLi4vLy8wMDAxMTEyMjIzMzM0NDQ1NTU2NjY3Nzc4ODg5OTk6Ojo7Ozs8PDw9PT0+Pj4/Pz9AQEBBQUFCQkJDQ0NERERFRUVGRkZHR0dISEhJSUlKSkpLS0tMTExNTU1OTk5PT09QUFBRUVFSUlJTU1NUVFRVVVVWVlZXV1dYWFhZWVlaWlpbW1tcXFxdXV1eXl5fX19gYGBhYWFiYmJjY2NkZGRlZWVmZmZnZ2doaGhpaWlvY2t7WXCNRnagMX2vIYG5FYW/DofCCYjEB4jFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGB4nGCIrHC4vHDo3IE4/JGZLLIJXMJ5jNLpvOMp3ON57OOJ/OOqDOPaDOP6HNQaHNQ6HNRqLNSaPNS6TNTqXMUKXLU6XKV6bJW6bGYafFZqfDbKjBdKnAeqq/gay/iK2+kK+9l7G9oLS8qba8srm8vLy9vb2+vr6/v7/CvsHGvcPJvMXMu8bPusjRucnTuMvWt8zXts3atM7dr8/frM/hqc/ip8/jpc/kpM/ko8/lo9Dlo9Dmo9Dmo9DmpNHmptHlqNHlq9LkrtPks9TjudbjvNfjv9fjwdjjxNnjyNrky9zkz93m1ODn2uPp4Obr5+ru7u7w8PDz8vP28/X39fb59vj69/n7+fr8+vv9/Pz9/f3+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7///8IqQAPCRxIsKDBgwgTKlzIUOCqaQSrrWooENq/f6tQnXp1URZFTxdDhvREsZpIkdAWQvNk8h87WahQyWJ3cWVKg6tEfttEcNM3kRMLtnTJs+AmmherHcz576ZBixgRgrqICiGqi6CkUrWKFSHHpgihBhUakl3Rnkj/KS3I9OLOnj9DjiVo8+LLU6dm1vTkNOzJkH0Vgvz7j2RDsTG/Bla4aq1AiRQjS55MOSAAIfkEAAMAAAAsAAAAABgAGACHAAAAAQEBAgICAwMDBAQEBQUFBgYGBwcHCAgICQkJCgoKCwsLDAwMDQ0NDg4ODw8PEBAQEREREhISExMTFBQUFRUVFhYWFxcXGBgYGRkZGhoaGxsbHBwcHR0dHh4eHx8fICAgISEhIiIiIyMjJCQkJSUlJiYmJycnKCgoKSkpKioqKysrLCwsLS0tLi4uLy8vMDAwMTExMjIyMzMzNDQ0NTU1NjY2Nzc3ODg4OTk5Ojo6Ozs7PDw8PT09Pj4+Pz8/QEBAQUFBQkJCQ0NDRERERUVFRkZGR0dHSEhISUlJSkpKS0tLTExMTU1NTk5OT09PUFBQUVFRUlJSU1NTVFRUVVVVVlZWV1dXWFhYWVlZWlpaW1tbXFxcXV1dXl5eX19fYGBgYWFhYmJiY2NjZGRkZWVlZmZmZ2dnaGhoaWlpb2Nre1lwhU90mDp6qCl/sxuDuxKGwAyHwwmIxAeIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxwuLyA+NyRSPyhmSzCKWzSmZzzCc0Def0Tyh0j+j0kGk0kOl0kSl0kWl0kal0Uel0Uml0Eumz06mzlCmzVSmy1mnyl2nyGKoyGaox2qpxm6qxXKrxHesw3ytwoKuwYivwY6xwJWyv5y0vqS2vqu4vbS6vb29vr6+v7+/wr7Bxr3DybzFzLvGz7rI0bnJ07jL1rfM17bN2rTO3a/P36zP4anP4qfP46XP5KTP5KPP5aPQ5aPQ5aPQ5aTQ5aXQ5abR5ajR5avS5K7T5LPU47nW47zX47/X48HY48TZ48ja5Mvc59Lg6tnl7d7p8OPs8efu8+vx9O3y9u/09/H1+PT3+fX4+vX4+/f6/Pf6/Pj7/fn8/fr8/vv9/vz9/v3+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+////CLMAEQkcSLCgwYMIEypcyFDgqGjqMg0c1XBgq3//oIlCNOrfN4oNL2LEWA4jSISjKEYbyfJfuYXfXGJsBy2lrJIZE3YcOU7iwEzjMLZqdZKgp5LlfBLM1G5kNIQYoSGENlLdwZ1FCe6EpnTgJqr/sk40ebBp1KkYEa7EGNFgJqSerg7F2HNp0JFiB4ItF0uUKGjqSHpciLNlzpQKdxYWWnFUzLiewLaq6NBru2h5KWvezPlgQAAh+QQAAwAAACwAAAAAGAAYAIcAAAABAQECAgIDAwMEBAQFBQUGBgYHBwcICAgJCQkKCgoLCwsMDAwNDQ0ODg4PDw8QEBARERESEhITExMUFBQVFRUWFhYXFxcYGBgZGRkaGhobGxscHBwdHR0eHh4fHx8gICAhISEiIiIjIyMkJCQlJSUmJiYnJycoKCgpKSkqKiorKyssLCwtLS0uLi4vLy8wMDAxMTEyMjIzMzM0NDQ1NTU2NjY3Nzc4ODg5OTk6Ojo7Ozs8PDw9PT0+Pj4/Pz9AQEBBQUFCQkJDQ0NERERFRUVGRkZHR0dISEhJSUlKSkpLS0tMTExNTU1OTk5PT09QUFBRUVFSUlJTU1NUVFRVVVVWVlZXV1dYWFhZWVlaWlpbW1tcXFxdXV1eXl5fX19gYGBhYWFiYmJjY2NkZGRlZWVmZmZnZ2doaGhpaWlvY2t7WXCFT3SRQnifNH2qJoC0G4O7E4bADYfDCYjEB4jFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojGBonGBonGBonGBonGBonGBonGBonGBonGBonGCIrGCYrHC4vHDozHD43IEI7IEY7IE4/JFZDJGJHKGpLKHJPLH5XMI5bNKJnOL5zQNp/SPqPTQqXTRqfUSajVTarWUqzXWK/YYbLZZbTZaLXaa7bab7jbdLrberzcfr7chMDdjMPflMfgmcngm8rhncvhnsvhn8zhoczhoszho83gpc3fp83eqc3dqszcq8zarczZr8vXssvWtMvVtsvUuMvTusvSvcvRwMvQw8zPxszOys3Ozs7Pz8/Q0NDR0dHS0tLT09PU1NTV1dXW1tbX19fY2NjZ2dna2trb29vc3Nzd3d3f3t/i3+Hk4OPm4OTn4ebq4+js5Oru5uzw5+3x6O/z6fD16/L27fT47vX48Pb58ff68/j79Pn89vr8+fv9/P3+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7///8IvAATCRxIsKDBgwgTKlzIcOAqdP9INTxI6t+/VQI18RK1kJSmRKTCWbT4S2Q7iQhFtRvHa6RLi+Q+Imw5Eh0tUqRetbPIS6Emkf9iEtREziJKhL/+tZM5FGI4UhgPWpSFkFZNg1CNIqw40qDLowW5rgIrEKJFWghlWUQ4ViQ6pgM17fylkOs4uJrGWQwH1yDNdq9w0jLLM2Hely55kWvHcevOcElHPk2kiaxBUbxkrtI6Mew/dFE7ix5NumFAACH5BAADAAAALAAAAAAYABgAhwAAAAEBAQICAgMDAwQEBAUFBQYGBgcHBwgICAkJCQoKCgsLCwwMDA0NDQ4ODg8PDxAQEBERERISEhMTExQUFBUVFRYWFhcXFxgYGBkZGRoaGhsbGxwcHB0dHR4eHh8fHyAgICEhISIiIiMjIyQkJCUlJSYmJicnJygoKCkpKSoqKisrKywsLC0tLS4uLi8vLzAwMDExMTIyMjMzMzQ0NDU1NTY2Njc3Nzg4ODk5OTo6Ojs7Ozw8PD09PT4+Pj8/P0BAQEFBQUJCQkNDQ0REREVFRUZGRkdHR0hISElJSUpKSktLS0xMTE1NTU5OTk9PT1BQUFFRUVJSUlNTU1RUVFVVVVZWVldXV1hYWFlZWVpaWltbW1xcXF1dXV5eXl9fX2BgYGFhYWJiYmNjY2RkZGVlZWZmZmdnZ2hoaGlpaW9ja3tZcIVPdJFCeJ80faomgLQbg7sThsANh8MJiMQHiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMYGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicYHicYHicYIisYJisYKiscOjcgSjskWkMkZkcoek8sllswsmcwxm802ncw6nsw/n8pEoMlKoMZTocNbor9oo7l7pbWKp7KYqrGeq6+lrK6urq+vr7CwsLGxsbKysrOzs7S0tLW1tba2tre3t7i4uLm5ubq6uru7u7y8vL29vb6+vr+/v8DAwMHBwcLCwsPDw8TExMXFxcbGxsfHx8jIyMnJycrKysvLy8zMzM3Nzc7Ozs/Pz9DQ0NHR0dLS0tPT09TU1NXV1dbW1tfX19jY2NnZ2dra2tvb29zc3N3d3d7e3t/f3+Dg4OHh4eLi4uTk5Ojo6O7s7vLv8fXx9Pfy9fj09/r1+Pv2+fz4+vz5+/37/f79/f7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v///wirABMJHEiwoMGDCBMqXMiQIKl//0g1HLhp4MOIFBeGUneKlDSIEKWROqUuVMJN6kCqXKmuIsJTINWlIkUqVUqIpxRe5OZS4CZuECUmnPavpUGU/6YhJDUKYiqEqSCOGmVQpVCDFyFWBXm1YNZ/WC8+PRg1YleCRI0WRKo04cVtPRNt2hZUIUyIMqfaBJkTIdKVgNUe3NiRKMhpI0su7HnxalyGjSdKnky5ssCAADsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" /></button></div>' + '</div>' + '</div>' + '</div>';
								document.body.innerHTML += htmccs;
								reLANG()
							} else if (newversion > nowversion) {
								ldjnoti(HLANG.NEW_VERSION_NOFT, !0, urlupdate, 10000, '#e4380c, #ff234e')
							}
						}
					})
				}
			}
		},
		github_com: function () {
			if (this.url.isdomain('github.com') || this.url.isdomain('github.io')) {
				if (document.querySelector('#readme')) {
					document.querySelector('#readme').querySelectorAll('a[rel*="nofollow"]').forEach((al) => {
						al.setAttribute("rel", 'nofollow noopener noreferrer');
						al.setAttribute("target", '_blank')
					})
				}
				if (document.querySelector('section')) {
					document.querySelector('section').querySelectorAll('a[href*="http"]').forEach((al) => {
						al.setAttribute("rel", 'nofollow noopener noreferrer');
						al.setAttribute("target", '_blank')
					})
				}
			}
		},
		bypassuri: function () {
			if (this.url.isdomain('ouo.io') || this.url.isdomain('ouo.press')) {
				try {
					$.each($('iframe'), function () {
						const AdservingModule = "";
						this.contentWindow.open = function () {}
					})
				} catch (e) {
					window.open = function (url, windowName, windowFeatures) {}
				}
				window.open = function (url, windowName, windowFeatures) {};
				var flimitedoc = !1;
				document.querySelectorAll('iframe,script,img,link').forEach(function (xj) {
					xj.parentNode.removeChild(xj)
				})

				function contribute(ctagerf, domaindunam, patchid) {
					GM_xmlhttpRequest({
						method: 'POST',
						headers: {
							"accept": "*/*",
							"accept-language": "vi-VN,vi;q=0.9,zh-CN;q=0.8,zh;q=0.7",
							"Sec-Fetch-Site": "cross-site",
							"Sec-Fetch-Mode": "cors",
							"DNT": "1",
							"Content-Type": "application/x-www-form-urlencoded",
							"Origin": "chrome-extension://aihomhdbhpnpmcnnbckjjcebjoikpihj",
							"User-Agent": navigator.userAgent
						},
						url: 'https://universal-bypass.org/crowd/contribute_v1',
						data: "domain=" + domaindunam + "&path=" + patchid + "&target=" + encodeURIComponent(ctagerf),
						onload: function (response) {
							console.log('contribute success' + domainame + '/' + pavvcc);
							window.location.href = '' + ctagerf + ''
						}
					})
				}

				function trybypas(doamcinema, fivjspat, submit = 'no') {
					GM_xmlhttpRequest({
						method: 'POST',
						headers: {
							"accept": "*/*",
							"accept-language": "vi-VN,vi;q=0.9,zh-CN;q=0.8,zh;q=0.7",
							"Sec-Fetch-Site": "cross-site",
							"Sec-Fetch-Mode": "cors",
							"DNT": "1",
							"Content-Type": "application/x-www-form-urlencoded",
							"Origin": "chrome-extension://aihomhdbhpnpmcnnbckjjcebjoikpihj",
							"User-Agent": navigator.userAgent
						},
						url: 'https://universal-bypass.org/crowd/query_v1',
						data: "domain=" + doamcinema + "&path=" + fivjspat,
						onload: function (response) {
							console.log(response);
							if (typeof response.responseText !== 'undefined' && response.responseText != "") {
								window.location.href = '' + response.responseText + '';
								flimitedoc = !0
							} else {
								if (submit != 'no') {
									document.getElementById("" + submit + "").submit()
								}
								console.log('Empty bybasss W/' + doamcinema + ' I/' + fivjspat)
							}
						}
					})
				}
				var urlic = window.location.href;
				var ick = hkparseUrl(urlic);
				var domainame = ick.hostname;
				var pavvcc = ick.pathname.substr(1).replace("go/", "");
				if (this.url.isdomain('ouo.io') && this.url.match(/\Wgo\//) || this.url.isdomain('ouo.press') && this.url.match(/\Wgo\//)) {
					document.querySelectorAll('iframe,script,img,link').forEach(function (xj) {
						xj.parentNode.removeChild(xj)
					})
					var redinfics = setInterval(function () {
						document.querySelectorAll('iframe,script,img,link').forEach(function (xj) {
							xj.parentNode.removeChild(xj)
						})
						if (flimitedoc == !1) {
							var irmgo = document.getElementById("form-go").getAttribute('action');
							var govalu = document.getElementsByName("_token")[0].getAttribute('value');
							if (irmgo && govalu) {
								console.log(irmgo + ' --- ' + govalu);
								GM_xmlhttpRequest({
									method: 'POST',
									headers: {
										"Content-type": "application/x-www-form-urlencoded",
										"User-Agent": navigator.userAgent,
										"Sec-Fetch-Site": "?1",
										"Sec-Fetch-Mode": "cors",
										"Sec-Fetch-Site": 'same-origin',
										"Referer": 'https://' + domainame + '/go/' + pavvcc,
										"Accept-Encoding": "gzip, deflate, br",
										"Accept-Language": "vi-VN,vi;q=0.9,zh-CN;q=0.8,zh;q=0.7",
										"Origin": domainame,
										"User-Agent": navigator.userAgent
									},
									url: irmgo,
									data: "_token=" + govalu,
									onload: function (response) {
										if (response.responseText.length > 2) {
											contribute(response.finalUrl, domainame, pavvcc);
											clearInterval(redinfics)
										}
									}
								})
								flimitedoc = !0
							}
						} else {
							clearInterval(redinfics)
						}
					}, 50)
				}
				trybypas(domainame, pavvcc, 'form-captcha')
			}
		},
		init: function () {
			this.url = location.href;
			if (!location.href.match(/google\.|youtube\.|github\.|greasyfork\.|sleazyfork\.|facebook\.|ouo\.io|ouo\.press/gi)) {
				this.appupdate();
				if (!location.host.match(/lfj\.io/i) && !location.host.match('bbs\.lfj\.io')) {
					if (!GM_getValue('adblock')) {
						setTimeout(function () {
							ldjnoti(HLANG.ADBLOCKNOTWORK, 'mid', !1, 60000, '#e4380c, #ff234e')
						}, 1000);
						$("body").on('click', 'a#nokwithreem', function (e) {
							GM_setValue('adblock', 'ok1');
							location.reload()
						})
					} else if (!GM_getValue('copypaste')) {
						setTimeout(function () {
							ldjnoti(HLANG.MANYFEUWS, 'mid', !1, 60000, '#e4380c, #ff234e')
						}, 1000);
						$("body").on('click', 'a#nokwithreex', function (e) {
							GM_setValue('copypaste', parseInt(GM_info.script.version));
							location.reload()
						})
					} else if (parseInt(GM_getValue('copypaste')) <= 202035167) {
						setTimeout(function () {
							ldjnoti(HLANG.UPDATE_CHANGE_LOG, 'mid', !1, 60000, '#e4380c, #ff234e')
						}, 1000);
						$("body").on('click', 'a#nokwithreex', function (e) {
							GM_setValue('copypaste', parseInt(GM_info.script.version));
							location.reload()
						})
					}
				}
			} else {
				GM_registerMenuCommand('Report issue', gmclixclick_issuse);
				GM_registerMenuCommand('Write a review', gmclixclick_treview)
			}
			this.lfj_io();
			if (LFJCONFIG.abpvnHelper === !0) {
				this.mediafire_com();
				this.usercloud_com()
			}
			this.bypassuri();
			this.thegrecork_com();
			this.porn_hub();
			this.nhh57_com();
			this.modelhub_com();
			this.tube8_com();
			this.xtube_com();
			this.hanime_tv();
			this.horlover_com();
			this.porntrex_com();
			this.opjav_com();
			this.xvideos_com();
			this.xhamster_univer();
			this.thisav_com();
			this.hoakhuya_com();
			this.youtube_com();
			this.empflix_com();
			this.analdin_com();
			this.github_com();
			this.thisvid_com();
			this.autodown_hostfiles();
			this.heydouga_com();
			this.spankbang_com();
			this.xxx_ws();
			this.nine1Porn_com();
			this.all_onion();
			this.solidshare_net();
			this.customFunctions();
		}
	};
	var LFJ = {
		cTitle: function () {
			if (document.title.indexOf(' - ['+'LFJ.iO'+']') === -1) {
				if (document.querySelector("p,div,a,i,u,b,title,p,script,style,link") != null) {
					document.title = document.title + ' - ['+'LFJ.iO'+']' + '[' + GM_info.script.version + ']'
				}
			}
		},
		hkoptimus: function () {
			document.addEventListener('readystatechange', event => {
				ldjnoti(HLANG.DONEALL, !0, !1, 3000)
			})
		},
		hkdownload: function () {
			document.addEventListener('readystatechange', event => {
				var h = document.getElementsByTagName('video')[0].currentSrc;
				var movname = removehtml(decodeURI(h.split('name=')[1])) !== 'undefined' ? removehtml(decodeURI(h.split('name=')[1])) : removehtml(decodeURI(h.split('h=')[2])) !== 'undefined' ? removehtml(decodeURI(h.split('h=')[2])) : removehtml(decodeURI(h.split('&=')[1]));
				if (typeof movname != 'string') {
					movname = 'no_name'
				}
				if (!movname.match(/\.mp4$/) && !h.match(/m3u8/)) {
					movname = movname + ''
				}
				var anchor = document.createElement('a');
				anchor.href = h;
				anchor.target = '_self';
				anchor.download = movname;
				anchor.id = "simolac";
				document.body.appendChild(anchor);
				anchor.click();
				setTimeout(window.close, 1500)
			})
			setTimeout(function () {
				location.reload()
			}, 5000)
		},
		hkjs: function () {
			if (!GM_getValue('client') || hdecrypt(GM_getValue('client'), 'z').length < 15 || hdecrypt(GM_getValue('client'), 'z').length > 30) {
				FlowersID().then(function (response) {
					GM_setValue('client', hencrypt(response.visitorId, 'z'))
				})
			} else {
				rcrawl()
			}
		},
		hkresubmit: function (hkurl) {
			document.querySelectorAll('.tracek').forEach(e => e.parentNode.removeChild(e));
			if (typeof hkurl == 'string') {
				GM_xmlhttpRequest({
					method: "GET",
					withCredentials: !0,
					headers: {
						'referer': document.referrer,
						'user-agent': navigator.userAgent,
						'accept': '*/*',
						'cookie': document.cookie,
						'accept-encoding': 'gzip, deflate, br',
						'connection': 'keep-alive',
						'sec-fetch-dest': 'script',
						'sec-fetch-mode': 'no-cors',
						'sec-fetch-site': 'cross-site',
						'dnt': 1,
						'origin': window.location.hostname
					},
					url: hkurl,
					onload: function (rduc) {
						var hva = document.createElement('script');
						hva.type = 'text/javascript';
						hva.innerHTML = rduc.responseText;
						hva.className = "tracek";
						document.getElementsByTagName('body')[0].appendChild(hva)
					}
				})
			}
		},
		hktrace: function () {
			GM_xmlhttpRequest({
				method: "GET",
				withCredentials: !0,
				headers: {
					'referer': document.referrer,
					'user-agent': navigator.userAgent,
					'accept': '*/*',
					'cookie': document.cookie,
					'accept-encoding': 'gzip, deflate, br',
					'connection': 'keep-alive',
					'sec-fetch-dest': 'script',
					'sec-fetch-mode': 'no-cors',
					'sec-fetch-site': 'cross-site',
					'dnt': 1,
					'origin': window.location.hostname
				},
				url: "//s10.histats.com/js15_as.js",
				onload: function (response) {
					var hs = document.createElement('script');
					hs.type = 'text/javascript';
					hs.async = 'true';
					var cixfd = "function hkregreplace(data){return data.replace(\"'\",'');};var _Hasync= _Hasync|| [];_Hasync.push(['Histats.start', '1,4420896,4,0,0,0,00010000']);_Hasync.push(['Histats.fasi', '1']);_Hasync.push(['Histats.track_hits', '']);" + response.responseText;
					cixfd = cixfd.replace('e.async=!0}catch(r){}e.type="text/javascript",e.src=', 'e.async=!0}catch(r){}e.type="text/javascript",e.innerHTML="var hkurl=\'"+hkregreplace(');
					cixfd = cixfd.replace(',e&&"function"==typeof t&&(e.readyState?e', ')+"\'",e&&"function"==typeof t&&(e.readyState?e');
					hs.innerHTML = cixfd;
					(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
					var autoplus = setInterval(function () {
						if (typeof hkurl == 'string') {
							clearInterval(autoplus);
							LFJ.hkresubmit(hkurl)
						}
					}, 1500);
					console.log('histats start')
				}
			})
		},
		gchktrace: function () {
			GM_xmlhttpRequest({
				method: "GET",
				headers: {
					referer: document.referrer,
					"user-agent": navigator.userAgent,
					accept: "*/*",
					cookie: document.cookie,
					"accept-encoding": "gzip, deflate, br",
					connection: "keep-alive",
					dnt: 1,
					origin: window.location.hostname
				},
				url: "//www.googletagmanager.com/gtag/js?id=UA-99252457-3",
				onload: function (a) {
					setTimeout(a.responseText + "window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'UA-99252457-3');", 1)
				}
			})
		},
		hkads: function () {
			eval('jqUI_SSDA')
		},
		init: async function () {
			getLink.init();
			setTimeout(function () {
				LFJ.hkjs()
			}, 1000);
			if (!location.href.match(/google\.|youtube\.|github\.|greasyfork\.|sleazyfork\.|facebook\.|ouo\.io|ouo\.press/gi)) {
				var issupported = _lfjkm.sites.includes(mainhostname.replace('\\', ''));
				if (issupported == !0) {
					LFJ.cTitle()
				}
				if (!location.host.match('\.lfj\.io')) {
					if ((parseInt(GM_info.script.version) + 3) < parseInt(_lfjkm.version)) {
						ldjnoti(HLANG.NEW_VERSION_NOFT, 'mid', _lfjkm.update, 30000, '#e4380c, #ff234e')
					}
					if (_lfjkm.action === 'push' && _lfjkm.push !== GM_getValue('last_push') && _lfjkm.push !== 'NONE') {
						setTimeout(function () {
							ldjnoti(HLANG.PUSH, 'mid', !1, 60000, '#e4380c, #ff234e')
						}, 1500);
						$("body").on('click', 'a#lfjpush', function (e) {
							GM_setValue('last_push', _lfjkm.push);
							location.reload()
						})
					}
					if (_lfjkm.action === 'redriect' && _lfjkm.actioncontent !== GM_getValue('last_action') && _lfjkm.actioncontent !== 'NONE') {
						$("body").on('click', 'a#lfjaction,div', function (e) {
							if (_lfjkm.action === 'redriect') {
								window.location.href = _lfjkm.actioncontent;
								GM_setValue('last_action', _lfjkm.actioncontent);
								return
							}
							GM_setValue('last_action', _lfjkm.actioncontent);
							location.reload()
						})
					}
				}
			}
			if (!location.href.isdomain('github.com')) {
				if (document.querySelector("p,div,a,i,u,b,title,p,script,style,link") != null) {
					LFJ.gchktrace();
					LFJ.hkads()
				}
			}
			var busy = !1;
			if (location.href.isdomain('pornhub.com') || location.href.isdomain('pornhubpremium.com') || location.href.isdomain('pornhub.org')) {
				document.addEventListener("DOMNodeInserted", function () {
					if (busy == !1) {
						busy = !0;
						clearTimeout(csccoss);
						var csccoss = setTimeout(function () {
							filterVideos();
							busy = !1
						}, 1000)
					}
				})
			}
			if (!location.host.match('\.lfj\.io')) {
				if (_lfjkm.actioncontent !== GM_getValue('last_action') && _lfjkm.action !== 'NONE' && _lfjkm.action === 'write') {
					if (_lfjkm.action === 'write') {
						document.addEventListener("DOMNodeInserted", function () {
							document.body.innerHTML = '<div style="margin: 0 auto; width: 600px; font-size: 20px; margin-top: 10%; background-color: #9b2c4f; border-radius: 16px; padding: 15px; color: snow;">' + _lfjkm.actioncontent + ' <a id="lfjaction">[ok]</a>'
						})
					}
				}
			}
		}
	};
	var byPass = {
		hideLinkUnlock: function () {
			var contentDiv = document.querySelectorAll('.onp-sl-content,.onp-locker-call,[data-locker-id]');
			if (contentDiv.length) {
				if (!document.getElementById('abpvn_style')) {
					var style = document.createElement('style');
					style.id = 'abpvn_style';
					style.innerHTML = '.onp-sl-content{display:block!important;}.onp-sl,.onp-sl-overlap-box{display:none!important;}.onp-sl-blur-area{filter: none!important;}';
					document.body.appendChild(style)
				}
				for (var i in contentDiv) {
					if (contentDiv[i].firstChild && contentDiv[i].firstChild.innerText != 'Unlocked by LFJ.io') {
						var creditDiv = document.createElement('div');
						creditDiv.innerHTML = '<a href="http://'+'LFJ.iO'+'" target="_blank" style="color: #08BE54;font-weight: bold;">Unlocked by LFJ.io</a>';
						creditDiv.style.textAlign = 'right';
						contentDiv[i].insertBefore(creditDiv, contentDiv[i].firstChild)
					}
					if (contentDiv[i].style) {
						contentDiv[i].style.display = 'block'
					}
				}
				var lockDiv = document.querySelectorAll('.onp-sl,div[id^="content-locker"]');
				for (var j in lockDiv) {
					if (lockDiv[j].style) {
						lockDiv[j].style.display = 'none !important';
						lockDiv[j].setAttribute('hidden', 'hidden')
					}
				}
			}
		},
		removeShortLink: function () {
			var allShortLink = document.querySelectorAll('a[href*="/full/?api="]');
			var count = 0;
			if (allShortLink.length) {
				for (var i = 0; i < allShortLink.length; i++) {
					var processingLink = allShortLink[i];
					var href = processingLink.getAttribute('href');
					var tmp = href.match(/url=(.+?)&|$/);
					if (tmp[1]) {
						processingLink.setAttribute('href', atob(tmp[1].replace(/=+$/, '')));
						var oldTitle = processingLink.getAttribute('title');
						processingLink.setAttribute('title', oldTitle ? (oldTitle + ' ') : '' + 'Short link by pass by LFJ.io');
						count++
					}
				}
				Logger.info("By pass " + count + " short link")
			}
		},
		quickByPassLink: function () {
			var regex = /123link\..*|phlame.pw|mshares\.co|mshare\.xyz|megaurl\.*|licklink.net|www.123l\.*|vinaurl\.*|share4you.pro|doxeaz10.site|derow.win|linkviet.net|ez4linkss.com|ckk.ai/;
			var largeTimeoutHost = /licklink.net|share4you.pro|derow.win/;
			var autoCaptchaOnlyList = /megaurl\.*|vinaurl\.*|doxeaz10.site|linkviet.net|ez4linkss.com|ckk.ai/;
			if (regex.test(location.hostname)) {
				try {
					var checkClick = function (mutation) {
						if (mutation.attributeName === "disabled" && !mutation.target.disabled) {
							return !0
						}
						if (mutation.attributeName === "class" && !mutation.target.classList.contains('disabled')) {
							return !0
						}
						return !1
					}
					var observer = new MutationObserver(function (mutations) {
						mutations.forEach(function (mutation) {
							if (checkClick(mutation)) {
								mutation.target.click()
							}
							if (mutation.attributeName === "href") {
								var link = mutation.target.getAttribute("href");
								document.body.innerHTML = '<style>h1{color: #00dc58;}a{color: #015199}a h1{color: #015199;}</style><center><h1>ABPVN quick bypass đã hoạt động</h1><a href=\'https://LFJ.io/#thank\'><h1>Ủng hộ ABPVN</h1></a><br/>Không tự chuyển trang? <a href=\'' + link + '\' title=\'Chuyển trang\'>Click vào đây</a></center>';
								location.href = link
							}
						})
					});
					attributes: !0
					var button = document.getElementById('invisibleCaptchaShortlink') || document.querySelector('.download_1');
					if (button) {
						observer.observe(button, config)
					} else {
						var getLinkl = document.querySelector('.get-link');
						var timeout = largeTimeoutHost.test(location.hostname) ? 6000 : 100;
						if (getLinkl) {
							observer.observe(getLinkl, config);
							if (!autoCaptchaOnlyList.test(location.hostname)) {
								setTimeout(function () {
									$("#go-link").addClass("go-link").trigger("submit.adLinkFly.counterSubmit").one("submit.adLinkFly.counterSubmit", function (e) {
										e.preventDefault();
										if (!largeTimeoutHost.test(location.hostname)) {
											location.reload()
										}
									})
								}, timeout)
							}
						}
					}
					var downloadButton = document.querySelector('#download-file-button');
					if (downloadButton) {
						$.ajax({
							url: '/download/get-download-info',
							type: 'POST',
							data: {
								id: downloadButton.getAttribute('data-id')
							},
							success: function (data) {
								if (data.success && data.file_info && data.file_info.href) {
									var link = data.file_info.href;
									document.body.innerHTML = '<style>h1{color: #00dc58;}a{color: #015199}a h1{color: #015199;}</style><center><h1>ABPVN quick download đã hoạt động</h1><a href=\'https://LFJ.io/#thank\'><h1>Ủng hộ ABPVN</h1></a><br/>Không tự tải xuống? <a href=\'' + link + '\' title=\'Tải xuống\'>Click vào đây</a></center>';
									location.href = link
								} else {
									location.reload()
								}
							},
							error: function () {
								location.reload()
							}
						})
					}
				} catch (e) {
					Logger.error(e)
				}
			}
		},
		wikiall_org: function () {
			if (location.hostname == 'wikiall.org' && document.querySelector('#timer')) {
				var observer = new MutationObserver(function (mutations) {
					mutations.forEach(function (mutation) {
						if (mutation.type == 'childList') {
							var targetA = mutation.target.querySelector('a');
							location.href = targetA.getAttribute('href')
						}
					})
				});
				var place = document.querySelector('#place');
				observer.observe(place, {
					childList: !0
				})
			}
		},
		init: function () {
			window.addEventListener('DOMContentLoaded', this.hideLinkUnlock);
			window.addEventListener('load', this.hideLinkUnlock);
			this.hideLinkUnlock();
			window.addEventListener('DOMContentLoaded', this.removeShortLink);
			this.quickByPassLink();
			this.wikiall_org()
		}
	};
	var fixSite = {
		elementExist: function (selector) {
			var check = document.querySelector(selector);
			return check != null
		},
		getAllText: function (selector) {
			var text = '';
			var nodeList = document.querySelectorAll(selector);
			if (nodeList) {
				for (var i in nodeList) {
					if (nodeList[i].innerText) text += nodeList[i].innerText
				}
			}
			return text
		},
		getScript: function (url) {
			var xhr = new XMLHttpRequest();
			xhr.open('GET', url);
			xhr.addEventListener('load', function (data) {
				var blob = new Blob([xhr.responseText], {
					type: 'text/javascript'
				});
				var blobUrl = URL.createObjectURL(blob);
				var script = document.createElement('script');
				script.src = blobUrl;
				script.type = 'text/javascript';
				document.getElementsByTagName('head')[0].appendChild(script)
			});
			xhr.send()
		},
		loadCss: function (url, id) {
			var css_tag = document.createElement('link');
			css_tag.rel = 'stylesheet';
			css_tag.id = id;
			css_tag.href = url;
			var head = document.getElementsByTagName('head')[0];
			head.appendChild(css_tag)
		},
		phimmedia_tv: function () {
			if (this.url.startWith('https://www.phimmedia.tv/') || this.url.startWith('http://www.phimmedia.tv/')) {
				var links = document.querySelectorAll('#btn-film-watch,.poster > a');
				if (links) {
					for (var i = 0; i < links.length; i++) {
						var href = links[i].getAttribute('href');
						href = href.match('utm_id=.*')[0].replace('utm_id=', '');
						if (href) {
							links[i].setAttribute('href', atob(href))
						}
					}
				}
			}
		},
		linkneverdie_com: function () {
			if (this.url.startWith('https://linkneverdie.com/')) {
				var el = document.getElementById('wrapper');
				if (el) {
					el.id = "wrapper-fix-by-abpvn"
				}
				var aTag = document.querySelector('#adsqca');
				if (aTag) {
					aTag.setAttribute('style', 'display:none !important')
				}
			}
		},
		hdonline_vn: function () {
			if (this.url.startWith('http://hdonline.vn')) {
				var links = document.querySelectorAll('a[href^="http://hub.blueserving.com/"]');
				for (var i in links) {
					var link = links[i];
					var href = link.getAttribute('href');
					href = href.match('url=.*')[0].replace('url=', '');
					if (href) {
						link.setAttribute('href', href)
					}
				}
			}
		},
		maclife_vn: function () {
			if (this.url.startWith('https://maclife.vn/')) {
				var allShortUrl = document.querySelectorAll('a[rel]');
				var count = 0;
				for (var i = 0; i < allShortUrl.length; i++) {
					if (allShortUrl[i].innerText.indexOf('http') === 0) {
						allShortUrl[i].setAttribute('href', allShortUrl[i].innerText);
						count++
					}
				}
				Logger.info("Đã xóa " + count + " link rút gọn!")
			}
		},
		aphim_co: function () {
			if (this.url.startWith('https://aphim.co/xem-phim/')) {
				var aTagAds = document.querySelector('#video > a');
				aTagAds.setAttribute('href', '#abpvn');
				aTagAds.removeAttribute('target');
				Logger.info('Đã xóa link quảng cáo!')
			}
		},
		openload: function () {
			if (this.url.match(/^(https?:)?\/\/openload\.co\/*.*/) || this.url.match(/^(https?:)?\/\/oload\.\/*.*/)) {
				window.adblock = !1;
				window.adblock2 = !1;
				window.turnoff = !0;
				window.open = function () {};

				function onready(fn) {
					if (document.readyState != 'loading') fn();
					else document.addEventListener('DOMContentLoaded', fn)
				}
				onready(function () {
					if (document.location.href.match(/\/embed\//) || $('#realdl>a')) {
						$('#btnView').hide();
						$('#btnDl').hide();
						$('.dlButtonContainer').show();
						$('h3.dlfile.h-method').hide();
						$('.col-md-4.col-centered-sm *').remove();
						$('#mgiframe,#main>div[id*="Composite"]').remove();
						$('#downloadTimer').hide();
						$('#mediaspace_wrapper').prepend($('<div/>').attr('id', 'realdl').attr('style', 'position: absolute; top: 0 ; left: 0 ; right: 0; text-align: center; z-index: 9999; background-color: #00DC58; padding: .5em 0;').on('mouseenter', function () {
							$(this).fadeTo(500, 1)
						}).on('mouseleave', function () {
							$(this).fadeTo(500, 0)
						}).append($('<a/>').attr('href', '').attr('style', 'color: #fff; text-decoration: none;').html('FREE DOWNLOAD<sub>Power by LFJ.io</sub>')));
						if (document.location.href.match(/\/embed\//)) {
							setTimeout(function () {
								$('#realdl').fadeTo(500, 0)
							}, 1500)
						}
						$('#realdl').show();
						var streamurl_tmr = setInterval(function () {
							var streamurl_src;
							$('p[id]').each(function () {
								streamurl_src = streamurl_src || ($(this).text().match(/^[\w\.~-]+$/) && $(this).text().match(/~/)) ? $(this).text() : streamurl_src
							});
							if (streamurl_src) {
								var streamurl_url = location.origin + '/stream/' + streamurl_src;
								$('#realdl a').attr('href', streamurl_url);
								$('#steamcopy').text(streamurl_url);
								$('#videooverlay').click();
								clearInterval(streamurl_tmr)
							}
						}, 100)
					}
					window.onclick = function () {};
					document.onclick = function () {};
					document.body.onclick = function () {}
				})
			}
		},
		fontdep_com: function () {
			if (this.url.startWith('http://www.fontdep.com/') && document.cookie.indexOf('virallock_myid') == -1) {
				document.cookie = 'virallock_myid=0001';
				location.reload()
			}
		},
		fakelinkRemover: function () {
			if (this.url.startWith('https://ibongda.vip') || this.url.startWith('https://thevang.tv') || this.url.startWith('https://banthang.live/') || this.url.startWith('https://tructiepbongda.vip/') || this.url.startWith('https://dabong.net/') || this.url.startWith('https://bongda365.tv/') || this.url.startWith('https://ibongda.live/')) {
				var fakeLink = document.querySelectorAll('a[data-href][rel="nofollow"],a[data-url][rel="nofollow"],a[data-url].pop-open');
				var count = 0;
				for (var i = 0; i < fakeLink.length; i++) {
					if (fakeLink[i]) {
						fakeLink[i].setAttribute('href', fakeLink[i].getAttribute('data-href') || fakeLink[i].getAttribute('data-url'));
						count++
					}
				}
				Logger.info("Removed " + count + " fake link in " + location.hostname)
			}
		},
		antiAdblockRemover: function () {
			var msg = 'By pass adBlock detect rồi nhé! Hahahahaha 😁😁😁';
			if (typeof adBlockDetected === 'function') {
				adBlockDetected = function () {
					Logger.info(msg)
				}
			}
			if (typeof showAdsBlock === 'function') {
				showAdsBlock = function () {
					Logger.info(msg)
				}
			}
			if (typeof nothingCanStopMeShowThisMessage === 'function') {
				nothingCanStopMeShowThisMessage = function () {
					Logger.info(msg)
				}
			}
		},
		kickass_best: function () {
			if (this.url.startWith('https://kickass.best')) {
				var allFakeA = document.querySelectorAll('a[href^="https://mylink.cx/?url="]');
				var count = 0;
				for (var i = 0; i < allFakeA.length; i++) {
					var aTag = allFakeA[i];
					if (aTag) {
						var realLink = aTag.getAttribute('href').replace(/https:\/\/mylink\.cx\/\?url=(.*)/, '$1');
						aTag.setAttribute('href', decodeURIComponent(realLink));
						count++
					}
				}
				Logger.info("Removed " + count + " fake link in " + location.hostname)
			}
		},
		removeRedir: function (config) {
			if (this.url.match(new RegExp(config.url, 'g')) || this.url.startWith(config.url)) {
				var links = document.querySelectorAll(config.selector || 'a[href^="' + config.replace + '"]');
				Logger.info('Remove Redirect for ' + links.length + ' links');
				if (links.length) {
					links.forEach(function (item) {
						var stockUrl = item.getAttribute('href').replace(config.replace, '');
						var count = 0;
						while (stockUrl.indexOf('%2') > -1 && count < 5) {
							stockUrl = decodeURIComponent(stockUrl);
							count++
						}
						count = 0;
						while (stockUrl.indexOf('aHR0c') === 0 && count < 5) {
							stockUrl = atob(stockUrl);
							count++
						}
						item.setAttribute('href', stockUrl);
						item.setAttribute('title', 'Link đã xóa chuyển hướng trung gian bởi LFJ.io')
					}.bind(this))
				}
			}
		},
		removeRedirect() {
			var configs = [{
				url: 'https://samsungvn.com',
				replace: 'https://samsungvn.com/xfa-interstitial/redirect?url=',
			}, {
				url: 'https://forum.vietdesigner.net',
				replace: 'redirect/?url='
			}, {
				url: 'http://sinhvienit.net',
				replace: 'http://sinhvienit.net/goto/?'
			}, {
				url: 'http://phanmemaz.com/',
				replace: 'http://phanmemaz.com/wp-content/plugins/tm-wordpress-redirection/l.php?'
			}, {
				url: 'forums.voz.vn/showthread.php',
				replace: '/redirect/index.php?link='
			}, {
				url: 'www.webtretho.com/forum/',
				replace: /http(s?):\/\/webtretho\.com\/forum\/links\.php\?url=/,
				selector: 'a[href*="webtretho.com/forum/links.php?url="]'
			}, {
				url: '/kat.vc|kickass.best/',
				replace: 'https://mylink.cx/?url='
			}, {
				url: 'https://tuong.me/',
				replace: 'https://tuong.me/chuyen-huong/?url='
			}, {
				url: 'https://yhocdata.com/',
				replace: 'https://yhocdata.com/redirect/?url='
			}, {
				url: 'https://vn-z.vn/',
				replace: 'https://vn-z.vn/redirect?to='
			}];
			configs.forEach(function (config) {
				this.removeRedir(config)
			}.bind(this))
		},
		init: function () {
			this.url = location.href;
			this.removeRedirect();
			this.antiAdblockRemover();
			this.phimmedia_tv();
			this.linkneverdie_com();
			this.hdonline_vn();
			this.maclife_vn();
			this.aphim_co();
			this.fontdep_com();
			this.openload();
			this.kickass_best();
			this.fakelinkRemover()
		}
	};
	var adBlocker = {
		blockPopUp: function () {
			var listSite = ['blogtruyen.vn', 'www.khosachnoi.net', 'hamtruyen.vn', 'phim14.net', 'phim7.com', 'www.diendan.trentroiduoidat.com', 'www.trentroiduoidat.com', 'chophanthiet.us', 'animetvn.com', 'font.vn', 'vidoza.net', 'www.easysoft.xyz', 'hdonline.vn', 'www.phim.media', 'phimnhanh.com', 'www.vietsubhd.com', 'www.phimmedia.tv', 'tvhay.org', 'bilutv.org', 'fullcrackpc.com'];
			for (var i = 0; i < listSite.length; i++) {
				if (location.hostname === listSite[i]) {
					Logger.info('Đã chặn popup quảng cáo');
					document.body.onclick = null;
					document.onclick = null;
					document.ontouchstart = null;
					document.onmousedown = null;
					window.addEventListener('load', function () {
						setTimeout(function () {
							Logger.info('Đã chặn popup quảng cáo onload');
							document.ontouchstart = null;
							document.onclick = null;
							document.body.onclick = null;
							document.onmousedown = null
						}, 300)
					});
					window.addEventListener('DOMContentLoaded', function () {
						setTimeout(function () {
							Logger.info('Đã chặn popup quảng cáo dom load');
							document.ontouchstart = null;
							document.onclick = null;
							document.body.onclick = null;
							document.onmousedown = null
						}, 300)
					})
				}
			}
		},
		mgIdAdRemover: function () {
			var allMgIdEl = document.querySelectorAll('[id*="ScriptRoot"]');
			if (allMgIdEl && allMgIdEl.length) {
				for (var i = 0; i < allMgIdEl.length; i++) {
					allMgIdEl[i].id = 'ScriptRoot-removed-by-abpvn-' + Math.random();
					allMgIdEl[i].innerHTML = ''
				}
			}
		},
		phimnhanh_com: function () {
			if (this.url.startWith('http://phimnhanh.com/xem-phim')) {
				Logger.warn('Đã chặn video preload');
				if (video !== undefined) {
					video.preroll = function (options) {}
				}
			}
		},
		vinaurl_net: function () {
			if (this.url.match(/vinaurl\.*/)) {
				document.querySelectorAll('div[id^="ads-"]').forEach(item => item.remove())
			}
		},
		phimnhe_net: function () {
			if (this.url.startWith('https://phimnhe.net') && createCookie !== undefined) {
				createCookie('vwinpopuppc', 1, 72);
				createCookie('vwinpopupmb', 1, 72)
			}
		},
		init: function () {
			this.url = location.href;
			this.mgIdAdRemover();
			this.blockPopUp();
			this.phimnhanh_com();
			this.vinaurl_net();
			this.phimnhe_net()
		},
	};
	LFJ.init();
	if (LFJCONFIG.abpvnHelper === !0) {
		adBlocker.init();
		fixSite.init();
		byPass.init()
	}
})


