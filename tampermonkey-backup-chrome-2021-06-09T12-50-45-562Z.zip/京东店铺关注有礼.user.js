// ==UserScript==
// @name         京东店铺关注有礼
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  京东店铺关注有礼,获取京豆奖励
// @author       You
// @match        https://f-mall.jd.com/
// @grant        none
// ==/UserScript==


javascript:void(function() { if(location.href.indexOf('f-mall.jd.com')==-1){ location.replace("https://f-mall.jd.com/"); } var scriptTag=document.createElement("script"); scriptTag.src='https://tyh52.com/jd/static/shopUrl.js'; document.body.appendChild(scriptTag); })()