// ==UserScript==
// @name         京东自动入会助手
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  京东自动查找店铺入会奖励入会
// @author       小赤佬
// @match        https://chat1.jd.com/
// @grant        none
// ==/UserScript==

javascript:void(function() { if(location.href.indexOf('chat1.jd.com')==-1){ location.replace("https://chat1.jd.com/"); } var scriptTag=document.createElement("script"); scriptTag.src='https://tyh52.com/jd/static/ruhui.js'; document.body.appendChild(scriptTag); })()