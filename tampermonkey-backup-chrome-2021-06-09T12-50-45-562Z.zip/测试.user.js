// ==UserScript==
// @name         测试
// @namespace    http://tampermonkey.net/
// @version      0.3.2.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       lpjp01
// require  https://greasemonkey.github.io/gm4-polyfill/gm4-polyfill.js
// @match        https://*.xuexi.cn/
// @match        https://xuexi.cn
// @match        https://xuexi.cn/index.html
// @match        https://www.xuexi.cn/index.html
// @match        https://pc.xuexi.cn/points/my-points.html
// @match        https://pc.xuexi.cn/points/exam-practice.html
// @match        https://pc.xuexi.cn/points/exam-weekly-detail.html?id=*
// @match        https://pc.xuexi.cn/points/exam-weekly-list.html
// @match        https://pc.xuexi.cn/points/exam-paper-detail.html?id=*
// @match        https://pc.xuexi.cn/points/exam-paper-list.html
// @grant        GM_download
// @grant        GM_openInTab
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_xmlhttpRequest
// @grant        GM_addStyle
// @grant        unsafeWindow
// @grant        GM_setClipboard
// @grant        GM_getResourceURL
// @grant        GM_getResourceText
// @grant        GM_info
// @grant        GM_registerMenuCommand
// @run-at       document-idle
// ==/UserScript==
