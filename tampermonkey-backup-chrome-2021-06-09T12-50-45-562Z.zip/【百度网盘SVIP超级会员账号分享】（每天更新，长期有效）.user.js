// ==UserScript==
// @name         【百度网盘SVIP超级会员账号分享】（每天更新，长期有效）
// @namespace    http://tampermonkey.net/
// @version      1.3.0.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       You
// @match        *://pan.baidu.com/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==
