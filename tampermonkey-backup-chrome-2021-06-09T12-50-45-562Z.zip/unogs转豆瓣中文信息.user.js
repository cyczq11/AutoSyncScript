// ==UserScript==
// @name       unogs转豆瓣中文信息
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include        *://unogs.*
// @grant       GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';
    //创建悬浮div
    var mypop = $('<div id='+ "'haha123'" +' style="display:none; position:absolute; left:0px; top:0px; z-index:999; width:250px"></div>');
    $('body').append(mypop);

    //悬浮div的样式
    var mysty = '';
    var dqimg = '';

    //悬浮div的内容
    var myxsc = '载入中。。。';

    //用于搜索的标题
    var mytt = '234';

    //豆瓣显示中文标题和简介
    var myxstt,myxsjj = '';

    //提取第一次搜索get访问的真正链接
    var myflink = '';

    //第一次搜索get访问
    var ret1 = function(){GM_xmlhttpRequest({
                method: "GET",
                url: "https://www.douban.com/search?q=" + encodeURIComponent(mytt),
                onload: function (res) {
                    var myxml=$(res.response);
                    myflink = myxml.find('.title').find('a')[0].href;
                    ret2();
                }
    })}

    //第二次也就是真正获取中文信息的访问
    var ret2 = function(){GM_xmlhttpRequest({
                method: "GET",
                url: myflink,
                onload: function (res) {
                    var myxml=$(res.response);
                    var myxstt = myxml.find('#content').find('h1').text();
                    var myxsjj = myxml.find('#link-report').text();
                    myxsc = '<button id="haha" style="font-size: 10px;position: relative;top: -8px;left: 214px;height: 21px;" onclick="document.getElementById('+"'haha123')"+'.setAttribute(' + "'style'" + ",'display:none'" + ');">X</button>' + '<b style="font-size:18px;">' + myxstt + '</b><br><br>' + '简介内容:<br>' +myxsjj;
                    mypop.html(myxsc);
                }
    })}

    //显示悬浮div方法
    function xss(e) {
        var pageX=e.pageX;
        var pageY=e.pageY;
        if(mypop.css('display')=='none'){
        mysty = 'background-color:white; position:absolute; left:' + pageX + 'px; top:' + pageY + 'px; z-index:999; width:250px;padding:10px; border:5px solid rgba(255, 7, 7, 0.64);'
        mypop.attr('style',mysty);
        mypop.text('载入中。。。');
        mypop.css('display','block');
        mytt = $(this).parent().find('b').eq(0).text();

            ret1();}


    }

    //隐藏悬浮div方法
    function ycc() {
        //var pageX=e.pageX;
        //var pageY=e.pageY;
        mypop.css('display','none');
    }

    //给当前页面的所有缩略图绑定方法
    var reloadInterval = window.setInterval(mybb, 3);
    function mybb(){
        dqimg = $('img.img-rounded');
        for (var i = 0; i < dqimg.length; i++) {
        //dqimg.eq(i).on('mouseover',xss);
        dqimg.eq(i).parent().find('b').eq(0).on('mouseover',xss);
        //dqimg.eq(i).on('mouseout',ycc);
        }
        if(dqimg.length!=0){window.clearInterval(reloadInterval);}
    }



























})();